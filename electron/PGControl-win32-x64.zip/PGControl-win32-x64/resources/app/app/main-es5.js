(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    "./$$_lazy_route_resource lazy recursive":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function $$_lazy_route_resourceLazyRecursive(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
      /***/
    },

    /***/
    "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js", "common", 0],
        "./ion-alert.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert.entry.js", "common", 1],
        "./ion-app_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js", "common", 2],
        "./ion-avatar_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js", "common", 3],
        "./ion-back-button.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js", "common", 4],
        "./ion-backdrop.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js", 5],
        "./ion-button_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js", "common", 6],
        "./ion-card_5.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js", "common", 7],
        "./ion-checkbox.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js", "common", 8],
        "./ion-chip.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip.entry.js", "common", 9],
        "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 10],
        "./ion-datetime_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js", "common", 11],
        "./ion-fab_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js", "common", 12],
        "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 13],
        "./ion-infinite-scroll_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js", 14],
        "./ion-input.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input.entry.js", "common", 15],
        "./ion-item-option_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js", "common", 16],
        "./ion-item_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js", "common", 17],
        "./ion-loading.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading.entry.js", "common", 18],
        "./ion-menu_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js", "common", 19],
        "./ion-modal.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal.entry.js", "common", 20],
        "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 21],
        "./ion-popover.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover.entry.js", "common", 22],
        "./ion-progress-bar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js", "common", 23],
        "./ion-radio_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js", "common", 24],
        "./ion-range.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range.entry.js", "common", 25],
        "./ion-refresher_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js", "common", 26],
        "./ion-reorder_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js", "common", 27],
        "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 28],
        "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 29],
        "./ion-searchbar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js", "common", 30],
        "./ion-segment_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js", "common", 31],
        "./ion-select_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js", "common", 32],
        "./ion-slide_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js", 33],
        "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 34],
        "./ion-split-pane.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js", 35],
        "./ion-tab-bar_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js", "common", 36],
        "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 37],
        "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 38],
        "./ion-textarea.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js", "common", 39],
        "./ion-toast.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast.entry.js", "common", 40],
        "./ion-toggle.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js", "common", 41],
        "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 42]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app>\n  <app-menu></app-menu>\n</ion-app>\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppComponentsHeaderHeaderComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"titulo\">\n    <ion-title><ion-text class=\"lbl\">{{ titulo }}</ion-text></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html":
    /*!*******************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppComponentsMenuMenuComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-split-pane contentId=\"main\" color=\"dark\">\n  \n  <ion-menu contentId=\"main\" class=\"ion-text-center\" color=\"dark\" >\n    <ion-header color=\"dark\" class=\"ion-no-border\">\n      <ion-toolbar color=\"dark\">\n        <ion-title><ion-text color=\"light\" class=\"ion-text-center\">Menu</ion-text></ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content class=\"back\">\n      <p></p>\n      <ion-label><h1>Pollos Gris</h1></ion-label>      \n      <img class=\"icon2\" src=\"assets/icon/pollo.png\">\n      <p></p>\n      \n\n      <ion-list>\n        <ion-item detail lines=\"inset\" mode=\"ios\" routerLink=\"/venta\">\n          <ion-icon slot=\"start\" name=\"storefront-outline\"></ion-icon>          \n          <ion-label><h1>Venta</h1></ion-label>\n        </ion-item>\n        <ion-item (click)=\"crearCorte()\" mode=\"ios\" lines=\"inset\"  detail>\n          <ion-icon slot=\"start\" name=\"albums-outline\"></ion-icon>\n          <ion-label><h1>Corte de caja</h1></ion-label>\n        </ion-item>     \n        <ion-item mode=\"ios\" lines=\"inset\">\n          <ion-icon slot=\"start\" name=\"document-text-outline\"></ion-icon>\n          <ion-label><h1>Informes</h1></ion-label>\n        </ion-item> \n        <ion-item mode=\"ios\" lines=\"none\">\n          <ion-list>\n            <ion-item mode=\"ios\" lines=\"inset\" detail routerLink=\"/infoventas\">\n              <ion-icon slot=\"start\" name=\"bar-chart-outline\"></ion-icon>\n              <ion-label><h1>Ventas</h1></ion-label>\n            </ion-item> \n            <ion-item mode=\"ios\" lines=\"inset\" detail routerLink=\"/infocortes\"> \n              <ion-icon slot=\"start\" name=\"file-tray-full-outline\"></ion-icon>\n              <ion-label><h1>Cortes de caja</h1></ion-label>\n            </ion-item> \n            <!-- <ion-item mode=\"ios\" lines=\"inset\" detail routerLink=\"/infoinventario\">\n              <ion-icon slot=\"start\" name=\"newspaper-outline\"></ion-icon>\n              <ion-label><h1>Inventario</h1></ion-label>\n            </ion-item>  -->\n          </ion-list>\n        </ion-item>\n        <ion-item mode=\"ios\" lines=\"inset\" detail routerLink=\"/adminusuarios\">\n          <ion-icon slot=\"start\" name=\"people-outline\"></ion-icon>\n          <ion-label><h1>Administrar Usuarios</h1></ion-label>\n        </ion-item> \n        <!-- <ion-item mode=\"ios\" lines=\"inset\" detail routerLink=\"/adminproductos\">\n          <ion-icon slot=\"start\" name=\"basket-outline\"></ion-icon>\n          <ion-label><h1>Administrar Productos</h1></ion-label>\n        </ion-item>  -->\n        <ion-item color=\"danger\" lines=\"inset\" mode=\"ios\" detail routerLink=\"/login\">\n          <ion-icon slot=\"start\" name=\"power-outline\"></ion-icon>\n          <ion-label><h1>Cerrar Sesión</h1></ion-label>\n        </ion-item> \n      </ion-list>\n    </ion-content>\n  </ion-menu >\n\n  \n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-split-pane>\n";
      /***/
    },

    /***/
    "./src/app/app-routing.module.ts":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var routes = [{
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
      }, {
        path: 'login',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-login-login-module */
          "pages-login-login-module").then(__webpack_require__.bind(null,
          /*! ./pages/login/login.module */
          "./src/app/pages/login/login.module.ts")).then(function (m) {
            return m.LoginPageModule;
          });
        }
      }, {
        path: 'venta',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-venta-venta-module */
          "pages-venta-venta-module").then(__webpack_require__.bind(null,
          /*! ./pages/venta/venta.module */
          "./src/app/pages/venta/venta.module.ts")).then(function (m) {
            return m.VentaPageModule;
          });
        }
      }, {
        path: 'corte',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-corte-corte-module */
          "pages-corte-corte-module").then(__webpack_require__.bind(null,
          /*! ./pages/corte/corte.module */
          "./src/app/pages/corte/corte.module.ts")).then(function (m) {
            return m.CortePageModule;
          });
        }
      }, {
        path: 'infoventas',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-infoventas-infoventas-module */
          "pages-infoventas-infoventas-module").then(__webpack_require__.bind(null,
          /*! ./pages/infoventas/infoventas.module */
          "./src/app/pages/infoventas/infoventas.module.ts")).then(function (m) {
            return m.InfoventasPageModule;
          });
        }
      }, {
        path: 'infocortes',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-infocortes-infocortes-module */
          "pages-infocortes-infocortes-module").then(__webpack_require__.bind(null,
          /*! ./pages/infocortes/infocortes.module */
          "./src/app/pages/infocortes/infocortes.module.ts")).then(function (m) {
            return m.InfocortesPageModule;
          });
        }
      }, {
        path: 'infoinventario',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-infoinventario-infoinventario-module */
          "pages-infoinventario-infoinventario-module").then(__webpack_require__.bind(null,
          /*! ./pages/infoinventario/infoinventario.module */
          "./src/app/pages/infoinventario/infoinventario.module.ts")).then(function (m) {
            return m.InfoinventarioPageModule;
          });
        }
      }, {
        path: 'adminusuarios',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | pages-adminusuarios-adminusuarios-module */
          [__webpack_require__.e("common"), __webpack_require__.e("pages-adminusuarios-adminusuarios-module")]).then(__webpack_require__.bind(null,
          /*! ./pages/adminusuarios/adminusuarios.module */
          "./src/app/pages/adminusuarios/adminusuarios.module.ts")).then(function (m) {
            return m.AdminusuariosPageModule;
          });
        }
      }, {
        path: 'adminproductos',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-adminproductos-adminproductos-module */
          "pages-adminproductos-adminproductos-module").then(__webpack_require__.bind(null,
          /*! ./pages/adminproductos/adminproductos.module */
          "./src/app/pages/adminproductos/adminproductos.module.ts")).then(function (m) {
            return m.AdminproductosPageModule;
          });
        }
      }, {
        path: 'crear-usuarios',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-crear-usuarios-crear-usuarios-module */
          "common").then(__webpack_require__.bind(null,
          /*! ./pages/crear-usuarios/crear-usuarios.module */
          "./src/app/pages/crear-usuarios/crear-usuarios.module.ts")).then(function (m) {
            return m.CrearUsuariosPageModule;
          });
        }
      }, {
        path: 'editar-usuarios',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-editar-usuarios-editar-usuarios-module */
          "common").then(__webpack_require__.bind(null,
          /*! ./pages/editar-usuarios/editar-usuarios.module */
          "./src/app/pages/editar-usuarios/editar-usuarios.module.ts")).then(function (m) {
            return m.EditarUsuariosPageModule;
          });
        }
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "./src/app/app.component.scss":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "@charset \"UTF-8\";\n.back {\n  --ion-background-color: #ffe073;\n  --border-color: black;\n}\n.icon {\n  display: block;\n  margin-top: 50px;\n  margin-left: auto;\n  margin-right: auto;\n  width: 20%;\n}\n.icon2 {\n  display: block;\n  margin-top: 50px;\n  margin-left: auto;\n  margin-right: auto;\n  width: 30%;\n}\n.ip {\n  margin-left: auto;\n  margin-right: auto;\n  margin-bottom: 5px;\n  width: 50%;\n  --background: #fff7dc;\n  --color: #cca900;\n  --border-radius: 5% / 50%;\n}\n.txt {\n  --color: #cca900;\n}\n.ilbl {\n  text-align: center;\n  --border-style: none;\n}\n.boton {\n  --background: #fff7dc;\n  --color: #cca900;\n  margin-left: auto;\n  margin-right: auto;\n}\nion-icon[class*=”custom-”] {\n  -webkit-mask-size: contain;\n          mask-size: contain;\n  -webkit-mask-position: 50% 50%;\n          mask-position: 50% 50%;\n  -webkit-mask-repeat: no-repeat;\n          mask-repeat: no-repeat;\n  background: currentColor;\n  width: 1em;\n  height: 1em;\n}\nion-icon[class*=”custom-pokemon”] {\n  -webkit-mask-image: url('pierna.png');\n          mask-image: url('pierna.png');\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQUFoQjtFQUNJLCtCQUFBO0VBQ0EscUJBQUE7QUFFSjtBQUNBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFFSjtBQUNBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFFSjtBQUNBO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQUVKO0FBQ0E7RUFDSSxnQkFBQTtBQUVKO0FBQ0E7RUFDSSxrQkFBQTtFQUNBLG9CQUFBO0FBRUo7QUFDQTtFQUNJLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRUo7QUFFSTtFQUNBLDBCQUFBO1VBQUEsa0JBQUE7RUFDQSw4QkFBQTtVQUFBLHNCQUFBO0VBQ0EsOEJBQUE7VUFBQSxzQkFBQTtFQUNBLHdCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUFDSjtBQUNJO0VBQ0EscUNBQUE7VUFBQSw2QkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuLmJhY2sge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZmZlMDczO1xuICAtLWJvcmRlci1jb2xvcjogYmxhY2s7XG59XG5cbi5pY29uIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIHdpZHRoOiAyMCU7XG59XG5cbi5pY29uMiB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tdG9wOiA1MHB4O1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICB3aWR0aDogMzAlO1xufVxuXG4uaXAge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIHdpZHRoOiA1MCU7XG4gIC0tYmFja2dyb3VuZDogI2ZmZjdkYztcbiAgLS1jb2xvcjogI2NjYTkwMDtcbiAgLS1ib3JkZXItcmFkaXVzOiA1JSAvIDUwJTtcbn1cblxuLnR4dCB7XG4gIC0tY29sb3I6ICNjY2E5MDA7XG59XG5cbi5pbGJsIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtLWJvcmRlci1zdHlsZTogbm9uZTtcbn1cblxuLmJvdG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmN2RjO1xuICAtLWNvbG9yOiAjY2NhOTAwO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuXG5pb24taWNvbltjbGFzcyo94oCdY3VzdG9tLeKAnV0ge1xuICBtYXNrLXNpemU6IGNvbnRhaW47XG4gIG1hc2stcG9zaXRpb246IDUwJSA1MCU7XG4gIG1hc2stcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQ6IGN1cnJlbnRDb2xvcjtcbiAgd2lkdGg6IDFlbTtcbiAgaGVpZ2h0OiAxZW07XG59XG5pb24taWNvbltjbGFzcyo94oCdY3VzdG9tLXBva2Vtb27igJ1dIHtcbiAgbWFzay1pbWFnZTogdXJsKC4uL2Fzc2V0cy9pY29uL3BpZXJuYS5wbmcpO1xufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/app.component.ts":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _servicios_backend_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./servicios/backend.service */
      "./src/app/servicios/backend.service.ts");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar, backendService) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.backendService = backendService;
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            var _this = this;

            this.platform.ready().then(function () {
              _this.statusBar.styleDefault();

              _this.splashScreen.hide();
            });
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
        }, {
          type: _servicios_backend_service__WEBPACK_IMPORTED_MODULE_5__["BackendService"]
        }];
      };

      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./app.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./app.component.scss */
        "./src/app/app.component.scss"))["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "./src/app/app.module.ts":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "./src/app/app.component.ts");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./app-routing.module */
      "./src/app/app-routing.module.ts");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./components/components.module */
      "./src/app/components/components.module.ts");
      /* harmony import */


      var _servicios_backend_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./servicios/backend.service */
      "./src/app/servicios/backend.service.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./pipes/pipes.module */
      "./src/app/pipes/pipes.module.ts");

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_12__["PipesModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HttpClientModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_9__["ComponentsModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"]],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _servicios_backend_service__WEBPACK_IMPORTED_MODULE_10__["BackendService"], {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "./src/app/components/components.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/components/components.module.ts ***!
      \*************************************************/

    /*! exports provided: ComponentsModule */

    /***/
    function srcAppComponentsComponentsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ComponentsModule", function () {
        return ComponentsModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./header/header.component */
      "./src/app/components/header/header.component.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./menu/menu.component */
      "./src/app/components/menu/menu.component.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var ComponentsModule = function ComponentsModule() {
        _classCallCheck(this, ComponentsModule);
      };

      ComponentsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_3__["HeaderComponent"], _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"]],
        exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_3__["HeaderComponent"], _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"]]
      })], ComponentsModule);
      /***/
    },

    /***/
    "./src/app/components/header/header.component.scss":
    /*!*********************************************************!*\
      !*** ./src/app/components/header/header.component.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppComponentsHeaderHeaderComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".back {\n  --ion-background-color: #ffe073;\n}\n\n.txt {\n  --color: #cca900;\n}\n\n.ilbl {\n  text-align: center;\n  --border-style: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksK0JBQUE7QUFDSjs7QUFFQTtFQUNJLGdCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLG9CQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja3tcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmUwNzM7XHJcbn1cclxuXHJcbi50eHR7XHJcbiAgICAtLWNvbG9yOiAjY2NhOTAwO1xyXG59XHJcblxyXG4uaWxibHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC0tYm9yZGVyLXN0eWxlOiBub25lO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/components/header/header.component.ts":
    /*!*******************************************************!*\
      !*** ./src/app/components/header/header.component.ts ***!
      \*******************************************************/

    /*! exports provided: HeaderComponent */

    /***/
    function srcAppComponentsHeaderHeaderComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HeaderComponent", function () {
        return HeaderComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var HeaderComponent = /*#__PURE__*/function () {
        function HeaderComponent() {
          _classCallCheck(this, HeaderComponent);
        }

        _createClass(HeaderComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return HeaderComponent;
      }();

      HeaderComponent.ctorParameters = function () {
        return [];
      };

      HeaderComponent.propDecorators = {
        titulo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }]
      };
      HeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./header.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./header.component.scss */
        "./src/app/components/header/header.component.scss"))["default"]]
      })], HeaderComponent);
      /***/
    },

    /***/
    "./src/app/components/menu/menu.component.scss":
    /*!*****************************************************!*\
      !*** ./src/app/components/menu/menu.component.scss ***!
      \*****************************************************/

    /*! exports provided: default */

    /***/
    function srcAppComponentsMenuMenuComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbWVudS9tZW51LmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "./src/app/components/menu/menu.component.ts":
    /*!***************************************************!*\
      !*** ./src/app/components/menu/menu.component.ts ***!
      \***************************************************/

    /*! exports provided: MenuComponent */

    /***/
    function srcAppComponentsMenuMenuComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MenuComponent", function () {
        return MenuComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/servicios/backend.service */
      "./src/app/servicios/backend.service.ts");
      /* harmony import */


      var pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! pdfmake/build/pdfmake */
      "./node_modules/pdfmake/build/pdfmake.js");
      /* harmony import */


      var pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_4__);
      /* harmony import */


      var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! pdfmake/build/vfs_fonts */
      "./node_modules/pdfmake/build/vfs_fonts.js");
      /* harmony import */


      var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_5__);

      pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_4___default.a.vfs = pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_5___default.a.pdfMake.vfs;

      var MenuComponent = /*#__PURE__*/function () {
        function MenuComponent(alertController, backendService) {
          _classCallCheck(this, MenuComponent);

          this.alertController = alertController;
          this.backendService = backendService;
          this.total = 0;
        }

        _createClass(MenuComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this2 = this;

            this.sesion = this.backendService.getSesion();
            this.sesion.subscribe(function (sesion) {
              console.log(sesion[0]);
              _this2.idusuario = sesion[0].idusuario;
              _this2.nombre = sesion[0].nombre;
              _this2.apellidos = sesion[0].apellidos;
              _this2.telefono = sesion[0].telefono;
              _this2.email = sesion[0].email;
              _this2.domicilio = sesion[0].domicilio;
              _this2.tipo = sesion[0].tipo;
            });
            console.log('ngOnInit');
            this.suscription = this.backendService.refresh$.subscribe(function () {
              _this2.sesion = _this2.backendService.getSesion();
            });
          }
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            console.log('IonView');
          }
        }, {
          key: "crearCorte",
          value: function crearCorte() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this3 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertController.create({
                        header: 'Corte de caja',
                        subHeader: '¿Quiere realizar el corte de caja',
                        buttons: [{
                          text: 'Cancelar',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler(blah) {
                            console.log('Confirm Cancel: blah');
                          }
                        }, {
                          text: 'Continuar',
                          handler: function handler() {
                            console.log('Listo para crear corte');

                            _this3.obtenerDatos();

                            _this3.Corte();
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "Corte",
          value: function Corte() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this4 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.alertController.create({
                        header: 'Creando corte',
                        buttons: [{
                          text: 'Continuar',
                          handler: function handler() {
                            console.log(_this4.total);
                            console.log(_this4.descripcion);

                            _this4.corteNew();
                          }
                        }]
                      });

                    case 2:
                      alert = _context2.sent;
                      _context2.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "obtenerDatos",
          value: function obtenerDatos() {
            var _this5 = this;

            this.total = 0;
            this.ventas = this.backendService.getVentas();
            this.ventas.subscribe(function (ventas) {
              var descripcion = '';

              for (var i = 0; i <= ventas.length; i++) {
                console.log(ventas[i].montoventa);
                _this5.descripcion = _this5.descripcion + ventas[i].descripcion;
                _this5.total = _this5.total + ventas[i].montoventa;
              }
            });
          }
        }, {
          key: "corteNew",
          value: function corteNew() {
            var date = new Date();
            this.backendService.crearCorte({
              "idusuario": this.idusuario,
              "monto": this.total,
              "fecha": "2020-12-16",
              "hora": "" + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds(),
              "descripcion": this.descripcion
            });
            this.ticket();
          }
        }, {
          key: "ticket",
          value: function ticket() {
            var date = new Date();
            var docDefinition = {
              content: [{
                stack: [{
                  image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYCAYAAAC+ZpjcAAAgAElEQVR4Xux9B7xlVX3ut3Y55bbpDDDSBKQISlEUgwUQeyFWTGISa95LNIlRkxcTE42mvGhiRE1ib1EjioqFYgEfQkAEASlSpYxDmT5z7z1tl/V+3yrnnHvmzty5/ZT/5nc5c+/Ze5VvrbP3d/7l+yvIIQgIAoLAAiGgtV4H4AAAjwPwWACHAdgA4EAAawCMASgCiAEEANQ0r/yb/+HI+O/pDu3+yNf2n9z93v6aAKgD2A1gK4BHAWwC8ACAewHcDWCzUmrLAkEhzQgCgsCAI7C3G9eAwyLTFwQEgXYEtNYkSSRLJwM4AcDhAA4CsBrAKIAhAIU+Qa0BoAJgHMB2AA8DuB/ArQBuJClTSpGcySEICAKCwF4REIIlm0MQGHAEtNa0JpE8HekI1HHu3yRVtDqN7MOKNKjo0WI2AWCbs4T9CsDtjoDRIkYSRquZHIKAIDCgCAjBGtCFl2kPHgJa64Od9ek3ADwVwDHOnVcePDSWZMa0gtHleCeAawFcTSuYUuqhJeldOhEEBIFlRUAI1rLCL50LAguPgNaabju68Z4M4Az370Nc7NPCdygtzhYBxoJtdC5Hkq7rHPGiO1IOQUAQ6BMEhGD1yULKNAYTAa01Y6JOAnCWc+/R1UeXnhy9hwBdjoz1ugnA5XxVSjHmSw5BQBDoQQSEYPXgosmQBxMBrTXjoU53ZOpsAMcDiAYTjYGZdepiu37kSNc1SinGfckhCAgCXY6AEKwuXyAZ3uAioLU+0RGqF7iYqfWDi4bMvA0BSkwwputiACRctwg6goAg0H0ICMHqvjWREQ0gAlpr6kPROvUsAM9xcVP9InswgCu6pFOmrAQlJL4P4MeOdFHvSw5BQBBYRgSEYC0j+NL14CKgtQ4BPN2RqZe5jL7BBURmvtAIMHPxmwAuA/ATpVS20B1Ie4KAILBvBIRgyQ4RBJYIAa31KS6r75XOWkWSJYcgsNgIkFz9D4CvA7hKKfXzxe5Q2hcEBIG9l6AQbAQBQWCeCGitqTNFzSnGUJ3pVM/n2apcLgjMGwHKQVzhYriuVkrR2iWHICAILDACYsFaYEClucFFwOlPPRsAM/zOAXDE4KIhM+8hBO4D8AMAzFT8oVJK9Lh6aPFkqN2LgBCs7l0bGVkPIOCC02mhegmAF7m6fD0wchmiIDAtAqy/+D0AF9HCpZSSYHnZKILAHBEQgjVH4OSywUVAa83Cxp5UkVitGFw0ZOZ9jMBOAN8G8B1Htlj6Rw5BQBDYTwSEYO0nUHLaYCOgtaZkAkkVrVTnuiLIgw2KzH6QEKC46bcAfNeRLUpDyCEICAL7QEAIlmwPQWAvCGitA0eqXgiAUgoHCFiCgCCAzQC+4VyJdCPmgokgIAjsiYAQLNkVgkAHAlpr1vWjlerlAA4WgAQBQWCvCDwE4EJat5RSrJ8ohyAgCDgEhGDJVhAEAGitj3RWqte4osmCiyAgCMwOARam/gqtW0qpe2d3qZwtCPQfAkKw+m9NZUb7iYDWmoWS6frjD61VUjh5P7GT0wSBfSDAAtV0IdKyRbLF3+UQBAYOASFYA7fkMmGt9WmOVP0WgEMEEUFAEFg0BDYC+LIjWtctWi/SsCDQhQgIwerCRZEhLTwCWuv1jlSdB+AZC9+DtCgICAIzIHAlgP92ZOtRQUsQ6HcEhGD1+woP+Py01pRWoAvwVSICOuCbQabfLQhMAPiqI1oXd8ugZByCwEIjIARroRGV9pYdAa019/Xvuh9mBMohCAgC3YkAayJ+HsAXlFK6O4cooxIE5oaAEKy54SZXdSECWut1jlS9HsDxXThEGZIgIAhMj8DtAD7jiNYWAUkQ6AcEhGD1wyoO+By01se2ESvGWskhCAgCvYkARUw/7YjWHb05BRm1IGAREIIlO6FnEdBan+GI1e8DiHt2IjJwQUAQ6EQgAfA5R7SuEngEgV5EQAhWL67agI9Za/1SAL8H4DcHHAqZviAwCAh8k3FaSqmLBmGyMsf+QUAIVv+sZV/PxAWuM7aKwesis9DXqy2TEwSmRYAyD19grJYExMsO6QUEhGD1wioN8Bi11nT9vRHAmwGcNMBQyNQFAUHAInATgE8A+JRSiq5EOQSBrkRACFZXLosMSmtddsTqDwA8XhARBAQBQaADgVvbiFZV0BEEug0BIVjdtiIDPh6t9WibxYrZgXIIAoKAILAvBO4E8HFn0RoXqASBbkFACFa3rMSAj0NrvRLAm5wr8KgBh0OmLwgIArNH4F5HtD6plNo5+8vlCkFgYREQgrWweEprs0RAa73WESu6Ag+b5eVyuiAgCAgCnQg80Ea0tgo8gsByISAEa7mQH/B+tdYHthGrDQMOh0xfEBAEFh6BTW1E65GFb15aFAT2jYAQLNkhS4qA1roE4G0A3grgoCXtXDoTBASBQUTgYQAfAfAhpVRtEAGQOS8PAkKwlgf3gexVa/1aR65OHkgAZNKCgCCwnAjc6EjWF5dzENL34CAgBGtw1nrZZqq1PssRqxct2yCkY0FAEBAELALfdUTrcgFEEFhMBIRgLSa6A9621voYR6wYwC6HICAICALdhAClHeg2pMyDHILAgiMgBGvBIZUGtdYjjlgx1mqVICIICAKCQJcisIMkyxGtiS4dowyrRxEQgtWjC9etw9Zav86RqxO7dYwyLkFAEBAEOhC4xZGszwoygsBCISAEa6GQHPB2tNbPccTqeQMOhUxfEBAEeheBSx3R+n7vTkFG3i0ICMHqlpXo0XForY8A8FcA3tCjU5BhCwKCgCDQicCnAfy9Uuo+gUYQmCsCQrDmipxcB631GwG8G8ChAocgIAgIAn2GwIMA3qeU+lSfzUums0QICMFaIqD7qRut9XEA/gbAef00L5mLICAICALTIPDfAP5OKfVLQUcQmA0CQrBmg5acS6vVW5zV6gCBY2YEtNYzn7SPM5Qa7I/oTPgJPvveX4LPgn3+Njtr1kfn9YGWiwcKgcG+ew/UUs9vslprqq/TanXu/FoarKtnIggzoSEPSCEQ+9ojM+0v2T8LRrD8MnzLWbOoCi+HILBPBIRgyQaZEQGt9Tuc1WpsxpPlhCkIzPQAnAkueUAKwRKCNdOnZO/vL9Lnb7ezZn1w7iOTKwcBASFYg7DKc5yj1vp0R6yeP8cm5DJBQBAQBPoVgUsc0bqmXyco85ofAkKw5odf316ttf5rR64KfTtJmZggIAgIAvNDoOFI1vvn14xc3Y8ICMHqx1Wdx5y01s8A8B4AZ86jGblUEBAEBIFBQuAK3jeVUlcO0qRlrvtGQAiW7JAmAlrrdzGAE0AosAgCgoAgIAjMCoGMiUBKqX+Y1VVyct8iIASrb5d2/yemtT6FZm4AL9j/q+RMQUAQEAQEgWkQuJjhFUqpnws6g42AEKzBXn/qWv2xs1qtGHAoZPqCgCAgCCwUArucNev8hWpQ2uk9BIRg9d6aLciItdbHOGL1qgVpUBoRBAQBQUAQ6ETgAke07hRoBg8BIViDt+a0Wr3ekasNAzh9mbIgIAgIAkuJwCZHsj6zlJ1KX8uPgBCs5V+DJRuB1pqEikHsJFhyCAKCgCAgCCwdAiRYDIIn4ZJjABAQgjUAi8wpaq3pCiS5omtQDkFAEBAEBIGlR4CuQpIsug7l6HMEhGD1+QJrrYcBMG2YwexyCAKCgCAgCCw/Agx+f5dSanL5hyIjWCwEhGAtFrJd0K7W+jQA/wLgjC4YjgxBEBAEBAFBoIXAVQDerpS6TkDpTwSEYPXnutIl+DpHrlb16RRlWoKAICAI9DoCOxzJ+myvT0TGvycCQrD6cFdorVnl/e19ODWZkiAgCAgC/YjAvyil3tGPExvkOQnB6qPV11of76xWz+ujaclUBAFBQBAYBAQuddas2wdhsoMwRyFYfbLKWutXOnJ1SJ9MSaYhCAgCgsCgIbDRkayvDdrE+3G+QrD6YFW11u8B8Ld9MBWZgiAgCAgCggDwXqUU7+ty9DACQrB6ePG01ocC+FcAL+/hacjQBQFBQBAQBPZE4EIAf6aUelDA6U0EhGD15roxS/AFziV4bI9OQYYtCAgCgoAgsG8E7nAuw4sFqN5DQAhW760ZydU7AfxzDw5dhiwICAKCgCAwewT+XCn1gdlfJlcsJwJCsJYT/Tn0rbWmAvBb53CpXCIICAKCgCDQuwh8RCklFTl6aP2EYPXQYmmtWb+K2YJyCAKCgCAgCAweAl9TSrGurBw9gIAQrB5YJK31agDfAvD0HhiuDFEQEAQEAUFg8RD4CYBzlVLbF68LaXkhEBCCtRAoLmIbTjz0IgBHLWI30rQgIAgIAoJA7yBwD4CXKqVElLSL10wIVhcvjtb6bGe5GuniYcrQBAFBQBAQBJYegQlnyfrR0nctPe4PAkKw9gelZThHa/3bAP5rGbqWLgUBQUAQEAR6B4HfUUp9qXeGOzgjFYLVhWuttWahZhZslkMQEAQEAUFAEJgJgXcopf5lppPk/aVFQAjW0uI9Y29aaxIrEiw5BAFBQBAQBASB/UXgX5RS79jfk+W8xUdACNbiY7zfPWit6RKka1AOQUAQEAQEAUFgtgh8SSn1O7O9SM5fHASEYC0OrrNuVWv9QwAMapdDEBAEBAFBQBCYKwI/Uko9e64Xy3ULh4AQrIXDcs4taa1vBHDSnBuQCwUBQUAQEAQEgRYCNymlThZAlhcBIVjLiz/rCrJS+iHLPAzpXhAQBAQBQaC/ENiolDq0v6bUW7MRgrWM66W1po7J8DIOYa9da63Ne0rJFunG9ZExCQKCgCCwHwhMKqVER3E/gFqMU+TpuRioztCm1noVgK4ucyAEaxk2hnQpCAgCgsDiILBaKbVjcZqWVveGgBCsJd4bWusjAbDMQVcfQrC6enlkcIKAICAIzBaBo5RS9872Ijl/7ggIwZo7drO+Umt9GoCfzvrCZbhACNYygC5dCgKCgCCwuAg8RSl13eJ2Ia17BIRgLdFe0Fo/D8AlS9TdvLsRgjVvCKUBQUAQEAS6EYHnK6Uu7caB9duYhGAtwYr2Yl1BIVhLsDGkC0FAEBAElgcBqV+4BLgLwVpkkLXWb9Van99r2XhCsBZ5Y0jzgoAgIAgsLwJ/rJT6yPIOob97F4K1iOurtX6P1vpv2YUQrEUEWpoWBAQBQUAQmAsC71VKvWcuF8o1MyMgBGtmjOZ0Bi1XAM6f08VykSAgCAgCgoAgsDQIiCVrkXAWgrUIwPZizNUiwCBNCgKCgCAgCPQGAhKTtQjrJARrgUHttWzBBZ6+NCcICAKCgCDQmwhIduECr5sQrAUEtJd0rhZw2tKUICAICAKCQH8gIDpZC7iOQrAWCMxeUWhfoOlKM4KAICAICAL9iYAovi/QugrBWgAge6G24AJMU5oQBAQBQUAQGAwEpHbhAqyzEKwFAFF70agFaEuaEAQEAUFAEBAElhsB1WvaQssN2DT9C8Ga56JorScADM+zGblcEBAEBAFBQBDoJgQmlVIj3TSgXhuLEKx5rJjW+kEAh8yjCblUEBAEBAFBQBDoVgQ2KqUO7dbBdfu4hGDNcYW01jcCOGmOl8tlgoAgIAgIAoJALyBwk1Lq5F4YaLeNUQjWHFZEa/0DAM+ew6VyiSAgCAgCgoAg0GsI/FApdU6vDXq5xysEa5YroLX+GIA/nOVlcrogIAgIAoKAINDLCPy7UuqPenkCSz12IVizQFxr/acAPjSLS+RUQUAQEAQEAUGgXxB4m1Lq3/plMos9DyFY+4mw1vpFAL6zn6fLaYKAICAICAKCQD8i8GKl1Hf7cWILPSchWPuBqNb6DAA/2Y9T5RRBQBAQBAQBQaDfEXi6Uuqqfp/kfOcnBGsGBLXWJwC4Zb5Ay/WCgCAgCAgCgkAfIXCiUurWPprPgk9FCNY+INVaPwbATQDWLDjy0qAg0AUI+CIEItrcBYshQxAEeguBbZQqUkr9ureGvXSjFYK1F6y11lSwpRzDU5duOaQnQWBpERCCtbR4S2+CQJ8hcC2Ac5RSrGgiRwcCQrD2TrC+BuAVsmMEgX5GQAhWP6+uzE0QWBIEvq6UeuWS9NRjnQjBmmbBtNafBPDGHltLGa4gMGsEhGDNGjK5QBAQBPZE4FNKqTcJMFMREILVsSO01h8A8A7ZKILAICAgBGsQVlnmKAgsCQIfVEq9c0l66pFOhGC1LZTWmpvjn3tk7WSYgsC8ERCCNW8IpQFBQBBoIfDnSikaKeQAIATLbQOt9QsAfE92hSAwSAgIwRqk1Za5CgJLgsALlVIXL0lPXd6JECwAWutDAVwG4NguXy8ZniCwoAh0A8HS7pseX6c7ZrpJ+evNtXtrhO+pHBoBgBy5eYX7f6vX6fvKpzRtf7OHbcX+a8q1042jo/HWvHMoBNBgy60WfcszzX9BN4Q0JgjMH4E7ADxXKfXg/Jvq7Rbks2sJ1tcBvLy3l1JGLwj0HgIkGZnlPsgVoNwdSTuCEihLOdp/N//m+WRTSpnrQk9N+F7zh+/ntlG2qzIkSiEDCU3kwFIIHTUypyCDMs3agRgCaoiZ6RKp+Zd9j//ntfa3wIyzeUPVjii1Ey0/N/fq6VSO1FxN2jcdwbLtTtOeH0TvLbuMuP8RuFApNfBZ+ANPsLTW7wHwt/2/32WGgkD3IZBlliQZDtRGPLI8Q57nCMMQYRvZ0VluSA9JEAIFFTmiRG6iMwS5tpRHObqTpXbSZGARrUSW0PF00iYSF57vyZF9zdmUeUUQONZk7Va81nImS7R4pbc57UGu/Gke9jaC5a1gpFV2NPZo/Wuqha1JsPbSZvetrIxIEMB7lVJ8vg7sMdAES2tN7Y4LBnb1ZeKCwHIi0G7dyXNkOgVo+Qla5qs0TRGqAEForUokWHxVJD60KOUamkSrzZbkp8RWyKt48EaXky/5X1wXWdMwRNJGByLbUi0rWCehaTbuzGSha2Bfd9K296wbsHXs/bI9XYXLuVTStyAwRwRepZSipuRAHgNLsLTWxwO4FMAhA7nyMmlBYLkRMByFvj5tfYDGN0dK5EgI36P1yrv8+Hf+O03tDxlTsdzyCRqfXQiQ9JCRIUCtVoNSIYIgQBSE1krm22PTeQpNQqcUgsC7De0QsixHSCLX7L8NMP838qB2E5b1MzZDwexMfMQXXZPtjI2/eYZnY8OmcxE2GaIbejtF8wRyuZdS+hcE9oLARgDPU0rdPogIDTLBuoQLP4iLLnMWBLoCARPYRNLkKEOSIN01jq2bN2Pbo5tR2bkTOkmhkgRhDgxFBYyWSxgplVEwRAwolIsISwVgZBgYHQbKJaBgzF32Z3jEvhoeo6ET25eKCpauGBJn38uzHInS0GEEZQha6/ZoeFQOhN7q1h7r5XkSuZiybsSWK9GSqhA5QuOSdCTRDIPuR47Vkbi9LUqHa9HHg3FMU0fZFasqgxAEOhG4VCn1/EGEZSAJltb6gwDePogLLnMWBLoGAQ1kjRrCkAQotFYsxliNT6CyYzcalUn86pe/xOZfP4T777wTDz+wEZO7dkEnNtYqynOMRCQnOXKlEJWKGBobxYp167By3RqURsdQGBnB2JpVWL9hA1YfsA4jYyuAYhGIiwDjtxhsFUf2b4ZFBUCokEAjNc5Ca9VyhikTM0+SZYxtHkharNwPA+5NOFgbyCRVnmCZd5vkjJa22J7ZfkFnYPxeCBYv49UDeRPvmk0sA9lPBP5FKTVwAt4D99nUWr8OwGf2c1PIaYKAILBICJBHJDYX0DAMBnxbImPdhipLEdDCxED4pIFkooKtjzyKe+68C7ffdiu23vsr7L79LgylKZRhNrRCZYak5al9LQ4N29EHCkEUYWhkFGvXrcO6A9djdM1qHHT0kRhetxbrHnMwcOA6YGzEBMNzPA0Fk3UYFAoIg2JTiiF3QfZBwJxDH+5uu6FFqT3uy8bCO1LFeU254zLo3roITdB+J9FqI3Ce5bWC9K3bMeyUh1iktZJmBYEFQOD1SqnPLkA7PdPEQBEsrfVpLu5qVc+skAxUEOhTBEhOmONnDTrW8WXVpFpEixRE6dzESjHYvelOy1OgVgceegTj99yL22+8Gbf+/CZsuvd+NHZNoKwUymEMXU8QGQ+hlVMgOWJ2ImldQyns5hiKIeJSEaWRUaw8aD0OOeooHHb8sViz4SAceuwxwFAZGB4GYroVXdyYCqBNVmIrbstYtTxR8imRnWvXEZ/l3X1eZsJ5K1sWrfY7tLvWWsgsRsxhHKibeJ9+FgZkWjtcPNZ1AzLfwflsaq35VZZB7WfMZnG9EOPervF6ObNps5/OFXz2vZoz4TPTXuj3/dXuDWvHwhMuuvCsO86d6eO1HNHRSRWKQe2M5ZqoId+yFQ/d9Sv88robcN8tt+HR++6HqtVNHFesFaIgcNmCdOspNNgurVs0LuUKOrdipEFUgIpD5IUChtavxYZjjsahJx6P9Y87AisPXo/y2tVQ5SEgjxgIZi1TtJ7RrFSIDBHMmOEYOruc7cZa6PxUVItg+lh5/77OM5MtGRi5ial+wCmYeYGwmTbSXt7v9v010+dnpvHPdP1MsM3U/kzX9/r7M+E3B3yuciRrstex2Z/xD8yXH631hwH88f6AMuVGP8MNbA4bbLZD6OrzF+ED2NXzne3gZsJnpvb6fn81LT5TkbAfO21dhc2sQv7NZxjaGPEspBXJ2ZHyzKqVUvtq9ySwcxfShx7BL356La6/6mpseXAj8loDeaNu4qiKYYA4yUC7VJApqFyjoCIUwshobdWTDOFQEeNZA7uSBnarHPlQASs3rMchjzsSBx1yKE594mlYc9AGYMPBwPCQlZiIQxvfxViuNEMQF5shVhwaT4kYcgagpnIEJFJt33VpsSOxso5Kp/k100aZ4/vdvr9m+vzMNP6Zrp8Jtpnan+n6Xn9/JvzmiM/5Sqk/6XVs9mf8A0GwtNavAvDV/QGk85xF2mBzGUpXXiP47HtZZsJnpkWd4w1spma75v3pLFhGScG9Ya09JFqdgeD8g2MpXtkhcZHnsZd2SE0cFuhOrNaAhx/G7ddfj2uvvBJ33nY7ki3bcGgOlFNtZBwoapplGZIkMfiEUQSjwxVHiIoFk41YSxqoNeoWv0KMah4Cw2Ws2XAwjj3lZJx4+lOw7oTjgNWrbCwXSZcKUU9SNNIMxUIZhYLNGqzWUpSGImTI0EgaxmIVhQVj6cq0HQfPb6pATMHEDoHB9fM5un1/zfT5mWn8M10/E3YztT/T9b3+/kz4zQOfVyul+l6Dcp4fz+7fPlrrDQB+BOCYuYx2ETfYXIbTddcIPkKw5rUpOzPmTFB4G8HyjU8XBM6/MYjLyyQ0U/0sGUszjYgBWHQrMl6rkVjTUSNF7YEHsPnOu/Gzb16ErXffhc2PPmp0sspxAVkjMcH1w4USdJIgM0H0mXk/ZsajC3fPwhC1OEISR0iDABONBnY3GiisHMMRJ56Iw447Fic97alY/ZhDENHCVXA5f9T9MgrxGlmjgpB/d4r0JFZN6QbXk+3PHs0YrSYuel4kax4PyHkt+/5ePN/7y0zXzzSObsdnpvHP9/2Z8JsHPncCOFsptWm+Y+zm6weBYH0awOvnugiLuMHmOqSuuk7wEYI15w3pU+IcqWoyCMcijHXGBYu3i2t6rkXDVVqzWXsZkwidrBTF4L0SQr2RYKQQW70oWrPqKUANLEO6KsDOLag8+ghu+9nP8dMrfoxH77oP5URjmDFZk1WUOChatOi2i5QRJU10gkaWGs2sJIxZvRBxGKEcF6F0gKSRQasAqlBEJdAYPmA9DnvC43HMk0/BYScei9GDDwRWjgCFEqXoLdkihXJaXTRh5UojzTKEkXUv+pI8ewTB04k4j7v4PB6Qc1722Vw43/vLTNfPNJZux2em8c/3/Znwmyc+n1FKvWG+Y+zm6+fx0ezmadmxaa1JrEiw5nws8gab87i65ULBRwjWnPeiSaFrExr1Ad1eFNQIcTYjsKaoo3uLjpdE8B5E/+qz8/x5OstMnFNkgtm1iXuyCqAZUK0AjQyoJ9h0/Y348be+jbt/9nNDsIZzjTizFq3IlPDJkRv1d8o+hMijAEmSAYzX0iEKOoROM9aVho4iBMUSJpGiyvOGighXjWD9kUfg5DOeiiecciqKGw4D4pKJ1zJ+UfZhdLpsVUSO2hJKG6Vl5uvZo73LCcHaxwac6f40096dJ4GYqfmuf38m/BYAnzcopfpWNqlvCZbWmi5BugbpIpzzsQQbbM5j64YLBR8hWHPfh77QcSvSveUJ5L+8uEJbCHi7q5A6VXkNWZgh0GErMNwItNui0HFURGosUAEiuuLarWUAqpM1lIdKNsarXreldlho+t57cfM11+CSr12AbPtOpDt3I2rUMYQAsdYIsxQ6S00GYwZtKiGGYWzciO7LnclG5HuNNAHDw0jGSMxSQ6QCZOUy1hx/PI5/yul42pnPQPFxRwNFBsdb8dQ6pSlKJaeVZaliqK3cBKW1zEHl+XncxRfgATn35d+PK+d7f5np+pmG0O34zDT++b4/E34LgA9dhHQV0mXYd8c8PprdjYXWmkHtDG6f17EEG2xe41vuiwUfIVhz3YPUcuJ/e7Aelz1n8+i8rAHlFTqiulUGHaTI2jShbPkbDaWcPpVxwcXN4CV6CRnM7o1n3nDEBESyLFO7meyFJyYNYGIC9119Na66+DLcd/MvoHeOo6yBQp4jrCUoG+F3bchckmfI8tyQLv/gYZB8HBcRRRF5m9Hg8hH81SDAznIRk4UIpeEhHHzkY3HK056Gk552OopHHAqUqC5PEa8AuQqR0+1oCKZ/td7FFsGa/naum+JcnpO5ckEG3KnVDKdLOvDruxwPi/neX2a6fqa9uwAEYqYuuvr9mfBbIHwuUEq9uquBmOPgluMzM8eh7v9lWmvKMVCWQQ5BQBDoYgRIsvZ2MO5oj6OTASjqVnnCMM35bIBBWYZMTNNTm0xEqxPt5zYAACAASURBVGm2lxlXIipVKzA6WcHmn9+Mqy/9Pn5x7U8xvmU7RrMM65MUca1m9K5SnZv4rEK5ZLISx8fHUS4NG1IVqchYuGi8qjNwPtPQEdCIc2QhsxgjU5qnnmmMrFmHE05/Ck44/ak49LQnA+vWAuWyjRszxawj41llu0Z81UhwZYgYwO/mSDJn3gpsHoAVfLCSF6SXxiZorHn2ej/3va+GD7TvsCb25ROkiz8w/Tu0P1FKnd9v0+u7j4fW+hQAlwNY0W+LJfMRBASBBUSgPZbJBcYbQ5YhHAxdpxUrRWSkHujWCw1bye6+Gz/47iW4/oc/QPbARowww9AEulsR00atilApjI2NoVKpIE1yY90iiQqDyJAvpUIoZhGiinpWMySwVBqGDkJMJhnqLBxUKqN84AF40lln4bRnn42Rox4L0J3JcRVLVm/LxKk5JYsGxUmdi5Ix86EN/m/npKyJ2NIVo6xFy4I1E8myVMwRrDZiuoArIk0NLgK7AJyllPp5P0HQjwTrewBe0E+LJHMRBASBRUCgnWA5iQdfW9ATLBInQ1EYBF+pWHcjJRWqdWDbFlx36cW48uKLsenOe7E2LKKcZCinOYoqQL1aQ3GkZOKwWHMxNRYnZaxOKqWMRAOlUgGNtI46SVwQQdE6RYmJ3CrAF4dHsKNaM1IQR5x0Ip5x7gtwzBlPBQ5YCxRCTOYJgihGARFCQ5YcYco1MkOylLGaeQULa8mz9R8zJz3RtPC1Q9wM8vJ/7LAOCsFahA058E1erJR6YT+h0FcES2v9LgB/308LJHMRBASBRUJgGoLlsw9JsHhUJiYwMkyxT5bj0TY2y6ugMkYrS1B75FH89OLv47rvfR/1jQ9juJEhridGIb6R1hDGAfLQ1kDkERuVdlucOqklKBaLCIoxGvydRapBDscC0zF27tyJ4RUrkRcL2JXWMBForDz0IDzpzGfilDOfgdVPOAEoF50lylmz8hwp1eLjonEdUt2eyYkmXoa6YBQydU7DiAFcHYH/LbSdw9BwTNe2f1MI1iJtyoFv9q+UUv/QLyj0DcHSWj/DuQanRm32y0rJPAQBQWBhEdgjnstyDRt2b/9lc/aANGmYAPgocMHzhmhlQBwjrVaNAjse2YbLP/sFXPWtb0PtnMDKKEI2OYFSHBheQ4tVliVG2otB75EKkexOUWDdwzBAonNT6UeHyli7mEU4OjqKepqglqQIwhBhqWD0sRh8rIeGcfRTnoRnvuxcrP6N04AgxWQAFIfHjG5WrVrFcHHYsSlbDFEzhovczomX2sSBGWCd7inRtHDtJe5tYVdKWhscBMj96Sq8sh+m3E8Ei3FXZ/bDosgcBAFBYIkQaCcX7m5oOYcNnc91aoPJw9BasRgbhdT8m+dVsgRDYRGqXkNItyE1rR54ED/5ygW48tvfASYnUajXESNHIaB70LfJIHqgEAwhyGyQOvthfFbEYtFRaFx8uyuTRuCU1ieOge7FrN6AbuQISkVMBAEq5SJWH3cETn/J83DqOc9GeOABNqI/im1tRh/t7sbcPmUmKU4hWNORLSFYS7QZpRuHwBVKqbP6AY2+IFha678G8L5+WBCZgyAgCCw/AsZCZLxpFPtk9p1qWrcoLZHkqZFdYGkdvkHixAByU5KH2gm7d6Nyx1345mc/h+2/uh877t9odLRGCgWEbDtLoLUy+li0ZpWCCDE1ruop0qSOTOfQNDYVIqg4QkNnxnJFgVSV5oy4QlQqYnuthtKKFcbKNZlnOPDoo3HKOc/CCWc9E8PHHmXU5rO4iJg1Do1jMjCGN59ASP7Vflh5031YtWaKzVr+pZMR9AcC71ZKvb/Xp9LzBEtrfTqAH7P0aq8vhoxfEBAElhaBaQxYdgCMt+JhTDyWkNRTlsBh4LjL1Gsrg2isXlmKkIrvZFt0Idaq5vXuSy7Dj795EX59+52IqnUUsxyFhBl/CrpAJfg6wgQoBwEMDcqtC5A8rUaXYhyBYemejNGKRouXZnHoQmwyFaM8wNDwCGp5jm15hjUnHGNI1lmveQXSkSFEw8OuRBBjyVxMFSUc3K8e9faah02yNWVJOoUcxEW4tDt2YHprAHiWUuqaXp5xPxCsiwE8v5cXQcYuCAgCS4+AjbKyGXV71Przw2kP5nbx4F7KoRnH1Mzdayv74+1d1K5icPuWHbjx0h/gJ9/4DjbfcQ9GahrUaAdqyHPGZmmUSwXEQYh6rQIGnxvrGMvwcJx0DTKOKwjMTyO0VXViqr0zAdFpfbEWInXlG2GACsVN167EqS96Hp7+ypdg6KgjzVh0rqGCojG7JRFdobyGYf0szBM5S5flYaaG45R62kKwln6nDmyPlyileloRoKcJltb6HQA+MLDbTyYuCAgCc0bASBU4LXmX19eq9efNVp2t+zit9kBxL5ZK7uFdaIaM2Tgu6mKVC0WgkWP39Tfh8gsuwp3X3IBsx3aMqTqyagVDYyOoVCYwOTmJ0ZEhS5ryHHFmMwCN1Uo5chUoS7CgUUqt1czLgIY5tbgo6hUiCQPkIyN4uDEJHLAGp7/k+Xj2y38ThQ0brPx7uQB2VOcogwChcXKyVSpl8f8tUVFPtKxVq51kiQVrzhtQLtwfBN6plPrg/pzYjef0LMHSWp/sXINj3QisjEkQEAS6GwHylsQN0bvDmsWUPcHamw/R3zkNoaLlyjXk5QyctSsF46VIenLkuyYQlIZNpw//+Cp89WMfxfabf44NK0axZcsWRMUIK1aMolGrIA4jY70KcmXK45A4mQxDEiClDNlimyGSJuGx73E0NhifFClLGOMeQYcxxpVG+TEH4hkvfwme9MJzgHUrgBUjNmaMFrIkRcL6jcUh009ixFZZZdFasdiqJ1rWvmWJnxyCwCIisNu5Cm9cxD4WreleJljfBHDuoiEjDQsCgkBfI2AtWG2SBe3SBXuzYPHvPvPO3D1ZiMYLSXmtKJthyINinjwoyWBchbWGje9ijcTdO3HLBRfgh1+9ALu3b0OZmYpZhjjP0aD+1tCwUYb39QdNQ8YVyIB7WpdyQLF9jsGSK7oRTeC6DozbsBTEiHSIRi1BFoYYD4FH0yo2nPR4nPmyF+Gk5z8XGBkGCgU7L8pNMIuRhMuQrFaFIU+ubASa0wPrqGXY1xtGJrdcCHxLKfWby9X5fPrtSYKltX4LgI/MZ+JyrSAgCAw2Ap4EtdtimjfEabWhnCuOVitDdFzMlbnIkiuSEn8YKuR1poy5LEFK9XS65nhNkgBbtqD6wAP4xmc+jzuvvQGliQqiyRrWFMvGRZjnqSVOAZ12LSuWHyfdg1rlxqKVO4V29h9SWJQ/uUKtVjOK8EEcY3yigrhQQqlUwqOVCaw+4Wic88qX49gXvRgYLgNpavkiS/KUCsiorWqyKa270HAwQ/RcJJoQrMH+EC3d7N+qlPro0nW3MD31HMHSWh/nXIMUe5FDEBAEBIFFRmAfJZCbRMwSLC9U2szG0zByDvTC2fc1kqwBqpaSHFFdCxMTwPbduPbCb+PKr1+IfMt2FCpVlBnETlVSxompHLlPAPSEzhE46xZ0h8qtajsdhTSUMasxLqLSqBsSODayArrWQDpZR2lsDA/nCSZC4NgnnoQXvebVWH3mM4FyyRaWLtC1GJp+tSsKbRyPrn3bY6vA9CIvgjQ/2Ahsdq7CX/YSDL1IsL4C4LxeAlnGKggIAl2KwF5irGx4ehtxcb+1Rxz5WCdHMyy76mgvZeafs/zkjGnKMxRZ7Jknmi4MezFFpZFm2HrNNfjaJz6OjTfdglUqQLHeQCHLEdG9SJLlXIC0KtFqpZVVlg8Yp47cBbz7kWvoQKFSrSEqFkxJnrSeIk8zxEGMNM1RGBpBGhWws1FHY6iEU88+Cy/83d9GeMLxjmTFyI1v0FrPhGB16T4ejGH9t1LqNb001Z4iWFrrNwL4ZC8BLGMVBGZCYFpvVMfj3X5Q3eO9XTpgL5qQ03+wLWnwEUNensD/PtM4p7zfdtGsrp+G0Owtjnyf45k6ieap02O5pwWqhc/UIO2W27CFlW3c/j5lHQyW9npDc7z5yp9IcqWAhmNetFYxT48/hmClORoMYlchYuMyrAPU2Nq8GVd/+au4+AtfxEg1xVCaopRlCOkyDCzJSgKNPKAIagFKK0S5Nm5Bm1GYW5ciRUZZeLoQm+TGRqNhleKjgpXCckFb1NdShSIacYjtaYLy+vV41rkvwRmvehmwfh3rA1H8y9QxNByyzYIW2F9agVp+JToWdQ/L3qw2m5wsCDQReJNS6lO9gkfPECyt9RHONXhor4Ar4xQEZkKg/Znsn9EtuwkfxPawHqY2guWy1cwzcprnW4s2tJOLllXGRRA5hXLjqOrgT/YJ6RP1s8ReG7IgX1uQt3dP0W3EGsj0aJmfdgLk3jPimUapsyWuNMW95XiMFdkk8XDtTAfiNA9w//C3b1Hhyh+MX7L2Jptj55E0Np8ZS/G18wfbxp6Zc9PGbrW5DP1IOmUOEmYKxrEZXz2po2RchwH0g5uw44578MV//jfoLVuBnbtQoOZVCFTTGoJyhDqFTYMy8jRHKQhRDCPkSQOpToE4NLFZplxiniPKWpILtHwlobWAUTHelOExWYkKSZqaYPhobAXC1Svw2j97C1ae9ETgwHVAHBlfZ0PRARkhyVKMIDLrxD2R5nbdfPmdrFZFWGIhamvFY3zantmIM31C5H1BYAoCDzpX4X29gEsvESyy1jf0AqgyRkFgvxEg+XCfwk5CYNtgsr0lOlOtWO4h7x7ivj/PffzvvmhxazyWeHiiQJuK6YXlW8iQ+KxkORbz1GyRpub1HK/Rzsztw5kq4xSvbLuWsT/md61RYEZap1mp7ffMXef7NbFK7uBbaZo1s+g4Jqco0DrJ+99ciht/5QxbVJK4GXuN43WkVBZLEzQ+DcGa7qY4NXR9T4PNfq93x4mZZhC7QkLlKeKlImsNa6TA9l3A1t34/Pvfj7uvvQ4HDQ9hYsdWrB4bgc5T1OpUsApNILtOEqPuHkcBCqWiidmixYrCpbRsGReiwT0wNQ4NuTJuxgyaLkgKMpiY/Rw5gS8WoctFTBQiPOm55+DMV74M8WMPB1atMnUSa4ZTRabNpJYiVArFUuiseHRnOgrvyBfJFb8INGPTml8a5oqcXDfACHxaKUVvVtcfPUGwtNbPAXBZ16MpAxQEZoOAj9nx1h7/aXTaSi13FR9MJAP2Aen/b07nU6vdZehTvTxJmcY+Y2rsse6dMZ+5h+GUOwFr5WVI8xwqDCzZciVjDDlzAc/eUtQ55eY0aJdhAWNHDT1pI/EimVBGUTyyY7AMy/7wYIhSbq07zcO/xfdMoDVMoWRv5rN2KrZJl5ZvxlvickfU/OkmNW56HSezHvtWLG+HfDZLvue5zBQkuSJ5dDTaZOgx2CozcVmoVXD1Zz+Pb33m81iVaWSbt2JdYQg6aSAsFE18VaJZH5E0xraHNLFWKYqNcpt4ZqNpIbO6WgbyEOY6sx5mnTUyrQx5piVLF0sY1xrFdWtx7u//Hh7/YmYbFk2GYZ0EjcWtAcRpjtiQZcaU2RRGE7MVWQLf0gmzp/ht29LVmh+KcvXAIfBcpdT3u33WvUKwLgHwvG4HU8YnCMwKgXaC5S80n0gTsdyM+2lRBEsI/MPdPJyMOandR+i1mFyD0wUl+U8932NaPh/mfLjS/Weeuu1yBM7v556RtIilaYpGlkKnCYapn8QHO12WZkB0I7ncfvMY5R99e7Rqeedky0lpHsjtRND8ytItGhnJAkleEJmHNa09LftRy+3lvY7Nh3n7vDsx6CChe6xZ83xP/DqIWJvVcP43UNeHUV+3806TBnQYIIoVsixBRMKVU5z0J/jiP/0rwoe3Iti6C+tHxzA+Po5U5aaocxTHiAsh0modQZpiZGQElaRu6g1S+d0S6wBRBhSzwFisDMEiKSPpjQLowNo8SfhIskylnkIBeamMLdUqnnjmM/HqN70RhSNpzRrFtvoE4uEyxlSpxZo4JfZnzI1utTxfdV8mOF1vSZ0/hrP61MnJ/YHApUqpri+R1/V7W2v9OgCf6Y89IbMQBNoQmI5gNQlOG49wlhZjcGrjTdbxZe02PIVUhtFU5vTmA3svUfCmH++nse4pupiMG85k3ntiRBKWIctJxIAwsnE45qB1JctsvTz+mxYXCidxlEYmyQlr0lRmBk6yRusSn7oMmmZ0eAAUQhvczb/zhyrmJHumH/tE9i4mD5mV91SoOccTiySXEKPIbrz2JsflLSiegblXV7qvpVPVvjH3RkpbpjlXBKctLm6OG9tY+IiJn5hdPNRZiBk5GkjACK1SniKqJsA9D+K/3v8BbL35TmTbd2HtihHU61VUkpqxgJVi67YLksRkEHpyVQ+tECktV1EODCWmSg4SpOY8xmulFJEgeQy8fntgBEpHRsews1JBSELH+LixEbz0NefhCS99AXDEevNlIGkwPixGwPqJTkm+SXbd0k+BqA3LOUInlwkCr1dKfbabYehqgqW1HgHwPwBO7GYQZWyCwJwR6HyY78t60vKeme4sj7ARR+219CzZcg9t/3Dz7Xa4E5OsbixWdCcFJDWexWV8+jaAKLYkyhAApqIlJuB615YtmNi+A+MPPYS0WsH47kns2r0D47smMDGxG7XJGpKkbooYa2OB4agYUB0a3hQEEfJQIxgpIx4pmYf48NgoRsZGMbpqNcZWr0J5dAxHPP44OwYGWJPcmcmxARI9zj9yBV1sQHxoiB3djtMQS08oTYC3XTG6y5rH/lq9jAXLZxXuGfA+m71gXHNeQIvkVCnoiJmH/LGxZKSXoU4wTPX3nRVg6zgu/eh/4ueXXwG9exeGAmCoWILKMmTVupGBYEzVeG0C4XAJCQlQYGUWPMEqUpuLhkaiZyyXuRFBJeGzsW52RxWLZUxWaijRGtZIUElTJGGIeHgYjz31CXjJH74BxWOOBMZGzLrU0xxhgW7DCI1GgqF2F68Hpt1gOcX0OBvk5FxBALcAeJpSaqJbseh2gvVuAH/XreDJuASB+SDA54zTw24Zkzq/7e/Lxdd0VVmK1XmpfTjbBvwHvRlkbP7MhynPSh0hIYHKgN2TwI7dSMcnsfGXd2PXI4/ikXvux6MPPIBdW7ahvnsSaa1qrFqabixnRSJxor5SGPIBTfNUjjw1cuLQfLo7BXQVkFSQAubGasbrchYyzjLjejT2OFqeohgNnWF4bAxrDzwIB23YgEOOOAyHHH4YDjj4EGDtamD1CqAYAcXYkq6mu9NZwjRD3D0KdrWMl9EZ07xFsPmc7ySi7QtsXIv2ihZPnR/Bao9NYsxbHtBNZ9uni9QoZukUQ7RyZam1ENJtOl7Bzd/+Ni78+CfQeORhrMgjrAxj5LsrKIYhysMlIy6aRKxb2JqEceW27Qdqc0UBw9VZtzBFQHcvY8FY71DnqGc5isND2DVZMfIOpVIZWcps0ADb61UUD16Ls3/rFTj5vFcAB67lBsCkCX8vmlxN2kHbEfIe8KYpVoKw5nMLkWuBv1FKva9bgehagqW1PgbANQBWdSt4Mi5BYD4I8CHKWm8uLKWpXrBHweHpOnEkoXkxz3HBwzaAmK5DUhwWA6alxukkkR94VkErVWUcescOPPrrh7Dpgfux6Vf34+H7HsTWBzehum07iikQphmiemYEL4tamWBmupdSlSGNYdxQPkja31B8ZiGz2Cypse/4bEUjxZBrqjgZy5ORayBhpHeRAdKkX4EyxIs/RovTAKUQFmKUy0NQQ0UceOzROOCxh+NxJxyP9Y87Gli3xpZ5ocXLqZDzembN+Ue9CfD31kD32u5BbBKQdktL06W1gASrrf1mHcG25TEeVA7GZ0qSkFZolRqy5rpKBbdf/F386L++ioduvh3rgzKK1QaiJEWhXEQ1pWK8xdVmENoYLJtFSMxzpGkDURiiwCD7JDd6XCGtXVqjqlODdU1nyN0CFcMCApK8RobCUBk70wZqoyUcecZTcfZrz8Oapz3FWLLGGwkKpVFjnevwzk4VZJ0pHm4+HzC5dhAQ2AHgdKXUnd042W4mWP8J4A+6EbRBGFN72v0gzHc55mgJkCVCXnGqPY3dEJLMWVzaYlZ80p0514ZGNbWl0tAGh1sXFltOTVwSFcRRp1q4BsarGL/3Xvz6jrtw24+vxuSWbXj00UcxvmunsY4UIgpf2lIuTNfjq4nrcSTNP6xtCZf9Q651Tet8XhrnTXWvZpak1cZiXBC7J8lql7KwZMsffJ8EQBcLGDlgDdYeeRgOf+IJOOYpT8Ka44+1zGJsFIhjNJgZSdIS2sy3zLlWiRb/o02N/6V5amwvITWdXEe+y5Zr0I9gHhasdoJFN16bZYy0NPImzqYVkz5QoBFkqEMb52i5OolHrr0eF3z4P7HphttwcFRGOc2R1Kool4tI0gZCxrcxKYGB7IEyVkIGvRfLJaSNuiXgOUxslhUqtXiTOBsxUyc2r3KbgRgxjoteYwVUmG1YLGJ7vYYDH38cXvzmN+DQs55h6homBbqBS6inCYai2Eb1ZdpYOP3e90KlzQzT/dtOcpYg0I7Ax5VS/6sbIdnP2+PSDl1rfRaAHy1tr9JbOwJCsJZqP7Q7qVp9dnoGSapynYK6UXwYRWFk44fIGPhkNk8+uuEypFnD5BoG/J0xU7UGsocfwt033oxbr74O99x8K3Y8shnBZBUbRkahkqwZ4K6MdgP7sn8LOyw3doSWcPGgRWQ2FMNbq1w3iNrZkmOKnrTRQeb3oXF2dtyt2EYhis04E2pJUYRTARNKQ7Nw8egQTjvnLBz1xCfguCedguDAAwxbpfaUigtQQeiMQ9bGQlcnXZlhEDdVx/yKTHWxtgRgpxMd3e+d0xGLZDW87EFxCqfW0coSJdEMNWpKo2oIVorhrIawkaHxy3vx+Q/8Gzb/4i4UKjXkuyewdmQEeb1uiCJxNKV6CrxKo5YmxgVI3SxTu5AE2qyntWwZAuoC3ttxZwwXzyEZM1mJcQG1NEN5aBTbKpPYBYVn/9arcfYfvA7YcICxImYRw/S5moGJ8aJGF5McGlkDQ2HR1jb0JsX9Bk9OFASmIHC2UurybsOkWwnWdwC8qNvAGqTxCMFagtU2X+P5pGJfTl7Bu0ycQnuSJiazzgYdtxOwDI1GHcWojIgZebQkjI8jLLlCvTt3Y9cdd+GOG67HPTf9AvfceBPqO3ZiNIwwHISIaKECsLs6aYgYrRztDzlPtChoOR3t8wQptGln+w1Wp0iD19eargGStxbBskSg8+BDmucUoyIKhQIUVcqpFUUcCwXsShqoRQGGDlqHY5/yJJx2zrNw0MlPtEHZtOox1ssEYnsXos1Y5O+pZlaldXG2W7IsHZueGO83EDzRmnHs4QLwW7Fdbe+3Wy8Z/N4s7pxgiA1wjap1YMt2fOEfP4Q7rrwa6xEh37YLI0GIgCVzdGa0slQhQFSwpLTGgtIm66/lMrSuQzckki4GvDsCZobsXbmMq0MAKtEX4xLyyRqisIioVMbmeg2HnXoSfvMP34jRZ52BtDaBaPVKpKCgaoYQsSGztGkZ5S9P1oVkzWr7yMlTEPiuUurF3YZJ1xEsrfVrAXyh24AatPEIwVqCFTcWKEewGCPkHrLm1REsZ08yf2qkNSDLjUUicg9OTaVzE80eGUtV5Y67cP3lV+C2a67D7l8/hOrmbYjzFGNhjBGWLUlTVCsTlpTQReRq23mZBiNSSfdUFBjSlSTtUWJTGY4hGvmeZXb2Fzk+zOmCatW2c5l5/oFrEhfb3HTTEKzCMAsYN8BSPozpCln8L7OZcCqKkEeRyXqrhhq7aZUbLuGw4x+HZz3vOTjm6U8DDl7vguAYoR8bHJlNx5gtWmeCgJUD7eFjiSzlWiCC5a1YbSSqmZFgZbGmyMZ74Xuris7szxyTE+MYZlxWpQps3YnvfOIzuOnblwJbd2BtVDQxc6xhWKMmFqsXFgooBCGyesNYEGkxpDuQP7aGoZ0v3YZUvTevLk7Oqr8DKWO7yGFZNLpah6plWD0yhmJcxOZtu1AvRlhz3FE4+cXPxclv+F1gOEY1ZVzWsHFhh4wuo+vZVRJo3zNizdrfT5Cc14HA7yqlvthNqHQVwdJaMziCsgwndxNIgzgWIVhLsOqeYBkLxlSC5Y0btXoNxZgWJ5oZnO6UUVUnO6H1IgM2bsKtV12Dqy/7ATbeegfiSoKVQYRSplGiS6yRIGnUjCAlA5BzRjKTQDH4uZZYwUmXmm/infhA9uVvTF9WEtK7jgy9MIHT1l00VzeZeVBH9gFvrGDONdVyP3IsWSsDchqCZTScTI1DTok48cHtpN4RmHIxBluKlEaUEchQTRqIS0UEq8bwtFeci1POehZKJ55o5R8Y+F8qG6uhUYUPaW1pHSZeaaEIVjtP8120ES3rAbZRXz5Y3CTdUcbeYaHzzBDJDA0oamrVE0O0Lvvwx3DNRd9DaXcVcdIw+lg0EFEzK1TauFapXUYrIY8WwWolXXBfxFpNkbIwaxbkhmDxiFmTsJpgqFSAYvHqiRpWDo8iLpXwwLYtwEHr8OSXvgBnvfn3gfVrkLF0T2nInFcolg3me3iJ25IiluBTKF30DwI3OtkGVnLqiqPbCNZfAviHrkBmwAchBGsJNoB3EbYRrM7ix8Z+wsDjWt3Wh2HAcr0BbHoYWx98EJdfdCHuu/V2bNu0CSNRESuCAhq7diOspxiJSzY0KwoNiannqVH8prRCzkDjNMMQReONVpWN7aIr0jxwtS254uUWtCuP41GZ4sriHz1BmsWryWbjOPaIrfLWIRMMZojXdO5BdktriKF4KjL18OhyMla4jNIQOYbKI6jXasYlVihaNyLnyhqHkyrD1jBA4YA1OPWMM3D2i1+E4vHH2awC4rBizLxOkTnwBiUXDN507c53u7S7Cs1+sBIeVkbWEiwrJOtzF9wKUEyUDX8jpgAAIABJREFUgeMFF0PWqCHm2FLgR//6Ifz0ootRe/gRlDONlUNlUwIpTxNEtO5R88oFvHEt2lA3pNmQVkNvbcyZ2a7OguXXrD5Rw4oVK9BIamatVo4MozY+icnxCsbWrMFunWJroPGY007Fq9/6Fqyke5Zu10IRSFLoQmRjufbiHhRr1nw31sBd/y6l1D92y6y7hmBprQ8E8HMAB3ULOIM8DiFYS7P6nqjYh+nUsoJGQyhpmLgik/1XrQGbNuFXN96Ma390Be644WcoTOzCMHWlaNRIbU25QlQ0wqH8d6NWM+TDF3Cm248kygSGJwnKQ0Xzb/5496AXmeQ11mNIgjN9nFUzi9DWYfH1WPZ4tSWrvb+r5fea7gHaUq1qFZFuPv7bawTSgsaHNa1YLHjs3Jtm/DSIKWXK+vj4Mrr+qiyQzEzJQglxuYjxRo6aAmqBwopDHoNnvOiF+I1zXwIccgjyagXByhVN+QtD5BaQYPm1J8TOINSCyGWX2sI1lmA1b9beregEs+qVBqJyATrMkOR1lKMQyfZtiItFXPWxT+Lmy36EHbffhVVhZLJDWX4nM4TMBVQZd6DNELTZojbYylgzQ776UdjPBG17Ji7LuXBJWpOsgUq9YgX6izaui+V2WOIoCyNsrSVYefjheNUfvQWHPOfZNjtj1Qpo3XJJTrsXJC5raW5E/dPLwwBOUUo90g1T6iaCJaKi3bAj3BiEYM1uMTq9V50frPb3zXuOY5BYtbugfAC1sVxRb8goqmfAfQ/g+h9cgWsu/QF+fdfdKKQZVhVjlJIqwixpljgxbiVzmX1w0QJFqw5fNa06LGlDuYUgQhSHqDSqRsnbFAamirgrxOwtGB6FZhZdcyL2wctOtPETTkegpv6d5zMt379awtKKsZpKwGzPRgXePNXb7SvWZcmDIWycW/vYrSXOXW88qa4AchAgjKNmbFmjkaIQl41FJYlCjGcpduUJ1h51JJ533qtwyqteCZQLNjuTAqBmlm1lbSzbmBIjteeumWoX6nSn+rXvlIPwhHLaz2FzDZzwmWN9KWPPqAKf1gzJQrVqNtcVHzof11x4EaIdEyiyHFJmSSfdjz7JoJ1g0TXoLYYpXcqBNmrwnkObYtEMmHfuYWpmMcOVODGInkSWP9xTFJpVdCQWy9idaGRrVuD5r/1tnPra1wAjRaNXRnHV5u5xSQVNUKd5Qtk/LUAM3Ow+4nJ27yDQNeKjXUGwtNZrAdwEYEPvrKGMVBCwRMm7TtrdZt6VwwePosXIaV4x5oVWBPN8SAEdAzVqXWU5SgX+nWrqNYDZg3Rl3XUXrrjou/if712GyuatWFcoY4ihx0mGICex4sW2pIo/Ot157evkM7bsg75lPZhuLVvnTvduZz7g9L/TitEew2UyAxUfztNZxDxxas1mehdRi2DNZg/uEevDwsdBhLSemmw5FkuuA8Z1qNauRuGQA/A7b/9TrD35RGCobDS5GN4VaBI6IwFqrHZNK5MrbmyIYZMETCVYlk62lTFyavyzuhG3bTS6EElhmpa1JiAuPo+uZQC3XvANfP1j/wls3o4DohLUrgkMD5UwmdSMu5huUFNMO2kgzDSGGbxeayCIYhNzVY+cLpYTLY1dqR1j5Zwy+JaOFvut1xMUy2UkWY6cljUmHAQ5Tj/zTDz3HX8KrFsNrFxp9jpL65AsMxvRuEg5z46KT7RuMrjf0F3DeH3252x2gpzb5whsAnCSUmrrcs9zVp/rxRqs1lpirxYLXGl3UREw5Kqjh86HHd0nWlG40mbc5bQiUD8qVCacisYGozfFJwqtDjpD9bZbcPUll+BnP7zcaBoFtTqGaAug26WRQCe5jYv3QeKLOsu5N96SWZhbG4sdgxMHBeQsVGxi1SJTrmciayApxkhXDEMfsBpnvvJcnH7eecjoblzN74Ihksk64nLJaY8xTs4lKTjlDVuxhzuj5fi1Tr49CdbckPEysnT02cJDTcuoIX4ufo0spFYDxsdxw7e+i0s+8wXkmzbjwLCEiBppQYYsoLZWbt2BeWrI+4iKUQpYT7BhyBc1xihOylgt40aklastGN2T8c5YOSrBU29rnO7WKERUKmLXxDiKQ2UcfNIT8NoP/JMlWCtWmi8XDIIPogKTXU3pSR7+82V5ZRvBMr8LwZrr/unz67oiFmvZCZbWeqWzXh3W5wsu0+szBHjD9y4eo7rdZlloD1Y31iz/lMg06lQeL9inh1FgqidQFRskjAc34icXfRvXff8HqG/ZDDVRwXAcI+a3/yQxrhfjRYlio2/E8iZTChZ3GcbdTrACHboCxySrNhLK1ETMcyNeWqNMw+gQjvuN38B573k3sHLM5vYNDxtdp9DV7vMEy5T6aSYMeL0sT7IcwWq33s3jDmz3X4tgNfefI1jEvl6roFQsWgmHeoLbv/ZNfOX8/8BIPUWxXkeh0TDkvk4ptSgwLr6cNQkbidXIonua/bhgfx/w36xpGNggfC9S2kmwmIRAF3TCDNhAISwVkKQpaglJbAErjzkev/O2P8XqU59grIQoFow6fKgKaFQbGC0VppTW0YG2FlAXkdbuYO6yrS/DWV4EHnBWrJ3LOYx5fLwXZtha63cC+OeFaU1aEQSWDgGrjW0foiEfmuY56iwZ/LbvjQhZbpSvVeTcYgHAPGIWTB5hujwtCQ89ip9efAku/vJX0Hh4M9YXS0h27sDKYtnUh2NWXz2rm4BhlGJjSaB1YSizwcndenQ7wbIuTCuHwH8yNslojOUaOqUL1boN60MljB55ON783r9CdOIxVqaAavAm1igycVwMl6MLkXHZzR+zKdrTF8hkWtau+a5bs3SPJ20+7M25HnOdo1GdQDku2uzT8Sp+ceE38fnzP4aVqcaaRoqIIqTKEv+oTMoPNCYnjVYW3dm0VvnYMboDTfC7Ly7uGJV3+DJ+q/0wxbwpEREGqCcJGrmtbxhSn0wrTGQhhjcchFe89X/jiOc+CxgbQhpGqKYpyhTRZXudQYphq0KU1Iqe7w7q6+v/XCn1geWc4bISLK31qMscPGo5QZC+BYG5IeDv/s5F1FQ1px+llWrvH7wRBRaNaYtxUwxQzoCHHsKtl16CS7/xTWz79UNYxQfhxDj05CTWjYyiPj5upROo0RRoNJzqNuNm+Pc4bSlhz20Oi3tVLxAsEyPHWoAZ0QWKKkSBJXMSoIAQmYowEQC7iiEaB6/CH/79e3HA009FvV5HsTxqxElJ1CiXwIxPk9joXIVcNksHHAvWJjd0hsD42ayJYzQdBMtbUNlrrT6JEWPFqlhB2vFJ/ODTn8PV3/gmVm2fMJasIA4xWa+ZUjzMAmw0aihGsXEXmhqF/ILgHHS2WLSVr/CK/50Eywetc4+y9qHZw6yDmKbGVch/12oNjJRWY3eeorpiCC/9X6/HKa99lUksyKjtxRg5TbLbpiHBjuiudASS+YrL+hCbzVLJuUuNwD0uo3B8qTv2/S3r3tRavw3Avy7X5KVfQWB+CPDhxmB03wojct0D1H3pZwB74HLws3oN5TC2sVYPbcH2W27DD7/0RTxwyy9Qm6xguFhAWq2wyIlxCzYqkxgdHjGuQVoCGI/EeBaWguEDi1ID/Hs3H91OsJI0dxYWK7DKTEtqPxUygIHcEQlWrm2Nw2KMybESsrWj+P2/+FMccfZZlrCYcjMkBG4lHL9O0xyxYVjeiuU2hbnrTi97Mfu1bCNYNJ+Z1FH7wp1RyxoohAVkJrPQpBhaS1atjh98/FP46Ze+Cr1lixEHJefnXgvjALWkhlKpBE0LVw4UXVA7w8sNGQ0CY8naF8HiXExWq5PK8PFYxoUaUqQ2QG28hqGxFdieZxgvKLzwzb+HM37/tQAtaeUh4zU3au/slBNrI1icOe1tTYmL2YMnV/Q/An+mlPrQck1z2QiW1rrsrFfHLtfkpV9BYH4I0HLlFKxMNlNbjI17wFWy1FiesjxBMUlRzkLgvo244WvfxVUXfgt6+1aMRFZsk25AY6XKE5MZSH2hSqViH/oqwlChiALlFlKNnOrsJF10Fy7bp3hm9LqZYBFzg6ETWDXuMIpqUriTmXnMkOPyxiGqOfWyNNJCjCSOMLJuLd78rr/AEDMMGaBdKBmrpHEGuvXg1rBe4ekJlvfmzYzivs7wBMvX1TECYE2h0gZYhzBFQbGAdYqAZCeIgIkKsGsnLv7wR3DTpZdBjddMnUqVpAgjhYnaJGLqWbH8kAaKqbMU6RbBMgHvXujVDdG7CNu3pJknNcn45SDhvk0RxzEKpRLiuITJyUkEqgBdLGCnyvHkFz4XL3jbHwEb1tvPDhNEzBcXumLtxyxx9RjFgjW/3TMAV9/hrFjV5Zjrst2atdZvBXD+ckxa+hQEFgYBp7Le1IGi6cC6f3wAvHm06hpK/KRt34lbL/4hfvj5L2PnL+7G+kIRcVI3kgwqjszDpJrz39YlWKlVjRUhCmKTuZXXM6NjRbdJgbFYjGth+dxl+xTPjGK3Eyzizod+kJLEBoicZhZL8NCV1UBu4rNSpVAqDxtrzK4du7Bu9TroA9bgjz7xMeCgAyzJUrQ9OmkBa0iyWlHmhz42Fw5uSJfX1ZoZw32f0Rb0RHOPcT9aguX3YEPbuVHiIE8SFOmiM8bXBrBjG7707r/B3T/5KcoseZNpDEWsG1hDWHLYMMPSuQnZvon/oy6YmaM12zV1vJxQqd+StLAyro1aWSRZzNRk4Dv/rsMA1aRu9nchYfxbjDSKsD0Ejjr7DLzmnW8DDl1vakRqE+dGkmhbJsHiwVSRLt7+811cuX5hEPhjpdRHFqap2bWyLHtTa6r/gHWDHj+74crZgkD3IMBHS8LyuVmGMrV73MOU6tS5dw2ldYTQ2HLDzbj8y1/BL6+4CkMTVYwyNL5SMQ+cPYUeOue4x2OseYIR+9xDKKJ7MJrvSGYiaPORcTBuNP+gzm02JomEISZBbmQJbI0+RybywLgO6S4rpAF2F0MEpz0Rb/3wB4EVawEqmjcSxFTHd+5CI7/hCZZhIjaYyQeJzzcLrhnk7oHuyFD0u8Nby5oSImZMCZBXgfsexH/+5Xux+cbbsZaAVKooliJUG3WTVWiO3I6Ybj0W6M6D0FrqmEXZtsh7yDX46tRtSbb+dFOepxihUa2hnAcYKQwhaVDsNUd48FoMHXUY3vwP7wUOXgcMD2Oi3kCpyLBdqpk0MFIuTCFX0+2V+eyP+e5dub5rELiN9Y2VUqxcv6THchGs/w3g35d0ptKZILDACLSrsPMbQ71SR4lp5aYECXPPKKme4Yb//hou/9JXMX7vfVjFUjZpgrxhBSDB4GM+d5l9ZhSy7evU0jQ23sX80A5hXm1x5ICWASFYc1pZ45Z17ICWK5Pp6YhR3kawLAmz2Zp0lZVSvgaYKITY+ph1OO6cM/Hyt70NCGJgeMgWlnZ31qZYqzE00QXcIlj8k1VGm/vhCRZbMF12Crh6d6XrYuoNn8H3dWDHTmT3bMKn3v1+bL/lLqxgBmWeYGR0CBONiolNM+2bF0s2GeTOg4kb7ce+CJYZXtvJthalrYNZQGQ03jRLF6UpdHkI6aoRrHr843DeO/4EQyceawjsJIPkVcHEMjZqCQolm/XYfrQTLSFYc99bfXblHyql/mOp57TkBEvbvGjWHDxpqScr/QkCC4kAHxaVJEEhjp2AaIqQaemMap+cRL7x1/jvD38Uj9z6S0zevxErA4UhZqLVK0hUhuLwCCYTyrm7OnB0wziSxdIl/mFlKBRJVVv2ln2AkxQIwZrrmrYTrBa5bbncDJF1rjZPYGLHkfhajSJsHgqxPY7wvo98BCtOOgkYHjEFuY2VR1kXlrdsGjfhohEsJzTayWL2AQ71pCZ0FaMkS5UU4z++Fl943/9F8vBmxKxXSOsr3dVTCHxgdL5s+WcYCZF9Kf4r47bc+5Hq1JQvYtHvhFayzJKtMAWqORMLQhx42hPxu+/5SxSOPBS6PGwIWJnh7SS0LiZrrntArhsYBFgphjUKl1TUZjkI1hsAfGpgllUm2rcI2G/KyoS88GCWYEjXYK2O+y77Eb732c9h8823Y7VWGGUBYhZUVgkY594IMlMzMGfAMYsWm4K71gVjSJZLi/emEO/O6nzoh2LBmvP+asfU33abhYzdbXg6+5I/l3FIE7HCLqVx0lln47x3/w2wepUhWLpYRKIB8hNrWWqLw3IuwoWwYO21Jl/nY6T9d79fmRmJOsoIUdi1G1AFbPvu9/HJf/wnlOoN1HftQLkQIXQTZlwa96rd9/a104LVuRjemmRiCF2ZnfZzSMCCQoDJSKOeUZMrxHBYwFBCwdPMkNhdxQClJxyN33vXO7H6hMcDpSLyyQaCcpn1fSQIa86fgIG78I1KqU8v5ayXg2D9PwDPWMpJSl+CwEIjwAeHee4YhWq+pvZn5y5cc+E3cMXnvoLa/b/GUStXA5Uaao1JEyzNrD8WxWVGVcZsNX4L34ebyCtjd35Q/d/zKUWQF3qWy9/eYsdgcYbtmX/83VuzWu5ai0PTTUsXWcAqgFTcyIGhYWxKG3jL+9+Pw1/yErsPRkeN+hXXrRns7i1BXgR0AVyEnertrRVryy40f+ygii7LlY5qWtmCWhURiVO1gas+9h+4/IKvoVxvIKrVEBtClZsgdX9MX0uy1Xszk7LNveiLRfuzuIepOZYqbQgWxU41MwwJaRqiCBaOVpgMQ2wtBjjwlBPxhnf9BcpHHw6UhqkpAZTL8LU3xR24/J/XLh/BlUqpZy7lGJeUYGmtXwrgW0s5QelLEFhoBIxektYI+HDls2d8l9HsSe6+B18+/6O4/cdX4kAdYjTNUd+xE+VCjIAZWUqZrDTWJaTWEuOschZ3dg9vb2Qwbqm2T6bSJuIK/tU8Ltm1t4Qs6ad4odHcd3uLSbDae24vbeQJkbck+vM8wWLsEGO3uB5lDdQDhYe1xuFPeyre9PH/sHtiBQmWJTXGOmkW15slXYHw+RIsv2F8BLvrzP7ZO/Hc6PcS/M7dZ2LVc40CC4fXquZLwiX/9hFc+fULsTpXKCQZQrcHzfmUtaDV1RGuqcWebX+dBGu6VSaRjXVov2xQz6LIz0OKrNZAUSuUKOCaBYaoNopF7IgDrD3hGLz53e9CfNThNt4NdMe2xmIgaCOCS7tbpbceQOBcpdRFSzXOJb01a62/AeA3l2py0o8gsBgINAlWniGtjiMqFHHfxd/H1z7yH6jd92us4QOGgqHGfKERlmIjmFipNxDkEYpx0ZTWadTqiE2WFklXKwDYEywfDWTVlWxJHm+5YnA7o6/47d3Sr/48FpNgmcQCzz/ca+6Ct5uWwzbXWtM9q3KzIiQdY1CoZgkmV4zhkTjE//n3j2LlySebunqJYvanzRO0lSfb4rvcb/MKcm9PIPWxSCza3LYVOm/wU7MKA+OKrtc01BB3l0YRDagsAe7fiM/99Xuw5YZbMMRi2Flq9MF86yQx/PHZkJ0kyxMsxmvt61C5ckHuAaKYAfQ5UlP0OUcQRIhYqYCNpwqTQYDdpQjrTjoOv/1/3o6xo48ARseM0r4nVZ2v/fmpkFnNA4FvKqVeNo/rZ3XpkhEsrfUZAH4yq9HJyYLAIiPQysJqWRs6u2w3EBhhURNPk1Gimvni+H+f+yyu/cbFyB7ejBF++840YiMY2oAuhjYrKqcGUAEMXte0CKgIhShGlrM8iyVYPMwD0P/bBbIbcmUG0SJYfLTxIiFYc7+FeYJFbFsEd3qy2lwTvzkUZR1yqGoVcbmEXWGMzVGI57zx9TjzT/4YKMZG3sEfTiGr+bunHfOSaTD70P00haj2n2CR3CmahwJgkoQ9JB1MMEwiuLsCbNyE9/3OGzBWbaBYSxCmCVhwkW5pKrEbzJrMipmuTuerWf45t+r4LhDe73FPM/k7ta8Y2B6y7iPbZwwjBecp4UDrbqoxEg9BVxpGPT4dGcYjeR0HPflEvPXv3wcccihgpE5sKSlD+AKbaWu/lDjlrA7W6YmmqMAv8g22O5t/ulLqqqUY2tzvTrMcndb6EwDeNMvL5HRBYNEQsMWabakZZQpuUMnb3ZjdDdm7jux3dY28XrPiinRD7J7AZe/9e9x//fXYdM99GCsUsXp4zEgwsE4dkwk1v+WbT5kjcKbdoGmJ6tSwms7d0gKgZQHx4+xn69WiLXxbw95SxT/tG/s9R0NrC11aQVxAloWolYYxfMzj8Edf+jxQCKCpsu9dhJ1SGt5lN9878L7MVXsBsPOSdqsWPw8BMsTMwGikuO/bl+KL//hBjOysoFCroBQyOzLFzto4xlatBGj9MnPhPvdfReyrarNecZomZo2xa0bmwZIxH+/WuQ6eIPFLSFpv2OSPOEKNRc91hsLKUUSHHILX/d9/RPmYx5li20jrJsGA74fFIlLkYH6vIVH06/rhUShVahkuxcerW/v4pFLqzUsxuPl+vPdrjFprlsP5hSsdtV/XyEmCwGIjQIJlnT1W+JHWhClCjIz9SDXCWCHNGyjSIsGg9loN2LYLX/ib92D7T3+GwkTVuChY/oOio7VazfxOFXYqf8vRnwgYd1aYm0SFtKbRCMsID3kM3v6VLwDrVwFFqpb7ut9tiutmwzmKvCR34L3j32nBpco6rU6MGWNZHdRS/PjDH8MVn/kvrKWs28ROrF41grpOjBBpIY+hdEv3q+XWtlZXY2ltO2jlMgKjLjnDxHLtw4toSuykafPzRatWo9EwAr3JijGEJ56It37gAwAVXdcxg1OZUlM6tIrxRRUZd7zNZGhlHaSu1A5TTJZ5Cfrzw9Hds6Lg6BOUUiyjs6jHkuwtrfU/APjLRZ2JNC4IzAEB/4CxDwZrWWqWN+EXX5cGVmtMYJjlaTKN6s234eN/90+o3PcA1NbNGA1DQ6548/fFl1mM2cSozBCDMochyyVdgoAhWCpDHBXRmEzRKJQxMTaKv/viZ4DjjwaK1PC3xx432i4hWE0LKsdj3HnWEmVIVpbbwuQbN+Kifz0fP/3exTggjFFMGUuYIcsSBGHx/7P3JWCWFFXWJ3J9S72q6o2GphsVEBVRFAYdHQUHFUVAcUdUdMQZVBAUQUTFBRlRVEBUVMCV34VBZRQcEHdUEBRx31AEGmia7q6u7b2Xe/7fuZHxXlb1Vqvd1bzsr7/a8mVG3IyMOHHvueeCvDXTT+MFNOHXzvtUACoTAt9EiHULz5TvkEkEYckdHnzH+L+lbLQHFmG3xz0Wr/vgOcDifqDiIHUcBFEE3/OlWHcnjLq5B/FPWQF3kAHba0bZAucqpd4+3yaZ9+GV5/kyAL8DsHy+O9O7fs8C07VAh7TbAVbl9D3taIiiJnzHA8IQa2+8BZ/74IcR3HkfalGEQdcRUjB31axpx501izRzgWKYUJfC6R07pwUyxFmIil9FFORIqg3cq3Kc/blLUXviARIOsyc9/wncqwnkvu1lISPnoAGWDvVpTMJQYbBxIyr1OsLf/wEff+e70Pz7Xag3AyG+e64tvKi4cMZNDoWXQdb0QuFdW3CjYpJKRBqlKMzN7yNm0lb6sSYO8OQXPxfPe/NJwOI+JI4L2/UQxRl8m5UVuhw7kwvQidh2XNbby/69+24nC6wF8Bil1Lr5vP8/A2C9BcCH57MTvWv3LDATC3ARiZEJ8VzS6E0YQWt/IkWGKG6jxkVy4xiGbv4VLjvnXARr1mOxV0E0OgxXUcsK4EIgE3kh4dApL9JLGZ/Jo1kgn8mATIPqMLaQ1Oq4K4nx3s9fioEnPxG5SqFcvcCb8BRD0VpgtBSy2l69LYfmyhHMQiaEniyWuhaCfhThT/93HS4/+zw0hsewInFEh6ptp4iYitg5usT+TtmcIkmjrOnWzT6cFDqdZAt6r8y7ZbzDtLdkMWYK7WaI/pUr8ZuNa3DECf+Bw058ncg30PGWWa6Q6KVyVbHSsQ3SDnNbPoh5XwW31wPu3XcbFjhNKfWR+bTSvA6toizO7wHsO5+d6F27Z4GZWEADLK2aLmuEmXQpekihKZJ9uTJuGMYDN9yCS959DtyRcQxSXXpkBEsW9aPVbMoHGb4wu+3yQmDCGzNpX+8zO7YFCJVsKwWT3cJEoeVWcI8NfPDLX0T9wMfrOjJlCQ0R99QAZIcBWPRaCdAqpbFqwXYJj8smI21JGJyCudd/9BP4yee+il3GEtQVENiJeOrMMYFAX9LeMtpiHWkMKsIXWbJbSy4g/4qAyrxbfJ+MFAM3RVShHw1D5Lssxd/DcbzgpNfj4ONeDvQPcNeDlDpZxiPHrEVTb7LEx+oBrB37PZvH1v0RwH7zWT5nvgHWqwB8fh4N1Lt0zwIztkAnXCPpTcVlmBmmMsQWFaUzWGNt/P6qb+M7H7sU9gMb4TE7ECkS14LrO0KNJ6DiQmB22z3+1YwfyYL6IAGWZzMUHCNRLsYcBxv6+vCRK78CPHxPXSenzLWinFMBsDo1Cud1Bt6GOcueHIOxDPCQTD+IMG47a6FuuWBeHu68D5e/6/2483s3YYlFcnsMrfWgD62mpQ+jKSY/5EUCCb8W4fipACxz3fI7xffMlOnpsx20wgCRW0FQ8bAGGV51xhl4zEteCHg2Es9DYtlyTxGOlbYUeNLYfns+gwU14nfKxr5aKfWF+erZvA6tPM+/D+DQ+Wp877o9C8zaAqUtt15vWHxZF21GGOP2b1+Pr5x3AbD6AezmV1Dhjl9lGImaUtA3STJUq1XxYBFkEWzxe+6y+b0Jb8y6nb0L7HAWIMDyrQytIIKq1DHq+hhdOoj3f+0KYNlSWeClQjcPYi1Fj6n+WQKH25uDVQZYpnpA8T6YyDblDNpZG67lCMCyxwNsvPk2XHrmfwMPrEMlC+Hkplem8LOWYtCeI+pjdbMmJWtQ6+8WIGzrIUK+S+Q2ms2LSRyRrF1bIWiOYdmSRVi/YQxuXz9anodo8WK86p1vw25PO1gyOSObCSeaIO+Y933HSOKz6yksAAAgAElEQVTc4cb0g7BBP1BKPX2++j1vACvP8+cA+PZ8Nbx33Z4FZm0BTrZFwbiI4oZIZOHzKCK6+n78+Ts/xJc/fCEaUQpfCtGmUh5H/hfxRIpJ9rSoZv0kFuQF+OSdLIXlu1jfjhH09aO27yNw2v/7vBQkZogKud0pSKgBlj52GIBVAA7NOSzVTizpLURZihbDhG4FdhACQ8P42/dvxEVvewf2qvjIR4ZRq1aRJTE82xGZEq/mIRVF9gJkdUKl2oNli/sq78g1zGQAMIsztxNkcYTF/iBGR1pQ1T4McQ+0xwqc+MGzMXDQgchthdR1EadFKL+4mQngztsiOJNO9T6zPSxwhFLq/+bjxvM2tvI8vwzA8fPR6N41exaYEwtwcSm8CKGiinUKj4hrpInff/kqXHvJ52BvHBVwlbFOm9SS0wrefhEVIcBKi/Iqc9Km3kUWjAUEYBE0qRwt28doxce/vuwYHH7qm7SLplLrhp5FdHYSwDKFAOdtFt6GKUvjX/OtjGZXwUkkPStJoRhqI2GfG4yYmlQ2gtvvwNcvuhh/+ObV2GfxEjRHRsXr61usHxiLBhVlfOHYArL4jojWXCdESNU5Aiy2ceterC31gtyvxI4RBS0sdvuRNGNU/D4kfhX3ZRF2PWB//Nf7zoLaZ08ESQSnSo16C2OtJgZq9W4h7gUz4noNnScLfEYp9dr5uPa8vNp5nlOS4XYAjflodO+aPQvMlQW4xoRRW1LOrZhs5RB3X/s9fOvCT2LsH3djgOR16EwpQ+Z1sgzVRIdDegBrrp7EwryOShMEHEP1GpqNPrz+vA9gxcFP1cidGYSG22drTlPhMIVXAjfblWRdbDDYrnJinSR9EGCFMZRPOc4MaZ5A0WPHrNoMWPuzm/C509+OysYR5K02PKXgZ7lw+xkuzy2FzM6lMPbmAFZXYXQWAMvJ5P0d8PpghTnyIEWl2oeRLMPaLMa/HP0cvOCMtwC7LUUq6u6MDVoCHCtOr1DOwnzr5rzVYwAerpSidMOcHvMFsF4P4OI5bWnvYj0LzLEFuLawXqAotIeJZEmtv+Fn+NR7zoG1dghLXBdIIilAqwEWp+YMTJryUgIs8ksKjskct613uYVhAdFjcmxstBRW/MuBeN155wIrdwdsRztHtwSwDKboCDNt3/6ymZ2kDylkXapzyG/DEMr3xIObpBEc1wfGmrjtks/im5/8FPw4R79jw2qFcClSqhRscqTyFJmVCcDSXCynILkXBQql2zMHWLmrECWRKLb7cJGMteS97GsMYlQBd8VtPPP4V+CZp50sQE/VG4izDBXLk3KiBTVr+xq/d/cdwQJvUEp9cq4bMl8A68cADp7rxvau17PA3Fogw1hzFI1qFWgmGP3Rjbj0Pecg3zCMdGwYg7UKci4Q5HoIaZf8q8k6P5svDjy37exdbUe0gBQrdn00FTDiunjhm07C/i9/GeC5yJm9lgD0/cgx2YNlNNe2u9DlZHBT6LkZ4QbzZ25APEdIWixQnls26MnFfWtwxbvPxq9++FMsr9WA4RFUuAGhn4gc/zwvQoQ6REqAJebocLBmDrB4iYSwkIXVgxB1vwJf2UhaAVzLRWRZaNd8rHcVjj7lDTjouFcgTWLYtTpgESwS5O2II6vXpu1ggRuUUofM9X3nfHjlef4EADfPdUN71+tZYO4tQKHICNg4guzv9+IDJ74J7voR9JM+YzN02NI8kgk7bHKuihI6LCRrFODnvnG9K+7gFiCnKCAB3HGw9NGPwuvpvXrE3gjSFE6lImu3bRQMWIu44Dnx957RXdvOQpdkSski0Mmm1QCLY9z8SiCRAYT8vsiIRLspUb6Rn92ID739XfBaAZzRMQzAhpvlsCmnUNQelOuJ00qH6GztzupsXGbyqHm9ME7R19eHsN1Eniao+x5ShiejBJllw100gLvGx2DvvgInvvfdWPbkJwHVKlIS3umR6x09C3Qt8ESl1C1zaZD5AFgfAHDGXDayd62eBebFAlkCjDeB+9fh/a8/GenadfBGmujLMnisxxYHsMhiFk0fveAw1KGL1eqFyDHChfPSwN5Fd2QLcCyMhRHqu6/Aka/5D+x1zIuAwQbaLOdi26K55JjY2w4NsLjRMCBL4uBIOM4LeTiO9IqRdCBPkfpeFhC3mnCTUAqgX//xi3Hj1ddBrRvCEsuFlyRSLNp4f8UDLPIMmuhOgJVZmuRuCj9P/1lbSLMcnsOag5qLpVQK26GIaQbL8zEeBEicihDf/d1X4tQLPgKsWgkMNBDm1DHTshG9o2cBAB9USr1tLi0xp2Mrz8X/eweAVXPZyN61ehbYogUKkm5ZQZrndnblxQgv80tkqudsH6XAP+7Ex08/HWv/egcqcYw+ZcGJIsmIYqlei0CrpOmjvVeWyBvJQpFnXa7uFhqpd+5mB9/9qp0BOgZjik2bIrgTAzc6td30y3zfAX5Kt8F8dku2MqVLpjKaeA+CSP21+4nJdiYnp3xs6x5GXNIonG/r/Km0dTbnTLalFPcujrL6uADs0t9IAg9tG81KBQ/9lwNx7Ac+APTXRXcpoXQB8UoKeNpRo0OEJcBCYF4U/NuuYSrtwWJR51KouyCl0/kmuCrPUOOGgm0mwLIYG+VLwTNSIImBe+/H+048Gekd92IwySTzFnEop0ltw8J22oNFKhdFSmfnweIYqrg+hoaGUPV9eLR9Fkrb4jSScWvnDpRbQStTGLMd7HPwwXjl2WcByxYBVV8T3ksDSEBgR9ee8wRfdP2LsmyYcNTMMaer6GxGc++zs7TAagB7KlVSzp3lBed0aOR5/hIAV8yyTb2P9ywwNQuUJjmTZs4P0nPQyYLiqmBbUnMwTEL0OT7S8XE4Xg1YuwHXvPMs/P3mmxCMN9Ffq6E1Oi6gqVGri56PY+vit3IIqX3iQkuAMBmEyKmlN8tM2pO/qlxLPpjzxTtWXJ/gRnePO34l9xD9oKJuIr9yxQtZqsVmn5W0zQgxyjWLuogdwFCyl1UoSZqaiWWgIQugADbVAW6CB8QLUXB0THq9TXCn+8BfGY7aZOBEjwIPk5YvKfsdj8bUHvdcnyX2ZNE6wgR6bVjYu+BKieo3uUQMc6UkaQNwddkV3/UQbhwFFi/Fxt12w4nnvh/LHre/Bh6OjSgJ4VEHq3QY03cW8B1qgWbV5IlcQuNx0iOwtGExfTLAsR1KnylA8auvfxPf/uBFqGwYhptFqPsu0jAoqbvr8KDYm9sXxQ0MLzQzkrtWhDfjUVdgkHFWDD5+cZSNOCXZHsj6+rAOGQ554fNwxNvpqMiBegOjcYoapSgoi5el8MgvY1Ejig1nRbF2x5IQb1TML74J8Xa7NNfDs3e97WOBlyql/meubj3XAOurAF46V43rXadngW1aoFioypwRobUUHgLq8XBH28oCVC0HabMF36sC4wG++6EL8I/rrsX46tWiuF6pVBBFkdQ+830f7XZ7m0rsXUXqiS3dvCdq4jlSy07anwlw6XrKCGa6CthWroGOcHoy7VXifyH5crMlP1hQxVdZaHIlBH3L4gKRSWFcGkUvSJqsb84rgjfFQjeJtF9Civpb7XOTq9DIUoeu4PGUANNkwNYBVgUwMyFWDRS3z8E2Oon2ohBcxQRZ1KsqsujYNTtNUCPwDgIESYq+wX6seWAtVu62AvckCY4485046OjnSYFhZFr3yXxNKWnAGn6lozPhTnSpbh8DzPauEjPXF0nDMdjtAFeeeTb+9L0fYiBLYSf0YOUdAG5I7mWFd51rObOjU9ew4IxRRoUAS+W6lLSEIaMMfrWGVpahBaBV8TDw0FV49ktegH2PORbN8QiVXReh2Y7hV13pTpyG6LddKJL4jWfPsUBVe4IwPlHfUDP5w/YbwjMzXO9TW7PAFUqpY+bKRHMGsPI83wvAn0k7mKvG9a7Ts8C2LWCW++LMcno5w3kW0AxaAp6cPIEVROL2//1Xv46vXnAR6sMbUU8TeJ4mvFK/x3VdAVYEWARbMzm2Fa4z1zR793I4in8rv5gSmjCercKTZMKO9MDoRUrzTsQTQWKxNICFcbkCdAGW+TsvyPNJBBagVHxOL03lkI52CJTbJxGTAuCxXJBpCz832YM1cYLR2ZgG0HW8OnM2C03vSckCnWmARRkOA6xMf6U/niugG3GOarWOZhIjrboYsjM87dhj8IwTTgQWL9NhMh7UjKJHjwr/DB9TAqR0dELX5nfbqe/Ts9QWzjbvWkhgyQGRYt1PbsSn3/kuuPeuRSPJkAvS1gK9PNJieTAlc9QsYsTGg2WI9B0PVsGNFC92zA2WA9vzMRIGiGtVbIhDLN9nL7z57HNgP+ZxgOMgryqERTfDJMCAU4FU8TYhQnLoipFb9pCX4olzYtLeRba7BfiYH6mU+vtctGTOXu88z08HcN5cNKp3jZ4FpmIBvUAX4SkChDJJogAkQkinEGRzGI1KXTIGR37zB3zk9HfAHxtHtT2O/iKbKAxDCasRXJnw2kxrCU4GWGUOlulbOeQmXiow80oXzC0XxDVEYdmhF+EsA2q81NJOJBMSNJwz9p91E4tjEypvASwMQDLnlflWBgixNBAPHdLTZ+p1kWBOh826HiuGNLtPrzzBdM/RoJj90iTnqTzt+TmHAIv3p23Fo0WvVWFPAbUuQ0wZXDiwfR8jcYK1iHHoa16Gw1/zamDxrgDHFUEYxxH5S0kC2928b2azeGI79n/WVs2AJIjgUMIhaNHlh/87/0L8/FOXY5VTQRS35R013llxpOaW2Fk7XGfXeQPohSJgPFhSwqgI8SoXzfFx1Pv6EWQZAtfBeJYidG085qkH46XvOxeoeMCSPoQULVMMtheljMzup8whm7XBehdYABZ4q1LqQ3PRztmN7lIL8jz/FYDHz0WjetfoWWAqFtARCh2eklCTydgSJKDDPRG0h8cjSBgbB+5egw+d9CZE965FJQhhU2jUtqQwMwvK0mNlwBW9WvRozcVheFoTSdXkWelXsBO642/YsWLHT35Tx+tDUrBpTOF1EmBWMLPL/DAD8NgX8rL4X+5jqvhmBp7qrxKCFE9VmQ8jDUGmTLaXTt+nqY0mmJt52vbbOMgj64ALcm86WWQaZG2PQ0KDhb3JhZNFuQCTbA+9ebRfAhvVRgProhAPIMVjnnUoXnnmqbBWrQKCVAMsAoWiHwnrVjrMa+PTFQp5J4q0swEsmku6TS5b3ASqFsJ/3IVPveYUpP+4Gz55TCyhTrHRYphoblsx5pXmDs700KHuQlai4GDRxuZ5enCQhBFc25PklJicSt9HK8+wMctx9Gv/E//yxhMRRyNwlw0iKpTe03aIasXvyFXIHMNG8mGWvMnbXcZspobrfW5rFrhNKXXAXJhoFkO7e/s8zw8F8P25aFDvGj0LTNUCXP5JXtcu+wJgFasZa+ySVxNmKaoqh82MwdExfPHUt+LuW27FoiQTPpbFCZdiogW4YniQoIo/zwXAmsxFmtg3whnzCmpu1OTyIQbwdInkhvquw3q5gJtJ5Pti0SKYInA0wKoDrgpvl+GwGKK+blsBsEqkdMn2Es+ZBkMEJgRaXNzczIFdEIHNQlkOVRrytA6Nsf6cPjTQYHhu+wIs1hFkW3zqIpUAluEJ2cqRUjgb0xTx4gHsc+jBOPaMU4FFA0BfvTCEFuDM0lSHSyX1Xz/Xcgi42+9JI3xOZuGpvjVze15MMVW+gBIujBDbKdwkwa2f+CyuvvBTWBzncPMUoaNLTdHGHHe6EgKHsPaAzvSwcltsnFo61KstrrmNApaDFIP1BprNtgBeSjdQngGUcOCbs2gpXvG2U7Hrc58pqrC54yJIc/FYSqmfom0kCghfUgCWKWJN0NWTeZjps9vBP/d0pdQPZtvGWQztCQDrIgBvnG1jep/vWWA6FtisB4sXIGG5SIvnxJiPjcBtBrj5y1fgqo99Env4FaixcZFioDp1THIyJ9CCkExwZcJrZVCyubZtLhQoTTChtEkfmkzpNWRv7ckyxW+7S3OH+0QoZrxMQniX5QJp7ggh3vC0pL3Ci9Jeq5Q8oJL3ynjn2Efyt1g7Tu6sci2gWkRadd1F7T3jvbR3qxvCNCHC3KKnpsvb0tmGGuWar8YE9NIZD07XPjPLIJvOONnSuWUPFrMFJTTY8RyaLE4Hab2GoXoF+x52KI4+/U1AfwPwKqIe7lUqoghOcBWnmr9H3hUhqfFOFkOyBCx3HoCVMkRIWQbXQhC24FZcWEET+eo1uPzd52L9z36JWpwhdHVFBKq/u5kOx/IQgDULljgBFo+08LLqMWcAFpBLhqCPNIigbAdpnqMVx6hUq8gqFQzHGap7rsIpl3wU2GUxUK0hcRwoy0XBquuEDE3ijAZYTJ9RBcDatgd3LsZr7xr/VAt8TCl18mzvOGuAleeSlkT9iBWzbUzv8z0LTMcCekPJ6dnqZA3K5+m5Kka2FQVwobD2ezfggrechuWZgjUyArRbaPTXJe06oeOoACH0+BBokXtFT5YBXVtbpMt/2xRAdP+6KbjaVLtqy4vNpq8qC01Hyu7WeeOt2A+bQpAaYDmspygLGT11uZC6Ca74HwQEUQpyrMQBUdxCCz9KXqMAInoCuHvn4mjCaKafqa3vL/covFGda/Hn0uKpF9VCB6kTkiw57abz8OfoXAnjFaFR0ycDHgl+E8/BOgBPf+1xOOQNJwC1KgKptefB9RwkcQzH0zYmmLUKW7SjEL7XlWrYrNSBPK856sh2uEyZ8sj+RWEIzyeIpkhYgL9+6zu44sxzMBAmyJntqnI4WaK143SlxlkBLM1TLAAWPVgms1XsqgFz1fUwsnEYjWpNEl1Gx5rybju+h+FWC+7AANZnKZ7y0ufjsNPeovlY9SrGohSer5+fcLJkUBdGVokAOj2aydnqAaztMPzm+5b3Uc9TqUlCf9O866xf7zzPjwRw9TTv2zu9Z4E5sYB4DVhYl5I13Bm7WoGaoUOVxqhwcr/7HnzoxFOR3L0aA3EMKwhg2Vz8meXlzmoHbfSCyqGvCenjLJsiO2LN8xKuFzEQQZyjECYxvIqLNEgka5Gq1PVKXfoSxgkcz0dEeguAQLgsFlJbIbMVIseCvWQx+pYtxoqVu2O33XbDkmXLMLBoEH0D/ahWqwKwuKAYsj7vH8exZMaRjD26bgNGhjZgzd334L4778TG+9aivXEYWSuEkyToZ8mXIISV5ahSnZxaXXEk2lCUhWAYtdVuy4LmFgsSywsJLyZNoGxbP5eiDXmmBLgS7DmWK0WBZ5FINqsxxOcURxHqLLWCDGNjY+iv1ZHF9GACgedgfLCOF5/yBux79FHi3ciUA8urSKKgYKnC41duSNkn1xkX5oTJKHvWM/CsTDCrDxuAxa86I5PZqsy8i5EihN2K8aXXn477b/41KlmKpDWGRl8VSRIgDNqo1/sQpRNB+HQaJHIlFIEjsCpU4VOzHhZfJSRpcFHJ9ibBhBuEJikCg4tw3GmnYuULnytZoFG1JuBPxGK5XzGflaSZuIOL6cPq6TRM56ktqHOPUkpdM5sWz/r1zvOcFahfN5tG9D7bs8BsLJCmuSzanu9iPGzDch34loIVhrBGW7jifefiT9d+D41miFqeouIotLMAXrWCiCnmM9yBlrWuzCRuMtDKL1ZahBwlqEBAQQ+TEPRT4X/xd65liwwA2zI22kSUZag2BjEWhhAvke/DHejH4pW742H7PgJ77/soLN1jd/Tv/TCg6gEUtjQEdrPVJvG64GBRNkAOIgf+5+/5lRV5hVhS6DWR03///Rj56x0Yuude/O7mW7Bu9b1Ye+dqBKOjqNouqr4LT7KtMiRBG7al4HmOgMdWa1zAFsGd6zoC5MRjxoCmRb6KsVTxdTYEnNkMmgIUVHwf9953H3Z92B4YHW/CVQ7cShUjYYi+h63EMW8/DYufcCDQqEmGGXJ6qxRy2olJlE6pjN9mJDN3doDFt2cCAVzQZSwhNDuKMHLDrbjgpDdjSTtFX54jViFiKrxbepOR6pzZGT1JrQdXeE8LD6zwBHm1kuOhzIM0YL7z7hIU+lVsDEKsOvAAvPwdb4P76EcCfTWMRwmqlmfeDHneAuSE92kya3sAa0YPb2F86FNKqdfPpqmzAlh5nlM8iOHBXWbTiN5nexaYsQXEC5HA8R00owC2Z8ODkt2y73i48ZLP42sXfBwPdSqwRkbhZCn8mo/QihEl1JO2O2rQ023DVABWkmoAJSFIkp9tTVsn4KAXyCMQpABiECBMMzh+Fannos3FyHKw6557YsXee+FRBx6IvR67H9zdd9ccIOpzFR6UiaJZJL/zP1cfKotPRcerAFwk1Eh2IUEYyTUp0I6Adoj0nvvx11tvw29//gvc+ee/YHxoGE4SY1HVF5ClshQuQy+2gu/aSKIQY6Oj6K/XxVvV4bXRC2ZLESIdpixkHqZr+7k6n+Dcr1Swbt067LJiBTaMjkINDKCx10PwghP/E7s+7amMM0kYOU5yVFkBgOZhxEtjra1KZc5qgp2rTs7TdTQH0gjgGqJ7AW6402ApnWaIz77hVAz94BYsynOMZ024rkKf74nHkPpUswFYtK+RQDE8RONVlm4zs3Az/TfPhRmGlVqfPNuNeYb9jng2XnjOe3TZI2rjkZQondT8yMTR7Dr6veXePQ/WPI2uHeKyDxRhQjJJZnTM6v3P8/xoAFfN6M69D/UsMAcWSKIcjquEoD00shGLBxrgvhjDI2j+5Q6cd/JboO5fh4fVGgiGhuH7LlpxG3nNQbPdQt2pzhvAEpZJKQ2dU32cplKOg+BH+F2J1quyKj6cel3Sx0PPwX5PeAKeevizsPSx+wN9DaBR1x4UAjXjfdJugG6FO1FWJ/CSoI1mqMlGu6vszt+zvqJeGIAgCkWzyXaIFsyunN4tLnsKCCmyycWSf3OIMoC778FvfnoT/vjLX+Lvt91GdChlRcityaO2ANwqr0muTZpIWJHcLx0etToAi8kFypldFtlshhAXYsvx0Gw2UfOriGwLQ0mCwX32xPHveQcGnniAgOLUskEg5jgeKIvBFTuLU1gen8dEgKVTFRY0tWrKJmU/ReaiEPbURQeLocckiTRBPj6O+37+S3z11PfAXb8RTk0hTyP4KpdQNYnnMwVYbGi5JqABUmVR3jLAMhuiDteOzyqJRcLBtXy0bAsbfBevPutMPOywZ0pBaIkDS+YGvVcKqXgsuSlKRTGeWaa9Y6e2wPOVUv870x7OFmBdBuD4md6897meBWZtgSLCF1JWgXglaMJlodn1I/j8O87CPTf/Cos41zO85XjivRoaH5XsQcuxYacz5wBtzYNl+kWARSAh+2hml9mKgUHhZCnHRZraiJVCGzmW7rESTz3ycDzu2YcBq1ZoN4mAKK+o92ZIP5rEXiKC6NsVb7PxLOQl0nU5CFN+6Q2PJk7oacvh2XrBkPAfCdwiBFmAOtEEKwr9xinQbCO+/U7c8t3v46Ybfoyh+9agghx9lg07DpGMt1BlCSLyrwg0GSpker5kOhIG0yuwfWUaqGTP5ZKlhUazDIv2ewSOPfN0DB7waOSUYYCjw5om641yDKwIQM6RhF0nhbcMutqJuFZbekf1ONPow6FciN5R6HFIr2WeII0DuAnwtZPOwF+//2MsG6hhdP06WEmIRqOOiK7BGYYIdbv0pmCTIGOpbqjObO32wujM8RnaLAxNnmacwa31oV2vA7stxakXng/s9VDtxeq8EQwJm+CgiIwIxX1Wi+isJ8DeBebZAp9RSr12pveY8djI87wG4G4AS2Z6897nehaYtQVMdIuEa2YSjQxDuR5u+/Rl+PpFF2MlU7RHxiQDjqnZo2ELTqWKiHXiuPBTpmBzMYQpNqxMcp+oJ6UvkOQsW0O5AwXX95CzplkcC7k9YKZifRCPfdKTcejhh2PZkw4CBvo6Wj6oV0SCwfBUJFvSaEgVFCoSyvX8r8OQVlG6xiw95gXn1034QFwgCx1VoWIZgMawaxKJh6Hi+bIISRHpkmqXXttyXf02jIH1D+CuX/wKP/jWN/HHW34Bt93GsnofVCuAzdR88ZypInqpuV8k+WcEn7NL1Jnik9r8aVGUoG/RIqxrthD213HmJZ+Av/+jEVdctJUFL3fg5Cz+W2Rf2ilsh8/BICkCiylwiGY8086qe/P6YY6HrtezsIPpp0SpMyiGCuMU93z7u7jsrPfCHx7FIPWl8qhbDWCGrezqXk0s56Qv15UuKYcMu4R3Dcxs10JzrIW6XwOl8rJKFWuzGP9+3LF45ltO1vxGhrQFiBce5KImoXz+QeKtnOEj2hk+tgHAHkoplrKc9jHj1z7P8xcBuHLad+x9oGeBObSAqA2wFJoLqDgAghDjt/0anzj97XAfWI9aEMOJE1TrFSS2jQ1jI6j1D4jwdNgOhC80W4Al+KYAaZOFRaUUCEMLdALlGdpxJCT8pct3QW3VSjz7xJMx+Ih9gCWLCkI6c8upraQdAgm0x0tCezKh669yz0l2nIwTRdap9EsBZyaGxc8a95Vej+Rn8bYxw4+lTwQgctXR5HyHpG6hZxU6RgSIaQIr1QR2LqRYcz/W/OrXuOX67+I3P/kp+h0XCRX0owiu48BRjhZyhQWHWZACELePFhbDS26sELgW1g9WcOzbTsPeRx6O3K8A1T6pPSc2L2hp2ujkjTE9IUMQB6i7jRkBLPNYZjwBz+E7NPNLGTahFvUgK6mcxsDxpMjDCkNgfBRffu/78bsrrsI+i5YiRozx5ih8x5/x+6drEBZAqVCUp+CwkdmQIV68RyaXoqxPJ5pZNhVbQiweWIwgiDDWDCQzd2NfBa957zvw0Kc/BbHvwbYdWPA6nkyKGHPk0r+1sJ/hzJ/+g+iTL1ZKfW0m/Z3x2Mjz/IsAXjmTm/Y+07NAxwKllUav993FtqMdJDNlyUtQCoWZRTAhWHJsYONGXPamU3E/Q4P0TtB7Yu7bODEAACAASURBVCmsHx2G19cHt1rDeNCWiZ0eGvHcTAIigjfIuZjy2zGxzXLBIkSREMn5jsgrjCchIsfGXvs9Gke+4GgsO/IIUZRmxlIH4SglHC2CKsei36Tbb1H6oRo6Fy5GYkpgid+T115UwOn+vQTGpDShaH4Vq4IBDqb5xXbc7PgTqpsXGY/0RjjkUpnnwxtZtkhHEPJ5/D1J8STKE2itvgfr/vhnXH7xxWiu24BodAx1y0WFwqRRLOd4LsOzhJCJ9FKXCypwn6n/VhShpj1Njcby2zP1Z7TpO8cMNIaGxj0Hjzz6WTiKHotVK6QAdhDkqDEzcwK44jXIn8t1BihBIlfoGXiwdhqAJR1JJcxNe2gNe/3iiDAus/QIZNIQq3/0U1x24luwOIwRBy3Uq77IIBggZIahHguF9MPk8WDGs7wKkwBWbnU4WZ2xtJkkhAkhcj6+PJds14pbg2e5GI5ihAN9cPZaidMuvxSo+4DLTY+rSe/Mk3T0tqAHsB4Ua9nlSqnjZtLTKS8h5Yvned5fhAcHZnLT3md6FuispCbSojLxGBRspaISHKtXKGQU/BQyqY2cxGjqXrHWIMUNkcInGKEW08g4fveNa3Dlxz6B/iBGNYrhi6hh1qmhZ4BPt4YZw3cU0tQ7X5P2bTKTOuVfSkDFADDZt9sQTwYVvM3BCdu1XDTbIZRXQVPlaLkOdnnkPjjkRc/H/s9+JrBsqe6LTNwFgCy9jVuLWs7opd3ckNvcTUrgdfJHJty3eG56faSNCZZIaufKxwdJsJUL6Prt1d/Cd/7na7j/r39DI87QIDAJU6gsgufniCkGmyv4liccLfLVEhZLti3EkmmoaxfaJBWb2neFyrxgxhkahKB3FAqDe++Fkz76YeAhK0VINFOFn9CAq040UIsqlc3WkZ0oc68M8J1huxbM7FAGn5NqrZf7QDBVoadpvIVPv/5krPvVbzAYRKjlCkmxkQkdS95RHvQY+okuvG1qcUZ2tzwNTzP6VuYzxmu1udJUk8fHhHNEDFd7uuj9clO2w0bgWNhYcfCEl78Ah5/xFr1xqFRFpoPzUV5xECW5SL7s7I95wYzH+WvoSBEmHJ3uLWY0NvI8PwbAV6Z7s975PQtMsMCECboMsHRmEv/rTHhuQ0scD4bbMiDKU7h2DjsJGbVBcOtv8dG3noX2nfdgqePCjaOCK6NBlHA2Cm8Dd7j8Obb03/gzJ3YCrLJWjmhOy1vSXVb5o56kMzgUNk21cGet0ScZabbjIMks8ZhtDEM4ixfjkU9+Eg59yYvQd9CBIBt/JInhe1XpX+FEW6CDo1CBL3xbJIuLbQha0xxZqy3139I77sD3r/wGbvvu95GsH0Ifye5hG3HUhGfnAq4oWyEOItcT/9B4EMCvVaWMD4tFWwRYhQK88aRx8ZwpwAocG0Oej6Ne+xo88VUvF/5bzOQD15dnksU6x6BLt9Lojp6aGU2cC/QJb7HZJsRcvKza81n2Q+kQs6MUbBqz2cafv3UNvnD2f2OP1II93pYMUxZlJ6CJC2etSywTa4DFTFSCKNYyZFhOSjexlmFRtlPkPmbxMLSnuigJlVtSI5EomiBrzLPQXr4IZ132KWD5EmDxUpk/hJcvciO98ODONqS30p+XKaW+Ot3+zmho5nn+ZQAvm+7Neuf3LLAJwDK/KIjOGsZ0Q24kQdtWUYokJmnWkuwt7nwZQEtbw5I+j/s34PL3noM///BnqLRC7N5oiDCmJzIAGTIjQFiE3IynyggTdsMS3ZCcLvg7eQHvJpVzoicviQrs/f39GB0dlbT/ME/hDQ5i9fAQFj3soTju5JOw8sjnCBcrbgZwWSjY9hDFkSihL+xDPysCKw1gWZJHAyw6LWSCiciEV0A7wAM//DG+9f++jNtv+zUGlMKutSqG16+DW63Ar1YwNjIuYcSBah3t8aaup2hliCxLnqEsf6zVWwyR2XiwWo6NePkuOPPTnwT22ROouBjjDRQp+Rr4lgGwJnXr8dHhts1oBl3YT7zT+knh0zLAYrCQ1qIHkvpodh6LnAdGxvCJ174OY3/4MwYSFoLW+lKBo4uz8yCIrtCDRbAtdQaBqCjergFWNqcAS2acIiSthYJ1Q9qOjfuTCAe/7IU44ozTdHHvShUpLITNCLWa10NYO8lQnkI3vqKUOnYK5004ZdrTQ57niwHcCaAx3Zv1zu9ZYLMAq1iQO6GyzZiJxGpZ2GydHUQytsdVjpN2GOE7H7kIP/nfb6HeijBoObCCNizhf+gJnIuzDieYBdIAqRJ/StBdd0dcXrxNxlKHzF60MQtjNBoNEapcvMtyhHmG9a0mmr6NQ1/wfDzrtf8BLO4H6jUpECxsfC7d9NYwvliWW1iQw8MgHV3gWFTODQLJcl2bj0TndgDEdAl5wNgYbrvif/CNz38ByZoHsHLZEtHjovDkQLWGGsPBrRAVguMsEy9jSIFWXoo5A1IXUYeJZuO9aLo2Vjzl3/DyCz8M+BbSeh+asKUQCkPVdViTPIwaYBkw3vFsTXsWXZAPetNGG4BlPFid2qDd90xAVqKrJ4imWpLgj1+4HJef+yHs7lbghZS8yBAWAEvKSGWAn+qvfN9IeyL4MgDMeLB4l9kAbAFzmfZka4DV9b8R5LHGZlqtYL1t4dSPn4/FBz0eWYPJD67UJsyiHJZXkkvZSR5rrxubtQD3Xg9VSg1Nxz7TnhryPH8pgGm7yqbTqN65DxILyOxYLNBciE1c0Myc5R2yLNrafRGTLJ6lsgAiyPD7Sz+DKz7zBVSZLdiOYUcBGi4LtWqJBHpAZLIsASxTL3BTzkZXl6mc3t0BWKVHQy+YZKHHKeoDA3hgfAx2ow/pQAPPevlL8PijnwssGQRqvmhgcTdvC7+nYMjKOlT0e8E+8i7AKlxXncwtro5CHmYxZKlRV5Dgqae1bgPa96zG5edfhPv+9Fck7RaW1xuw29TPaop2FlXhmdHI50e+lPEoai9GwZnbTILCVE056tk45L+Ox5NYxNm1EFSqCOFI3UcutX06b6wUwtUAS4aRweXlMTvVG+8s55XIaMZ71ZVB0OOap4RJKgkoklE41gTuuQ/nv/EUBP9YjcVxCjfNENsM1xdcqAJAG6K7ACy+v8bDlRX8LD6lWYSIpVRzpj2vmcrBOoYMVxLwuZLLQL05F0M2sOsh/4rXXHQ+wgpJ8AmW1wd7AGtnGcdT78cxSqkrpn76DByceZ5fCmDGwlvTaVzv3J3cAgKgSpyNMtw3k3eh99QRTI5aOi5n6x3x2quuw+fP/bB4SGyWvSAhPk7QV/HRZi1CR8mkSYClyax6ljZkaQFaxb30RFuEvCZtPczvJwKywqWiHGwMA2SNGqq774bj3nQSlh/670DNBesQsigzFweqRVPlXNF7Re0olrEhOX7a25wdaVyUAFa5WSa8KnJZGXLKU2Tk4xSAks89SoA1a3Hlxy7Gb3/8U/RFKeyRJip5iv56FUHQ0qHdUiYYleBl2DCjkUKRpec3XauMei6ec9qb8NhXHQtUKggZilKuXJ/hQf6vGLDfCWH3ANYEO3feHe396WT+0t1YjGtubJh06tKGzZaQ3X/y2c/hmk9/BiszhVqcFu9ol2NlnquRWSA3zvCv+Dfz/s5OqJY6eJoBKZswK0diJxKCpAdNvKSpgzHbxv2DVbz6nHfhkc87Au3Mgp+ziHqx6VvQ7+9035oH9fmXKaX+czoWmPbQyPP8LjLqp3OT3rk9C2zZAmUPyKSzzMJqvPCyKEc6RjTexJqf34wr338BmneuRt224SuF8Q1D2HPVKqxZs0bAFTWnRLOGC3PJg8Wdq16gu9twA7AmCxiKo6loWrmsBwm2uXIQ2g7GrBx7HLA/jjv9zXD2foiQpa3+OnLLFc6G0JNIyleWLrdSJgNP+y3ckcZTN8QqrTKSBSWAFSaR6GQJF4dehyhGHsdSokfK/4yO4aeXfBHXfe5yDIQxllZ8NEc2Mvkfls8FsBCryPnMipCO4dLNyoPlYv9jXoTD33qaDuHaFiKKtdLHyGTIMIcikBcvlc4glNIpBnTx64J+dnMwjorsSa3oPglgFQ5qbo5YU52PUjFMPN7E+J/+gvNPOx2N+9aiHqddr2fRJGNWEwI07y+THQiuTIkcJkDMXKhWAyyC9tRKdCFnRcmQDD75YWyz5WN9EGBs6QDqj34kTv7oR+CsWIkgiOFX/M5wmANL9i6x41vgbqXUQ6bTzGlND3me7wfgd9O5Qe/cngW2ZAGShhmO4YTmmLBZKfTCtTqmVyHLUbEUHGYiBQGYxrP6+h/gi+dfAHvtBlTCCJ5lI4sieKwdF8WoVDy0oxCW52iJBgFDXa0lgpwywCrzMHR7mVlYLBiFl8R4v0zmUmwpBNTNyVI8+Yhn46jX/SfwsFVArYLcttFiiJKLAVXLU13bj+1jKI1gS8Q5Z1UmZPuPrU3U3SfplbGANbW0+FgTal7xWdpUxabzMkEWJzqJoR3jgWu/iys/cTEe+MvtWNqoQqUxsow6WcXiLc/BQN2SLtoMzTDuuhg44HE44cKPiDyDFNGmKlecwRGunMkgLMAVNZMKGCETZwEuZnj7neNjWwNYxd/4yEJdyRKOKSK+cRSXnX4Ghn7yM/RTF20LwrnduoL6eXffW/7M7L/ZASzKLvBgeDC3CPTICUvhZZl4sNIgRWXxEqyJI2ys13DMGafhcc97LtBoIKEgLwF473gwWeAxSqnfT7XD0xodeZ6fCODjU71477yeBagJZQ6pQVc6qOcdFHLiFUKshPoLxcLFoqoO0CZJlgAsD1FnfnQ7xl1XX4uvX/QpNO+5F/2O3Unf54Srd7Y67dro2wgRuliYRYahI7PQndbJwdDk7IJML8WOgagVoF6pIolSOJ4ryuqUDxhYNCiFgdfbCoe9/Bg842UvBR6ySmoc8n6x7UiJGxNF4OLSCZ+IDSamsy/EkSLehaIfHakJA4DM4mqeQ9FBMwK0LbQ3izUhmcIP20HzF7/EZ8/7MNb9/o9YygzLIEDVdyVTkx6mnHwe14NisWWrKCM0rVmsa2nKNGys1nHKf5+DpU99cqGgr0T8NRkfh0MBWHpcXCVhaa05r9PN6InsAawuyNysB4tDnMmjcQq7UoTiwkAKgWN4HPfdeBMuet0bsIdfBZNFaNM4aKNSqSDhZkoqIGhwbjYi9DzrJIO5A1gcqqIIr1iwPBKvNnlYAulEzy6G2+jHmOfBWrk7Tr/kYmCPFUhtMhU2LfbMOY+FzR1SAHrHzmaBk5RSn5hqp6Y1NeV5fi2AZ0/14r3zehbYOsDizpbV9FLU4EpYRmrbFYrizaCNWKVo1CpA0II91sSvr7oa3/jYp9EYDyTNP46jEijqgiv5bgKny2R/MURX5l1p/wh3wvozemKl/o5kKykbWZLD932sHxmB5fuo9PfjgeFhpIP9ePrxx2G/px+Cwf0erQsYxyHsekNEUFuG3FsCV12QtfMALMNZ0l6dkhJnQQDXQKx7dGxQYO84COBWHAQbh1GxFYI77sSlZ70PG2//G5bAwej992PX5csQBAGazTHssssuGF6/QcRdFZXhpzWLddsRWzaGcgt7H3QQXnn2WcDKFYDvIW6Owh0YQBq2YdeFhYWwkyPJcWRDJbnodrn+g3wR7XiwiDcFfuqkgE7xZyBgVL9SiOKzJigHAFX/71qNi/7zBIz+6a9YXO1DynGQKymhFKcRlOuIVq0BWPq9LaRdC4V/boxmXmqJfD4Grend1kWpPPGY6mtyk0Y9rEw02Dwktot4cBGed/LrsPdLj0RGJXoWr7IckRNhxqtgMvFM946d1ALXKaUOn2rfpjU15Xk+DKCn3j5V6/bOkzIUPCZ7r2QtLpTbgzSCDRue7eryGoWYoK4MnAKjo6Kfc9XHL8bPr7kWuzgeorXr0c9SJuJx0hPbRNX17iRXllbgzndTYns53bsLsLipZaFftj3JcvG2paxTV/GxrtXEYa84Boec9Fpg6WJWjdXNYEyQ5W8KXR1Tac9Ekwx5ulOCZQFnoZnnR9szN7ITNjMPt5hdNKdNH51zjGOzMEwrCeF7NvI0lsLcuOs+fPbsc3D7j36OFW4F+cgIFlNrrDkqxHfqZrFgNsfNTGtJ0jui7AoeSCKsOnB//OfHPwr4ChjsF29ZK2jCqnjISLCWhZj9ZOFnR9L0H/QyDeY5F1pVGmBlMhY6AIt/o6B/gUMpS+uk2lvFGoU/O+8juObTl2FF/2JEwyMY8CrI0hgpw8kuMzpNeHhipQUN5QwBbxIPcIrzrg71m7LdFLGlvhZJ7sxc1bIQpCi4ThWqlSDLHQSeh+UHPRYvfs9b4e/7cPFwoeTFYp1N47miF8umGmnv2JksMKKUGpxqh6YMsPI8fxKAG6d64d55PQtMxQJxGMH1vQJsMRwYi4CoK7NyJmnd8Z//LmGje//4Zyyp+AiGh1B3qfyta9iVAZbJMOvMvaauWae+mdHB0q3rcK8K7xV/xzO4yIsUAIFVEKF/6RIMtUOkfVWsjwMc8dKX4qmvfgWw10pdjy9hdJDFYKW4mUYSdlHkubQWdwDWTpDmv1WAVUJU3SDxpgArb6dQVVsWtHYeI0pCDFBJPU0Q/elv+OZHL8Fvrr0eq/wa4qEh7LJ8GVavvRfugC8h2zxIS7ysqYy48jn0RVkYZYrbLksQL+nHG997FhqPeZQeU31VGQy6JJMEoKWqgJM78DuqmBTmmu59d5LzSyCTPEcDsMRDKR4sbRi+Y1HJRknUgp9mcCyF9o0348K3vR1YPwY/jHVx8CL7N84TZAXHiXpVOoPXyHVI3L9bG3MGJtU0goLbJfQCLc/A3xrZCNZYdAmoI6qMKETKRmugimedcjwOeM2rpEZhbulNmPQ114XReVCiZOELCc/AsDv/R56slLppKt2cDsB6J4D3TeWivXN6FpiSBSQkSMEZLeyYFYoFZC+J16qV4u9XX4tvXHwZ1IZhLG/04YEH7hfNGr+/KmR2j54TXQO5w7kqr3jlorGmvE25bSYrTTgYxcE0bcPVIseiHUVwGgMYt4F/jG7Es459CZ73hjcAuy9HxIXFr4peUk4+EQMkom2VIY1C2FVfuDu6Zp/8tQihmJst3Ey0cnBG9ullJCVVpXUf9a8LYFs+z4QI4wSO76AVx8K7Y1i2PTYsau644158/t3vw5qf34r+OIWTJ8hVijEViHfAzW0Ri5zJIeMhzSTke8foRti7LIW1eBBPevYz8YyjjgKWLQIaNc3Bsi0kArCo8k5NJ0uPXXrdWMpnEr9wJu1ZcJ8xAKuIDGseFmFoF2BlUQarYoH0SlOY3aYlqYVGXbQNG3Hle87Brf/3PSx1fNTiBCpJ4Fc9NMOWZALzMLVCdRkbnRWsR5UO5c/kKOvcuQUlwIjXEmDJPTg3hSkali+8KgKspgcsfuwj8F/nnwc85GGICi89PVe98OBMnsSC+8xZSqlzptLq6QCsXwI4cCoX7Z3Ts8C2LCA7Pe1uQtJqwekj1yVDc+N61BsN4I678eULLsIdN9yCejNALcmgqKXkKAFi40nUWWB1PTEDsrp6OTIBF86krn5VN5yoQ4V6oibAKqu161I6FmzbQawsrG23gEX9WPWEA/Had5wBPGQF4PrIbcowFLQxIXMR7THrrFM0r6tuLiCjVMfOxA23Zawd+O9mbdtkkSuVPiqTlCfzr0yYLQgj+BVPskpjehIoq9Ech2/7wF/+ii+e8wHc+ctbYY2PY0mjhjhh+oMO2XUzC6dnKD4iSns0owBpvY6xPEPbduD09WGXFbvhaYcfhkcf/ixgcaPwZinEEZ+rA9etFUKaRR07pR58IMsg7KJUqCG6S5iQ74/hYbHMDWXriucqAIvvSRwCcYo/fuV/cPmHLsKiOBOhYJcyCQXAoorH5gAWhWf172cJsMi5nFQZgLINLM3DrGHHshG3QtRFuJh9SBFXPAxFLbzqnWdi71ceB1R9MDRIDpYp+s75rQe2pvc+LqCzb1VK/ctU2jslgJXnjHtIpm0voDwVq/bO2aoFDC9Liwhq0mp7wxBqIrpp4abPfxFXXXopamEMvx2goWyk4y3UfQ+uayNIAli2jTQli4JD0ohP6rplupyKHtpkWBhwpT1dhXClKfCcacDTFSzscj440SrLxliaIanVUN9rJU658AJg10UANa6UA5U7YJk1Fid26OlgBiGJ7lYOi+GNDteIXi3+nW3VGWkaIOwEUkqTPVfa8AVV2Hjvuv0tg6yM2YCOizTPEYQxKqzvBuY0RKhXPKDV1ga6+268/41vhL1+PfyxFpyxUSyq9mE8TTrejOm+dvR+5ORxOQTRLJFD74iDZrONRt8AxsM2+nffFXsdtD8e84x/x0Me/xhgtxUAsxszG0kcw/J0uSN6sB50XiwdIy7C4fRQFRm4BmCVNNGkniAV4QRk5VLGChGXFIXs93/BJ97xHozdfhf6wwxeTrkE8qDordTXpGSCDgpqD1YsVbiL38/Yg8W5QAMsCosSqOuSPJbUvuQcQtK9leUCnpyKjzEmPlR0VuuuBx6AV3z0Arh7PlSP2SCQDEgecRx3wNZ0x2Xv/B3eAhz1vlLKTONbbPBUAdZhAL6zw3e718BpW6DjgeAnJ09UpUXSXNgEY7oDZ2J+2Obmus65HbCRF5pUGbJWS8Mj28X6m27BlZ+6FHf/9ndYYruwWy1UmJ3TbqHiu8iSFEHYkolLNs8Z4NpeR6TQeLGkrcXkbgQJu8V5SbM1iu0WnCK8pJ1pxrulQ4QEWGGSwxpsYMi18fqz34VdD30KUPWQuL6AAi90tBilrUOUFCs03BBmFHpMSTc7eS4REj7UAItnaur0JJBV1pLa5I/TfsTz+4FNHvjE0KA49QqWnAFWE+QquKiliYAcHlFEL4DO+GQEyWJ5Fdo0CDD++9/ivDedDnvtOuxO/SKCL0fzt4QDVISJBbhOatcEoj31zcSzmYmOUUjxWseFZfuICfLcimSOCnfIsTFuZwjqPvr3WIl9n/SvOOApT8auez8S6O+XEjsgkZk1JeXG3dp0ut8mlKX/PCERoPjFZl67+X1mc3X1UoiQ3dRjupRJaLzDSYacdpKDsrsa1CAtyjSMNnHF29+NP/3gJ9glzeHGMZpRC17F1ZymQrGfn5aSSaX2T37O0+ma3mxpaRcCOCsjwLKkZA8TGxTFiOMUfZUqRsfHUB9oYGNrTEjsi+p1/HV4BCdccjEecshTgUYd481x9PX1yYYvjRMtP1KEjjctDr7ws4inY+ud8NxnKaWu31a/pgqwPgTgtG1drPf3hWUBswFlq2V5M6jFrATFpEnuhFkEuPQJCVy6miHLEynoa3g2XFAIYeiZkoOLWZYLobWTOaeRBZDEAPWN/vBH3Hj1NbjhO9djbM06LO3rQ5VVNYaH0edXCyKrDsVsom+1BZPrEJ8uqdFZ2ErndnhbSS6hRuorsU25pcQD5lquZKnRqzHuu3jiS1+Aw976ZmCghnFk8KyKcH86E3yxyJusQS7etABlDDfJJJfMQc3TykWkItWhLrFXEW9hCIVt5yRd7oAJK5aQ8XQ28FN64WczjCeFPbcGuDUAoQ0KbbJJ92X3g3ZLe7IoMJsr3P4/V+Hyj1yIWjNEJYjRL2HgHGMq0sWAXabNW3CTXAA5S/PweYpnkyYvFms3pYdC16ksk50NV8yEndMsR8wP+a6QmUejNlyvgv0PeDz2f8pTsMdzjgAWDwJsIyEGAbTwshTaoprmyBtDP634Wo1ESAFOyDljaK0QHxALlBllm2xOik1A11Qz45/N5hFP+OwWxuEEIFly5OqhXLyUBnk321jzo5/gvJNPwR7KRsMCRttjsF0W23bkPaN3KVUKLUnfBBpRBjvLkCidSLKloywTs9lzLA3gxIqyqdKvoJ67upp5OkPZ0Aj0OGo5LlYc9AQce/6HgF37kbJyRKbEs+44Pjh2BHCbeUje+24ygL6Jpg30jgVngQ8rpU7fVqunNN/meX47gL23dbHe3xeWBcz8JhOATCj8X0IkBTHVeFv0dFAiastimknml2IRY1vLacqiRK+ErRc7KW3BkUYQQ7cTd3WtNrJ7VuPmr3wFv/3RD3HX7X/D4sYA+r0KRtcNSSbhrst2wfjIqBiVO02tS6MnwPKkqids8XnoAq3FoQnuJXJ16ffmHC6a0i/OhTblGFIkaQrluIjzHDElF3ZdilMv+gjUPnsi5ELq1hCFIRr8m9nFlwBWac3pkto7u/2J9iXAKmZzAVRCnjYK7+btLC1Qm3KdNnU8bm0UTumF/ycNYw3wtVQps/mMZ8uMS/OVnBwVBtpFMt7GL7/wZXz90s9gV8uDPzqKPAxQW7YII+E4hsdG0Wg0UOUV0xx5xkLfOuXeLJz0VmiAxd93i3tvrtsi0ZEkMo6ZEcYFm9lhJDyHvofhWh0HPPPpOOyoo9C/36MAhjh5L98VuY62gGcd9qTt6TGVEclO8xeiDm/G76aKTlv0GPM9FbHTBV4snA+ZNSnvXo33/cfx6HtgHdTYMPy+itjdTqhBxVC8kmc45unyVosCKq1nCCkAOwuANZuwLnXU0oElOOaMN2PFi58DeBZiemC9qvAUCJulXrTRL+4BrH/SzPJPuc3flFIP39adtjnf5nnOTeLIti7U+/sCtcAW4hNl8GV6NoGgXHgqdHp2ARH4Db0GTFsuVoYoDmBzZ8dJJk70IrluI/58/Q/xg298A0N3/h121JZsLmYEktxsMyyXka9R1s+aCLCM5hXBm9l9iibW5PDaZnaH3eLOGXKKGpIvQXKzsoRXw9CUcl1EnoN1SPHiN56Ix53wH5JJBs8F1ZcYPuh45czqOSmkuuni2LWVCRDkXLzpvzDihLnW5REwUIDJMmDbhCQ+yTuwrVG4zRd+WxeYw78bD5bOPCt28mZcFfQeOScNUWUYrh1rA67dgG98+EL87JvfxMPcKvLWO4PRCAAAIABJREFUGBJbwav4UlonYakkZcOxbeHOlAFW14OlO8JxtDWhUvFu5rks9kbXiECL121R86gxiPXcLFQ87H3AY/BvRzwbD6cq/G676Ay0PJOwk7I92IoZiFrajf+FRjTZXVUqZmBwWDmkKllz5WewwAGWKJpw4xVH+Ppbz8Rfrr0OfrOFvv46wqAlOnRlgNWSTONcuFouC6mzNNZ2BFjDmYVHHXYoXnLBfwN1DzG9V54WIOU8wk2bTuYpAHXPgzWHM8h2v9SAUkp7ALZwbHO+zfP8WQCu2+5d6TVg7i3Q8ap0F3PDmTGYoevZ2sztLSAgGLF1yFDCZeZ/kiIOmnCpJUQyKy+0YQh/+v6P8ZP/vRprfvdXWEEbzCiqVSrwbUcWxiQIxfPgWQrWhNT3rnte2liMXCMcajxYRidnwhq0BcsJwdUhB6ctAMtKlehZWbaLyLIxXvUQL1+Ed13xJWCAfBuXqoMImiH8al36vQlvbfK9SqCrDFr5PT9Ob0rnGgWo4iXES7cZjWpN6e8q0Rsy+VQHxzZf+KleaE7O03w4XYCmQBoFYDDSFokEm3PxATFjDEPDQLWO6Hd/xHmnn4nkrruxa62CtfetwaL+fixq9GNkw3p4JM6LJ1JztMyYMQCLY5Xfbwtg0VtF4jIBML8XsrPjyH8+o1YzhFuvIqM3KwoxkiVY/vA9cfCRR+CJT38G1J6sDatlHkCdNJb3yfR9pQqeyTztAGodop68wTEgS38tsZAWOMCSx0+AFbbxj2u+jc+//d1YzrqiMT2WJBwQYGkCOkOEIcs9qAy1mOF/DV63BpC3FSKcjQcrUTYCu4J02SBOPP9c9B+wr5RbGk8SVFxysShUvOn7bfTC9Cv0IK8EMCfzyHa7yLOVUlvlpm9zvs3z/FwAb9tuXejdeP4sUH75C75VObtNwNVkKfJiIWAkSzKDCv5C1SwWUYY8bEP5XFAcnYr9wFr846abccO3rsHtt/wCXpSgz/eRMDXf9RAFgSyG/J5AhxMrFxGXE21RfqJjBBJTix+k+HLHY8WGsfBrd0jL4s0ag6VRXibIcqJ2rFS8Ho7lIgsTVOBDOR42xClai/pw6AmvwiEnvEb6EgcRXK8m0CiOA1ETNxvTCfwyg075tWTXsrnN1OqU7WtocAXJrRwqKwPerkejG1ra0iCZ7KDcDP6bv/G1zSubp1H0QwykQ14GYLbzFK6yESYB+hxPFlW0Q5EH/9t3rsdl7z0bizh26NGIE+TtCFXLhlf1MN5qQvluB2AVj0PzsExyQ5FVukX7lWppGi+jeMXSFEkSoV6vI4jaSHhNei4EnFvIvApQq+Gpz3kODnrGofAPeLzUM8ySCFZfXYRL4ywFGYaa6aP0OKUNDCAsGmWG70TvpUmrW9ghQnl/SHYP28Dqe3D+8a+D+8B6ZOPjqLm+2KgDsAp1daJSjxu7gr+3vQAWy+iElocRleOJLzgKR77zNGBRDUNRiJrXL+y7zgbKbJ4KD5YJBpOj1zsWrAU+oJQ6c2utnwrAuhXAAQvWBL2Gb90CxQpsQn1myRNyNn8ou1E4WohpCl0bkt95nkgN8Lwg6Qp5pAmwbi3u/tVt+OnV1+C3N9wAt93G4koFrmhF6Ykzyyz4XlXCMExz5o6SHgOS55vNJirkORWHZB6VSL46Q4sE+4nDuFMyp0RYMhpX8pkilEjpyDxvC+XJcSpIWglqTg2tVGG9ApY89tE45dMXIGhUURlYhDhK4GaOBo42dSaZ4q/DPp0wgDFgKcRHDSDtqNJwTKQjCrtZ5o8mXFSACy7YBH6UoygfxSPo+LY0I27Lx4IEWAWaLNf+jvMUviKbKZNwktRfCQNc/YEP4vovfgl71BdhsXIxuvp+LBscEGZXmMdIqaZfABbznIwiuOwJNiGNT7QlPVWGc2WEJI1aN2vmhUkbSjGJw5VST8zbCMMYUcbyMB6yahX1Fbthv0P+Df965OGo7vdIyTzkRkB5LsiDNkeZ6F523srYMuCrc/bOAbDY/5ylsvhQRsZxzVln45avfwtLYKHu2AKw9KE9nBIOFIkVLTKaG6GsLbwC8+nB4lsc5TYibhYXNfCOL30GePgqtK3C55pnqDGLweyDOpxK1l81vSrp4vXWqoVmgV8ppbaqDToVgEWxEs3S7B07lQXKHpJy0rBwb/nHzXmvWJ/LZkkbvYOs0uMQZ8jjAFRAh+MDI6O4+3s/xC+uux5/+NlNUqi55jvoY8gtaCNsjaNiKfhuBVFIBSlLpBf4P0oTBBFJ8+TUMF2eME4fRpW9uyB15RjKD6brsdK96u5wu2R4mbBVgjRrCcCybR9hkMH3+zHEkMVuu+KZx78KBx3/CoQCpDw4tic2SdotOI0KWlSS9/xSgdtSiLRwN5DELRlsheo0BRjFC9NBspyk6UXLdDuKBUO4OpuIKHb1vkz6P3lj23yJtxLJnMpn52/Q6xBhJ0nBeLDkYevFlEMwygpeH78P26i7rmSuotVEcPvt+MQ73oWh3/0Ne3h98MabcNMMMZXJXIXApp5SIQsg2VyG9GRCSxN8mpt0leCKwIpjkx4s8vXCMNQ1Nl2F3Mvke74vJGS7CTcdHjy3AtutYDQKMa4URl1g4GGrhKP1pKOeA6xaiTRoIh/sB8nSRaoFHALwnCB8Gg9t+z7EWQ0PJpXk9FIyC6bVxp1fuxqXvOM9WOVUoJpNbeNJdyhn+m1r9M83wKIWXu5XMBRFeNnb34x9XvF8hPUqQimpZKGWUTNtkuAdqzz0ANasxs0O8uFIKdX1AGymUVt9NfM8fwyA3+4gnek1Y44twImLQMlskE0IQiZ7ww0qz24Mt0lttlyUmR2G8Vqh5lB4LkWMsOanN+O7V3wN//jlr+G3QwxSEDRoIuNEilgmU2pDUZMzDhP4Xg1JokMukrBPj42ricURs4gKD45ZFifLLnSbxzN0/cCul0tLAJifN83AS2HZ9GLlQGojSBXsxgAeyIBlBz4eJ13wYWBRQ5Sa6ZXwTdagAsajJjy/3sl824SrVniwkiwuhE91fcNO3RyZYbkNT4DxETSHRxDEESquhzq1dGo1LWhpyN9EX5S6oPdQtHq0RSpG3mEbY2NLnqztvTbrDLqCgyWNpIu0KwzG8SleDpONJaT3BJ7tQDE5Imjhd1ddja9+8KOorhvHQ6p9CEdGUOuvYzxuI3G1Sr+RRxCFcfGEmBG1dYBVrjFnwtUck5JdqFg6RVooZGyKUnoU3Mgs5FGGKE7h1+sihsqEicC1MZLGaKzYBUe+6AV43CuOFf2k1NXX04XORStEZ9pu7qFNfmDb+wHOYk7SIXP9L45bqFg2ol/8Fh8+6c1YEQJj990Hl/IYpTAugazs/QqvpF3YbUvNmE+AJTnVrE0Ypci9CpYc+Ci8+pPnob1sEJZdkzfTYZVrNrisKCwbBz3utIRH71jAFnisUup3W2r/tgDWfwH49ALu/IO+6VubYOjpIVjiq06+gJkDqOOSZ8xs0wT2OE51JiBBUUR3Pj0+Bb+KLvxmG2tvvAXf+cqVuOOW36CSARXLQmt8FNWKI2nVJCgTHGlvRXdRsxlyK7xMWtldT54djFdwYLRHJxcCPBcjZogpizXOtJKURBIoGii96HJ7WEuQZ4iHqMhK5OepkZSkBE1SWQ5ROwNqDYz6HtZ5Ls798hfg7rEKYNmeQspBGtXxrDAIRQaFQtiKUKt5EkL0PN0f9iNJIzi2hShoi7fOyAxgtIX7b/s1fvm9H2DtH/6A0bVrhS8khqWRLQfLV6zA7nvuiQOf/GTs+rSDgUWDQNgEli2RENNwnsBTHrh9MlpclCSgTXiEUQjf33RzNXnN3t6Tux59JaFVw6krgayygOiEzEx6TLMQuPs+fOk95+H2H/4Uu8RAv+2i1R6FU/UQKK0GbrSOOqWRjHYb0/m2cmyLBG3EaaUPHeOWUgOVjURKJynk3GzkmXjk/GoFyaJFOPyUk/DoQ54CtWRpAbjlhUOc5XBr9Y4IK59TWSlcezzLKYgLb6oz5mrHbXiuC4c8rJEAX37LmbjvJ79AfxIjy2J5fqZWqHCaSoKj2wJY822VPNFZg0GSY7ju4WUXvAf7HP5M5JYryQwOET4PebeL1hQAS+OuHsCa72c0z9c/QSl1yUwB1v8CeN48N7B3+Xm0wLZ2cEZpmPIEeUoVbV9Alcni6kKhRBZzRXcCla/HA1kQ7rv15/jZtdfh9z+6CX4zRD8sxKNNATmNwQEp2MqDpTGEd9QV+p4Q8jNufwlblgRFuZBwkeNEqlFXLm1gv0RAkkWalZY54HnMPNQkZE7OBFz6b4RR5HVRXkGHBF1JoR4ZGcaSJUsRBSmatoOhegVPP+6VeNoJx4t3gSVRjI2EfF2ERzXVnqV/NXMmCCLRSeIPYczsSIZAHSTttshWCDF7aBi3XfcDfPcb3xRB1YEkQb3VhBuHUPTIMOON2j5xLMriTrWGFkHcokE87YXPx2OPPgpY3IeUCteNPrTSEH12pVMWKEtT6SttQx0yac+kY0cCWLot2pJdArfJJiw1fIsoMEMSjMGxHKz7zk/wsbe+A4PNBIOWjTAYJ04thETnD2B1yfJdrTZx/hZtFjBPLh03BRQ9TVIJe9MLlvX14V7Xw74HH4zDnnsElj/usTpbVXYwFqIkgvJ9xDzfYShajzV6gyUPogz853EOmc9Lcwy04lBCsB5nnZEmfn7JF/Gdj34KSyhQzC2glSAuirF7xe7LKLpvT4DFDRs3NSJQmltY7yrs/+oX4ui3nIKsVoHFhJi4EA52CoBVvICa86rlSbb3Jmc+n++D4NrfVEodPVOAdT+A5Q8CI+20XdwawNLEbKbjFAxr8RblyGyFIE/RSiJEeYyGV2VuHTwS10eaAIX0/vQ3/OhrX8fN37tOivLGQQg7zVCxHCmgq1LWeUsl3EeBQBOSobfFZUQxUeLZIkAyRGPtwZqoptxpP1WVed3CkyUAiwsXiz+XZigCGwFaBFVMiWeqvlLIqS/Fvmb6q4RixKvgIKAWlfIQVHzs8dR/xcsv/JC0m0Rk/r5TWI/hOf4vgAFbI7XKCLCiWMIZJL57DGtmEWwCJa7y7RDrb/4VvvSJT+Gu3/4Bu9T6kIw24SQhnDRA1VNClicg1IDSllItDDFRrDKv1rAhjrDbfvvi+Sccj1X/fkghaEmEqcsMmUMmfLbYeDcmzd47HsDq+hsnZskVPdpSbFM6SWdPEy5tvHEc3zjrffjj925AXxghC1voq1CvKtH15joG0t+xDJJcehYeLIrYUrlbLiObgrxTC5NeF5NYkXOccqxQH47Zh3EsfMXcqcBqLMHqjSMY2H05nv3SF+Fxz3susHyxzt5v1MBPjqchLNuDA0dI9VXHF4VznSyxsJdnPgOGxl2XvcuAVoTxW3+Dj7zmRAy2I/hZRAE9hEU6nicsdym2I723Non7//OmclNuia+cbXkYYthy791xyoc+gPo+ewP1Pk0k5KZHNoBdXp3xynbG/D+v2b07za0F1iqldp02wMrzfAmA9XPblt7V/tkW2DbA0p4Y7UOQAm0CPAgiNE+Au6wMdtAiJxy4617ccOVV+OE3voXx1fdi90YdVNrW814RVuRl0kx26/TMCFm54LywgKpR0mbYMLVY2FWDAp2mbhZA/TMXEDKpTDKRAU9mWbHJ4MgLj1YBUORidgHILEdEInkOycoMbQq/K00Q5jlayFFbvBTrhoZw1HGvxMFveoMsbGNBE43FSwoJ8K6JpBhsYS0JqVIUlUCt4IQkeQxPKcTNMckqo6fvtq9dhSs//RlgdAzLvKpwhBp+FVIlWsWwrFwU5EmoZv+qfhUeVaJZ7iWz0E4SKHLDgjZGPQeHHfP/2fsOMEuKsutTHW+YvJGFZYkCkiSpCCIiIChBTCCCgAoGxAQi6ieiiIIgJkT9EEQFQUVFQUmf+KMCBkRFRZKAKGF32Z14Q+f/OW913emZjcws3JndaZ91l5l7u6urq6tOve95z3k9DjvhOGDBAs1iyaNWFnW6pCMlF6r/PYUBljQ1fyFMFKvV5CKwWh2BjGOHVYW1Jhp/+ycu/OCHgaf7UUlTeGkkqWkZQaYfcjsUk68R0L2aY3UpwhUBFoGbrhVlulrTGDWJm4fn2DqNyHeDFlOZA9+qIEwsNH0LQ3aG3q23wGFvPR6bvvpAsdyJshipeG9ql4SQYAsKJbskRRBrW+TwXM87a3s9iVhnufRKHMHlD5YN4aI3vw3Rw4+hHDKGG6HhJbKRojyDnXJG0ptCVnC26xDRV44vbuDgoeE6WGyleN0p78buJxwLlMpiYUEwD+Vou8q8ua0IZ7saP3PdddkDs5VSy1Z2wlVuf7IsOwTAdeuyFTPneu57YI0Ai2+8MV0tmJNSYZy7+ywIRVUd/YP4800348bvXoXmE0swt1RBNDCEOZ0dGBkeRBg2YdMexLERJLFEpsgBSiPNfWIqhQsSK6S01U1OSi/oQIxhlOQLofGEkwgU1y2mXAi8DBZsRBIZYIpBS2OLY5gEdlgwFpNXLtzyDIq/p2AhOTG2hdhzUa+UkXVVceQJx2G7Vx8MVJkITYFqVc+GzAnmq77RZhL8Zjg3XDsJrhR34gF8Loq1EZR40czGrV++GHde93PES5ahGmfwrQxl18XAwABc10aZJtYUTCScLfigkWvG6IiovNu+VKMlfglJRxVNz8Xur9gXh7/n3VLtSDJ81GiILheBFZ+dopQEgZYxIc6H3lSKYBXfhhWXyYJiuQRW9XjR1Z/5N3POniJQrTXk1z/91Gdxx09/hk1LVQRPP40qgTajRa20sxll+u/JACzdCm25Y46iqbicXwBErBPKudelaQsjuVl/A7N6Z6M/bKI/i6B6exB0VrH9Pnvh9e88CVi4QOtn0X6KaUFXa6/Fot1GxmHuYfncTy3r5IrUEnMcTyLNrNAs0YpqsI6f/8+ncc9Pr0cv06Q5wGKakClCmy4K5G5K5YOmCrTjIMBKybN0XYw0Y1iVKoZThfk7bI8Tv3ER0NeJrORKQYol8cfCjqJNbW5HP20A1zxUKXX9MwVYFwL4wAbQOev1La6Jg0WuEiM7rYMcK6IS0aoS1IAnfvUr3HDV9/GvP9+NahSjSs5uGAlQGBwcRHdPp+hVUV4hoFyD64DyL+JHSLPWHGDJnJJZYoRLx3rNYyafJE9r5QuVLH2m2ivnFdEbUNZZ8ouktDuTha1Edew0ExDFnzMSlBJUUJ/KoU48Zeb5xxFCfKPZFHJ6tbMTldlzsN1eL8behx6C6nZb8WRIqC5fqQpQSaIQtldqiV4SSzFixuRMq8oyB1/kyzge7TEiOEwNZhb+ePkVuOXyK4DFy8X+Y0FPD4YG+tEI6pi7cD4ajQBJoG1YaDIN30Zms6IqApJYbIOYChIx1iiTasbIcvDQ4icxa+Em2PdNb8Rex78Fav48gIBYyGXWKMDK27Y6INP2ed6AkxXUy3WMotW+wufM/Ug6WcYKPetiIIoR3nsfPvb2d6BnpImuKJG0NmUxSN3RPpYaWBnuFAskVnesieRuvmtA1gr9KenpTIjuGljpDQb/UA+uGzaSMELI8VbyMMIAThDAmT0L87beCq9/21sxf7cXAD092hGh7MvYXl/K/LkxE65gynR+Csu1oIaG8cAPf4YrzzoHG/H5ZRGGS5H4RhJYOYmCHzuyYUvs9gEsmQQYJfVcDNQa8MsdsOwyBqjMfcnF8PbcHWnZQjN/jyW+XNxJtP3lW6+Xvufy5r6glPrgMwVYfwWw03PZyplrrfseWFMVYZQjBcZKsiiU9B1BEQZGgKeW4ycXfw333f47NJ9ajHlMByYRwmZN1nLuHO2uDtQaTTFsLTmOeMYx4sXIALlcNE7Wi9uo6rpEsszuXrgqOlphSukNwOLPhJMkwMERArjwlHhdx4XyHNTiWHS5UprBMtXA6/guvHIFquShZ9YcuB0V9Mydi945c9Hd14vuWbOwYOEm6FqwMTCLFENWEDoIhASfic1KNDgCt6NDAlhU3SYXhqwPxreEd2NWOFZiUiuJJr+IEdRr8D0P9Xv+ibPfdQo6lo2gsxZgnl9CMDKEZlhDua8Lw2kTjUaIXrdX0pChk2pJAd4LQaditMuRdGLJ0WIMQUw4YMGuVsWa5Uk7w+vO/hR2ffVB4p0okUiCSZJCpgEHq6V+nwPBYoRwVOl6LNAqphS1yKyFOI7gqAQOVT7TDNd87BP40zU/wyZuCS65geIHmOtqKW22vK4AltkcmDdXE9yLPx2Fibo4Q8sxSNyJMg9pDR0dFQHbQZig2t0nIqWDzRBZpQK7qxuvOvoo7PLaI4C5syStnDgZVImRLL6105uFxQ2JRbJ+vqHic3KaAdK778V5J74DPQMDcFINsCI7hZM4cHOAxWfIvlidF+G6n1GLZ2SBDXmWCoyz2VYZdmhjCAovOvZIvPz0UxD1VtCEhRIcbY00VUPIz25Hre9nv0cptfMzBVgSkV7fe2ba39+4HZGkJAo3ZWXZqMq4zrFJWEAWHFGmiiBa5GkMn1ESPvJlA7j7mp/gpquuQbR4iaS2KiklEnS6kJwjpjt4jhEu5q4Nl6CDpslZhjJJx+QUxYGAoNbixuxOPpFqPStt1MqFtUil0BY4+U6fhrnKkrYGSSogyi5RK6oLTmcHejdZgMqsHsxfsDE2WrAAs+dvhO7ZfUBPN1CuAJUykHAStAG/pFNmTHmKphS1uygmRXuTFM0kQsX2hYjMBTBjmbjv5nw0LmQZSmKFlkewihEim5WEwzrF0T+IS97/ETz+u7vQ1YzQS0J1rQGLu92Sg0amSbuu7cOtu3CUj8gDmlYo7dAwKhVJiopT0rYsJOe7Lqp9fejbeAGq3T1Y7jl4sqcDR7//vZi/8cZIKKHBaEDOwUpYfeaOfYWn1PwuIcl8sBYqR/WPRuUbNFwZTRGaukOdKqPdEUVG6AyQAgP9CB9+FOe+7T0oPd2PbnL+sljGIP+ErG3ILJRoOpBaiJROza7qWFMES7dNt89UD2ovQR0po+SJzfaxYEJeTv23vmSC1I0x3BhCya+g4pfRaGizcccrI1I2BqMIccnDbvu/AocedzTsnbcXmQ6enpsjyxGTqlEfUJ64IKG1sgjg1AqiUKSYPCYdfR0OA3Rys/DkUlx4zPFwHnwE5SRC3YsQ21rnbipFsHT6N4VdrUDFFqKBBtzuHjTmz8Gp3/0m0i02Qk3ZKJsUYRGJF1Ld034d2rBvIFZKjVYaFfpipVNLlmW7ALh7w+6zaXD3xQVK45UWOV2n3wCPAMuUCvOHJCd5Ck0XqCFFhdWBWQS7ntuP3PcAfnLpZfjDTbegz/PgcNGWFF/Of8934AYQRYogTZNtqfnE1JYs7Aooe75oQYmIqMokZUf4ELGyz+bnfQQN2sG4whniwhSSa8IUomMjY2Wd76I6axbmbLwx5m66EPMXLcTGm24qQMrp6gB6u7UgJ9OcpkzHkLyNzUxrlI/zbZOf51ycltp6vvgVyKhFwNoSFDW70bxGgCXXYVSDX3LwwE2/xJXv+Sg2Cpm9osK9Nqg1QqiiP8b1JLXgNegh7aOuAsQ+qxRT8bYr+yXhr9lWCYNRit4tN8fLXvtaPH/vF8GeNx/o6pbzNeIAqedJmkV4aDmAFogyHbSSxqX+VuRiFZTecyCjtbNyQJO/pkznUhZD0MnSflz7P5/CP2/8JWbxGYcBrLKFGmIMIkKHX0XHQAwnzhD7usp1ooeOEBcp+qMSDYK/RTBUX6A42Y6mFLWaPSsdRx0IDJdQl/8TWA8B2Oj5W+OgY47Cwv33AzrLUrUYeh2oB4yEelo1mCn+EkVQ+Z8ZSqIMP3p3pnrNzA9trWIz7cojr6QUKJvx8wQYHsaVZ34aj//kJvSEEQI04Zc9NBoNUNuuWqpiZGRE0nOrO9ZEkVgTgF7TuOBz5PynXAtJHKKcOrJnq5UreMs5Z2KjIw5GzXNRzUqymeBU7HBDSS8sEWeb3l6Sa+qfDej3uyql/jz+flcFsE4AcNkG1DnT81YNwCrMlny5uaPilE8wIFKTDRLWuXXPCdvUavI0GKvykxHlF4bxwA234LrLLsXQI//GvHIJ0ciQTAayWOcpPkNUN4rYLIO3RdIgFf4TpRG40KdxhCjQFU8k4yqSUcmf4q5dolIZokyhVO0Rkb56GIABtEpPDzbZagtsueMOmLdoEbbcfgdYPR1ATx9QLRON6OgT28MoGUGEY7cU3wkqhJ+V62JNdgJd/ewNpM0UlqcjCllUR2NoGX72pYvw4Dd/jIU0hWY8ymKKyvDMdPUT0zsErn5sicF1DQFCFSLlDy0lfVhrxhhKLbzo4IOw3zHHoPrC3fLoBZ+lhf6BQZTLvtwrdZWM6v30HMzPvNUc9mGSwra1SK7WAQNUEOI/P7gOV55zLroaTVF8T90UoQsM24xCOugbUfAzhYajwe5Ej8ks4FycLeqsse3WWMkSbmhMqjy1bDSUwiAS9G69JQ4+5khse/BBQF8P6lEGr1JBPBygRH4WO8WFVMiS72W8QoupqRWKNSZ685P9ntnEkD/nOlLZ67EoQbhNIX75jcvwu89fgln1ABko5WAjYMUob5HRvqCpzeFXc0zm+azV7VHlhvp1NsWOI1QYS00z9CfAi45+A17+6Y+h6TgoOR3ybIyIMiVtJNLMTeAMF2utunqKf+itSqlvrS3A+i6AY6b4Dc00byUplqI3syRV4kg4RfJyk4+Sq3tncV6lxTTYI4/i2u9cgTuu/zk6owTlKEAyPIy+jgoSKikbgMUep/ZPXg0owg6ZNniWqAxVqqNIqvRK1M6iCWqYSARLQA+jUjaJ5xkYWG+SkD2rFxttvRV23uUF2G7HndC96SZAb6+2iuHkE0QMhTFnkruocHeuSe0EU5QzsOnHl5OJDcBqyTkUXXPX9YhhpWKYwaLvDyNUSYwn7vkLLjrtw6j+83F4sA7VAAAgAElEQVRsbDuIkiAHWPriJkWqU0haR4sAlOX4YUK2RgqvXEIzU+hPYmy190vx5g+fCmz7PCRxBKvagSBNUa830U2OWJqMiVAYQCmaYc/mva/rvpzg+TgOjMgVLXRcRlHDCHhiKf73HSejce+D8MkbVCESTyFhpKERYVbiw81sNO1kUhyeySzgmnOoAVZiERCNasIZgKUSJaruMateSx6WpwmCSgkvO/wQHPaudwFz5iMNQ1idFQQstHBFrlMAZ5ykElWWkTZuM5ZRf67dVi3SJhbTZMhsS4pUXEqeUMICCZ76ze9w+btOR+fAMFkIwuukppjE/CxH5hm+++0GWI7voJmGArCqBHyZwrJmDH+bLfG+b30D6cYbwSl1IiKJn4KjwnPNN7aMvs8ArAm+/VPqa1copY5dW4D1dwDbT6nmzzRmxR4wIXb+nVflmXSWmXb431Gqq9SoOi77PSqxM1wUZVj++9/jB9/8Fh7+61/RZTlQwyPotC3MqlYw0L8MtqtTMdx5SaAsT3doojoJyLFWTqceE9N+ogTvIIxThGEEv1SRtF/MekFHIbJtdM+ZjZ123xXb7rELFuy8A1RPF9Ddnaf5RCUzT6iQJ6XtY5jZFA4W74GAMV9XaYQjVX0FAVIuegZgPevDRtSc2eSUbHf87drrcPlZn8bGwxH6MoUobgrAGuWa5SnJXFDV8HHIaSMZO4sSsd5YFgWw5s/Fu77wOXTsvgtQrWCYgqh8RkqDSi6iEguTNUprgZnDAKwNAWRFcSrj2+YfjtYm090Jbr/wy7jjsitQZTSVZGQCYUshGGqgz+uQFCyrXSdDkp4MwJIxnAMsptCTPE3I94oAi8FMas+xyrfOSlPfQ1Qp46mRIXh9fdhhr5fgqHedDGy2KVB1UM9CeUcqXocUndC2qaWSbwCWmSAcY7Q9ifDdZF+ucalLZs0YMY/jhgbK//4PLjr2XYgfeQwVRsmjUIo/tAyL0hs2QdirPib7fFZ3bg2QLVi+jeGgJlH6MtmbykagbCz3PLzxkx/F8197BDLPRSDq+w4ybgTEZoCbU1IbJtuRM9+fAj3wD6XUDmsLsIYBdEyBRs80YU09UOAK8aNaCiH/w8lKAUNhHa7HSrQUWX0IVbcMDDXwwLW/wM1XXIXak08hHBxBlSRqZSFuNqCSCG6JEqJ6Z81FSJN3zTW4M07hW6RAeWLnMTA8LNV85Wo3KHpZi1PEykEtS1CeMwvb7rEHdt9/XyzabRdgTq/eZpM7pUNhsrMTmUYS3CUNyNSiXiQM06VF28i/UtGc/RbAKgKMNXXduvo9BUJJ/1GNEDef+0XccdUP0d0I0ElQSo6UqNXr/iMwJSwlcV/I/TQNZuTBslGiEGWTKVQbyxWw3UH74TXnnQ30dCC0ffkeoSVTEAI6DcdmXd3IdDwP9wlxJP3pMlXM0RIEUtgwcvc9uOS9p0MtWQqLQVwajcNC0Giiq9KJWr0paafJ6ChNdgEnwNLkeMoNaB6WAKzcu9OhcTTFbB1HuIl18h07OxDYDp4Y6MeL9tsfR55xGrD5PGQVHw1azwQBev0ueb30psi8IIUKGG4IBFtNDYAlht5sDXmkBFjctYw0cc17PoSHfn07uhj5CQK4ogmWCs9JUxFWL7Mx2eezNgCL82MDkfi1MiJN4O6VO7E0TbDFAS/HUV/8PBJWCXuEX7RLottDzh2bAVfTcdZZWZtHlFKdawRYWZb1UYplfbnr9f8+chX0fKIckwqwgFocwXapmxMjTmroVqwSHMTdV/8EN3/3KsT/fQqdisRSbW/DikJuHul3JpwqRrBycGAMV02fchGgsnIQBBK9KnV1IXU8DDQbaBAklSvYcscdsfeBr8TmB+wHzOqThY8LSUq+CLkzlmix5xYxtKYZy6kIw1jrdK1iHeD9agnSnFD8HD9wXjmW1BSA4TquOPH9ePzOP8INGujgDlusPsYDLC1bwcWUvKkoCuTfnuXBpdIAbNSrJRz50dOwyesPRdJZxQjFQ1MHXeyLCFKFSO6RiWBtCJGqFR6toG4tSUF+t2iqsgKUfKbGCOxmhGve92E89OvfwlUZbJKQqTvFBbCjA7V6XRbsyRyTXcDHAiwCLa08bwCWRXkz4ULzHbC0+0AcCfHd7uxA03ZQWjgP7zz3UyhtswVQLiOEjUatiW5atRQ2W3oXwv+TnQwJYLpquJ2LfJ4mZIRae4qyjQlAf844xl0XXowbLvkWupj2DAJ4dGJQqfQDQadFZLaaY7LPZ00Ai5NjnLLa2JKImpOmaNYDlMudGOFLPX8uTv3ON5FtPh+BV5L5NU1yf1VyUycz+Ga+O9V6YJZSanmxUSs83yzL9gFw21Rr+Ux7VtUDeRWSKOKM262KYrrWVWo0htHl2cCSZbj+fy/FbVdeg85GiNlUvQoS2Q1ysRewlGVwfU/I0wEnc+6sC5VOxjvQTQE/pBGzg6xaRs0B/tsYFomEFx64P/Y95BD0bPM8rYrOHRsrvCiVQOsPUXXgdVc+ydCLjyXuLkvS8zVByCUcsTlX38xO3P2PB1hmYn02gYeJqollBhs31MSVR52EpX/+G1wnEYFExXsWgMUIBUv09f1EOcBiipPRuoD+iKlCJXOR2FSYr+JDl34d2H1H1NMQJa+qy/wZoiAG9YGRqImK5+vKsXFHkYu13r47DHoyler6OQdQDxSmmaKkCS9N8a/v/QhXnft5ePUGylGMisqtk8olGdvEV5NxW5nsAj42RTgKsCg5ISnCKEFPtRMDA0NiKD577lzESqF/aBBWpYyRLEFQ9tCx+aY45dNnobT1log8H06lA2GY6srKPOysDYY5fMTaQOe2252iMmPXUjKMdREs+UkBdy5YduOt+MrpZ6ArTlAKqHem35+QhTwWKQ+rhyiTfT5rAliU32hSGLazhDCO4DsuYnGXcBFkSkDVG//nQ9jsuCPQoIE7+z9zEaYJHJvyIu3Ft+vt3NCeG3uZUurXawJYpwK4oD3tm7nqM+0BXbLOIy8FX8mGLhoZhEui+OLFuParX8ed112PSr2JWbDhBzFKmYVao45M2ejo6kQzilGv11EqlVpE6bEgS0dkCBbc1EOQKgwkEew5vdhp/72xz2sPR9fOOwC+B7CMOhX4AZtE9cxCENLs1oJH5XJBRnqRK1CIWlZ6reonsxPPP9/6uZCDV4xeGbL7s1lZZwCWyC9QI2y4gWvefAqe/ONdqHSWUKsPiPH1KMDSPmoCLsWfjAtJAq/qo5mmAjg7rRJSWuN4Ls64+kpg8/nIursRBylcev/wcYchglIKu8y079gUqeGfPZvA8pmO0Wft8/IAtIJ9wqINUetnF+kyinIzEO/Ms49/O7ynlqMrTFBWjtg6heQn2azkpLbSxFs4mQXccHjEz4DjON/E6N2CjmI5FNBtBvAcHyXXQxBpSxmRPHEsNKwUqlpBfxiiZ/Mt8O5zPgl/551Qr9fEY1PGS77REkwl+xMKdk4hgFWQFomTDA41XuJAVzffex/OPOHt6B4JUIkT+CLWmiGwWIVMDTRaIa36+U3m+axpVPD5eaRC1OuwO3yM1GuolisiRGzHCkmqRGR0+9ccjAO/dBaGnRSl1IdrewiphyacwRmAtaZ+nka/P00p9fk1AayfAHjNNLqpDbapnFcoSpmkCTzlChiKQhJA6QNIC44EjrgkK2BgANee+xn87robMMd3EfT3Y061A1mzKZERnQbMXeoF8GiPNe4Y00ibJZeqJSwfHBCxTJFa8HwMJDZC18d2e+yCQ958FGa/7MVi+SILn0+1aR3faSlOEyQU0xa23kyvKlEzZn+6som0jTF2SQ9mqVaNIMAKEnzvtW/D0rv/ArdkIU4aGmCJ2bC29DAAiylCRgKZMoiSUPg1nleCqsdIyLea3Yf3f/2rwC7bYiRLUXZLsMW6SEfwkjL/GYFJBxPQk4U3l2yg/c4YC6T18S0pprty9fRARPaZZI0kYkX5kas/dQ4e+tkt6AsTeMwoOjbq1GNjxSZFcycBsCbTrZL6K5ibi0FAbnyuddN04YP+XL6N4vuj9Uq11yatldIMndUePLasH1u99CU45sMfgrUdI8f0pmTBCVP97JFcyw4xPF43aAJ+ZWqs8Pn9acN3vk8xQGX+J57ABe88GelD/0YliFAmGKVvoaNkDhoTtZ/Mw5jAd3WBiubNGesvzmTUt3NSjisLyvExPLsTH7zhSoRzuuBZVQRBDMcv52B3anT/BG5/5isr9sC1Sqkj1gSwHgSw1UzvTf0e0BGUnINF/0BOyGIpk4nkVVpviOoxFi/F1Wd/BvfffgfmeS4aA/3wSOmg+GeiI0CaxK75VmJgm1paHZrVSLajNfF8FyNhE9VZPRgKGvjPyAhm77Qr9n3tEdjz1QcBs3qAqIGI1YSVkpCyDXDSU6Eh4Of/Hqc6bXp8jBL9mMcwVtFbNvptfEwa4GbiTygxulqIH5/wPjz6mzvR2eFhZHgZyi77jl54Ok9jFlRtdp1XAdoWmmksHCyS3JVfQr1SwWEfOAVbHfs6JKWSBqGsKBODW6BmM0lioQIHUbMp0cbiIcR7V4Pu9fcgl4h/tLaY9EvO46Z4Ln0IVRrjru/9AD//zBcxp5kAzQAOie2uLbpLtsqdDtrQSUWAJXsOvoe5fAIjxmZ8M13Ipzga8cpfJWrPMcVMs/BajN658/Ho0BDm7bwj3vX5c4EtF6EeNuBTWVxU/l2B4wIKWgB8chy0ddZtBYAlHuUEWHRgWL4c3/zIx7D4tt+jJ0y0zlQSiVAydb7aCbD0+6ufk6ZikFdJgAUBWARarKYe6ivj2G+ci433ehHgVCQwB8eXyYspw/X5DV1n42N6nOghpdTWawJY3COLPuXMMfV7gMJ7nuvJJCsvvGVJtEl4DCxhXtqP337z2/jdVdfAWt4vEgwqixFZkXBQWAGooylaisFAGL0LAyqWjzSIMFKrC4m9aWdYPDwAu7uKbfbZBwe852TM3nYb2NStylIRF3XL2r5Drm888fRsJLMJ5xdT+0MHPz3BiGpXDjlGIdbYIuwVAVa7vdiY0mB5ts0FcbiOX51zIe646hrMLrmoD/SjTBFSwuB8Fm1FLGQyZoYwQSlXqC7ZLpwGAVYZ/baNeXvvgbd84RwEs3sRWx6iLIETsQ9SRJ4j5htlke8fjVaZFOFzwUFr/9uRAyw2hHoLlqaocWyVyHGR9GGC+v0P4cJj3oHO5SPIaiPaRLvia+4M01FtOgxgkqBNi+eogZauLDQNyzXrCn6dxcWdkh0dXgWLlyxHuasPYWcV/vMW4aQvnAcsmi+keN+vyFiz4hSe7wvnz1Y6+tm+HihWJedTRk4XsEToLgIaI7jx4otx5ze+i7kRBGCxGrRuaw6W8NTaFIHULR6dobQHJSP/SuZOtos80sGyjV3fcTQOPOWdQKUDCceq7QrnTFTd2zT+Zi67znsgUEqN2emOzcBk2QIAj6/zy86c8FnrgfGpIJb8x1GAEoWVGk389tvfww8v/Aq2q3SjJ8mw5D+PYdacHjEbJoeD5rPi9TdGqwkggZ0l4rQToRaPcn0BUUsYoeooY8+DXoH9jz8e2GZrJLYmDhPcccGSCU8mSM4ghR1yng6kVCBBFgcfAcKYCXLcbDN27mS8bhSIsVNZ9tzOgxMoMSQ16q1mhH9fdzO+fc658PsH0cXoQhYJn8bcBxXwmTqQ1KlYAyXwfRfNeh0dngdVD6HcEgZtYKivA8d/7tPY6MW7QfX0SYoHWQxHsSpURy/JwnLyJCF5ZyxSKOcA14CtdvbPs3vtAsACq8sgWkMcQqxuVWmEOG3ASTNcctw78fSf7kGlGYsEACswOWaVsSp4dhu6yrMb0+niGNGpwlGANerVqb34JOnOKI9sYmKdyrc9qY4slzswEMVY7tt4/sH74fVnnYG04sPiBog5Rerf+S5CxcrLWEyITYq5HV2Q8+9bnpS8b7k3bhgJsJIm/nH9Dbjy1DOxIMrQwXfHyjCiYqlcbi/AIorKAZZEUR0kueekaRfT9MvtGF277Yh3XHgesGCBzLeWpWMYM+CqHaPuWb3mxkqpJ8wVxgOsAwHc9Kxefubk67YHcscFzrJKFM4jDTqGh/C3m2/F9y/4EtInlqK3GaPPcWBn5GiFCN0MiqrPCWnylmg16TShhjAkwcourEkAQIsaH48sX4aktwuHvvVY7Hn8WwCaKocsJSxTY0BmC9l9c1fJ9sj/Rg9eicDAkG15HUawWuEsmXEK6cPxPcXJjBOZTGrtBVbjm6a1rDKkD/8bXzr1dCy5/S5s1d2HIGTxgCkK0P6D0idcKIRHo01uw2YNneUSLJr9Eng5LpapFLX5s3DSp87E5i9/GWJGsNjX9DojibnSgThKYNPLcSXK7eSqPJsk/3U7kCdytgLAUuJgpxctSTHxXymSlN51wK+/cBFuuewKzA5TlKJE5B3YZxyRk9HBmkirV/Udw7MyZtHy95gZejzAIj8rFYkTUi27u7sxsHQQjSRG7+ab4v6h5dj3uKPwqg+8F1kUQ/XM0ku67YielsVIXqEod13ey9qeqwWwCmT80edHM88Ay/56Dy486kTMG4nQkSkBx0NWKBtEEyla2+ut28+Rf2W4ctxlaYDFuYm0ABmLtsKwlSDq68EHvng+Ki/aDbFN5iULiEanu3XbrpmztbEHXqmUunlVAOuTAM5sY+NmLv1MesCUsenaa6pJSfqPs+3Dv74dF374o3AW92PL7l6kS/vhpgm6qhWMNOoIkUecFAUstVWHFsTUpFrqucjkFWWodvTgqaEhNMoVHP7Ot2HHNx0JzO+jzgJQ7hAD6SxOkHkKiuJ/eTm4TDCjmUG5s2KTRXFBODTmplcDrlYAW8+ko57Fz+ZtD6MmPEZDmnX89PwLcdclV2OBoohlrAUk875wE108wAgWOSS0/KDeWJSGqLDiMtJFB5bjYURMY0vo3XZrHHjssdiSJr/CW6OTdhloNIDODpmlTdWnSREbP8Zn8c6nwKlzgCVpZ62fxjHbytrI4COXJ8CTv/oNvvqRj6Pz6SF0hilUmsL1PK1h1KYwggFPZrsgwCIfT+RD6qrCsd1slP8NwdpztLQKq38HBgZEsLba1Y0nl/dD9XZhoOziyJPfjZ2OeZOuyqt2SNFJnbpg1NBqcxRlPMBin2gOFhsWIssCJI8/ifMOPxadS/pRDVPxPjUAi8Ke7UoRGmsjPV+OAiymCjUtgLWsMQKKCZdLeOMH34fnHX80MhazME3IB9/O8OEUeIPXwyZ8Sin1iVUBLEavGMWaOaZDD2iWtY4c0auLFYXNOjA0gD/f8H/4znmfx6ZuBY0nn8KsSlW4OlGsU0hMj4ioaKwXptDWRGwjdOjSRJkcgloIr7Mbwymw8a474w2f+DiwzeaIkwBOdyfL6JBw4nZcsdVJqJQdc2LM4Lue1qkxNAUDpIqLxkoCUc+EUtGmtVGPjgJa5EQKxehhiCfu/ANuPvMLGL73/pYRtu5XQAMsTsYqj/bZUomYuTTDjkSYtKQseJx5WeZNUVHPQ727S0yfD3jbCcDc2cDQkIgYLl78OOZutkhK93mQUyepL8Wd/vo+exNgMRfI1CDJ2xY85p7zaIgOchJghcATj+Pz7z8N4Z/vR6foKbFMXldythNgmapBnfobrd410w9HTTGKZVJPAipYpOIoDA8Pwi+XhO9IsO7QUidO0UhSJLSumt2HM77yRViLNpGx08ztpkKSxqmN18ajNSXkz2wMwEKMxAphDw7iy0ccB+uhx1BuxlKkMGRHSGytnN5OgEVqBa9P03ZRGFOaciHjilISVioei45Xxrav2BeHnn82so4uqLSg5N7WSayND3/9vPTNSqlXrgpgPQpg0fp53+vhXRUXeFZD2axoo1VICCxdjsaDD+OW730f/7jzD4jrI6g6Dpq1EfjcuVoOnITq1nqKI7iKWf4iqxM1eDIBWL7lY6QZIC2VMOJ6mL3j87Hty/bGHgcfiNJG80j+0OKh5I2I3EAGm5O6LHg5R6oYtiqOvJz0bibZIqF9PBZrVSOOR1+FyWn0V2Op8a0KxnU9BMx9EeR6DOQxLhjAjzP86oxzcNeProMn/UjR0dFye1lEcgPtNLElIuVUHQw3hqBUgqrrwQ5iuImClTqILRtBuYSnswRRtYytd94J8zdZiP/Wh1Habiu88sg3YtasWQKsitIMGwQHK08MUr2cEMUhwDJhEY4N8ni4AoZ1XP7hj2LJTXegu9GEzagCgRfThG1a4HT1bp5KWhXAytumE+4cSwQUrHwk8NKWSSR9M83MaJzxVeSPKPvBYrzBLEXX9tvgvZd+A+jtQOS6Yp2lNadG3xptQK4PncYe/Y8VXruVbZYm+35xQ9ciubMRMVI7htVo4tI3vA2Nvz8Ap8lIsS3WNKygXJMO1mSbtLrvFyNY3DgRYFEEVnxbld6sWp6LZrMJx/HhLtwE77niUmCj+YDSVYRTjOnwbHbXhnLufyulNlsVwKoL73jmmD49kE90Mlmbsn9WtpFkTumGKEbwt3tx+w034q5bb8Xwf59Ej1dClTbNjRE4GdXUFS2bESQhbMeSyAf9slQibAJYlo040UbNse1gJE1QmtWLBdtsjT0O3B+b7PR8VLfZGiiLUx5iRk4U/53vyqkJU7DAoYwEuQq05GGqhnIRXOg0XslTI/kTyDGYjqTzA+NzjHmFPtOjkuqU7+UVla0U5SjvaYUHO5nFlW1ppoBroRk24PL+CTC5qt33KC752Fno//sDqDZDlKNISuOZw6LNDQUi/WoHrJgFAilipnZzsryYwWaQQgUqeXMmpjVKLUkQUkzTdZBykdx0Y7zvG/8rmlmVSkWiVhtGatA8RbMhMIiKHThWZ42LXdCsgZ6V919/Ey5/z+nYWCm4DrlLMTIZp+07itGp1UdiRos7yLsyK7MGh1qLyTgscGMkXL/Mgu/6eLreQNTdhR0P3A+HnPFBYN4sZI4SNXRuhVIahbP6WN5R/a4wRacEuPFd1txJPdXo38tezCCxib5DckLyEPje6vdeb8pMZD6R4ht7aBi3n/1l3Hn1j4Ckge5yCWFjWM9TbUcooxwstj+SftTcLD5Ppqwdx0MtiBD39ODtF5yH3n32AjpoaQThwE20+9o3ameuvJoeaCilKisArCzL+Kz5zGeO6dQD+axkcIeZ92gzJpMg1aw5SQYhkr//E3f84kbcfdttGHzyKVSVQtmKURvqF82kaoml6w3EYYSy50sKhbuvUqksZHgu3l6pIvZvtXoDTYqN9nSgsmAjLNphOzz/xXtgi91eAH/TTSBCW5QUoHo7RbmiFJSUsGjjId6IlNiKUaG3XpYISZfpDu6iqS1FsVSScM3kQ5HNls+iAVt6vs95SVpgUi8EpqydEb1cK6elw1XISU52ZmOn5+WQjaAOt1qWKEKJC2CcYultd+LSMz+Dcv8QnMFh9DJ1k4aopXVkFQ/LBwZQdjpgKxuWbcP2GIWhrlGMjB6SXPjiBN3dPWhGIZYODaFj7hwsrdXg9/bg5HM+je49X4Kku6uVDiThmc9NuoiRjvVdB8tYgRukYookiKyYOtR/wYsDLP/jn3HxCSejL2gAaaD1oAShTK2CiWc2/Riu1qhRtOEEEWRlCetbbYTlEtLZXTjs5Hdiq9cfArgKqU+rFt1BCT0aZfRpjqDAThOlYgFM/m4xSkMAtE4AFp+dYEVWFesiBUI8DbC46UoRWymcegN/+9K3cfM3L0McNVChykHQFImDVNJyz6zH1uWnDWdOoCK5gDr7r7eKrFYNM1Hhr4UxgmoVh55yCrY7/k2IO31EjidFPu1N0q7L3pg5V94DnlJKOButoZllGcVFKTI6c0yXHhgXt+eLbSgo5uFKlR5BFqMqNIzl34/8G7f86Brc9otfIF26FHOrVSQjDYQjI+irVOBZDhrNmt5Reg5sX/u2kUxLmwemGK2Ey5MSi5dGkiBxXZRn96Fv042x5S47Y/dX7IvqLrtomQa5tgWUWJqsvbuUsuH7vpCzK2UN+NMkQRZnsP1Rw2caiBTJwMUAFicmcjDMISH7HGCZ+x+dvPJFVKoQx2Q/Jv60iylaK0FqcZGKkSUhKgSVYYz/3vT/8N3PX4jhhx5FH81d6010d5SFjEwwJFKjWSbpPVYisq8cgq381fTKJQyM1BC6Lry+HjzeGEbnwk3w5ne8HZsfcghAbp2rozA8TzGCVQRbE7/JqfzNAqO9lbLKn/M4gOUEdVhLluHrb3kHokf/DRU3YVvTH2CRz6erDXPJ4VaRilYUj4IIPbPn4F9LliCd3Q1v4cY47YvnwdliE6BSyr1zLMQFgKXfq0LEmP2UR7EIaARgmd9L0cVEx8gqAJZ5rxQ5TBHcMMbi7/0cV3z2PKRBHQ4LQjgvcF5RuqimHYcpOBA8OE5aQ+yz2E/kurq+sDaGbQfbHrg/jjj/s0g7XISe3/Yqznb02wZwza2VUg+NB1gkZt24Adz8+nOLZpIzTzJPExoaCn/M5YYTopWGiIZGwNiRokFwkgCDA/jTT36GP95yK566/yGUycmoNeEmKaqMWmUxalEgejPc8Qq/hxXuzVAI8hW/ImlEAQc0hrYUhuIIDQV4s3rQtWA+9nrlK7HTXi9GeYftNcgi74VAS4tHabNZQQf5YzEE5eKkmQOi0QjVaAGOb1JCeR+Y3aP+T6NRY3oij+wUePcmADbRQRHR9oK+dnnf64AiRV5pNkwPIiB58F/47gVfwAO3/x6zSPsfrqMsdiA6oel4NNrWN6xTshp0RQmJshZCx4bd24sHly7G7O22wnHvey8WvPiFQFduop1HrAioinING0YEi71WqEQ1EazcUoacB1EQadZgRxluOPUj+MeNN8NHQuUs0YGbzkfLGSBXgNdjiBXAWlHcos+AbaOWAf0qQa2jhN1etT+OPOtMHS5i73k+Uupo5ZE8zhcOB7OhQRoAACAASURBVLIxVx8DsHjG3OWhyHWbSCfK/CWNZE2zvK2SMhsPsKIE8S2/x4Wnngar2YAK6ujyHMRhAGV5bQVYUhFMWZVW5CqXCWnNPYl4sJJrOZgp+IsW4YPf/y4wtwuB649G7CbSfzPfmao9cJBSSuSuihGsMwB8dqq2eKZdK+kBmYhyECHmwbndRkFrSs9V3J/qyYu2LlkWC2FWJreRAPFjj+OO627AXTffCjw9CL8ZIRkeIqaCV/JRCxpI7Qyu72l14iCEijVpmzyhhNpaTEN6LlLHES3DKMkQpxn8Uhl2RxWLttsWL9x/P2y09wuBjWZpCWM2uFTFSK0h0THq+FCoNCOwSFPYBHRGyG8M/Urv1mWizxdS6R0zmlvifwXglqdCBMvlYIj/nqySNTGUWaODMIBH8IoUYdIUAq5Dm5OREaiBGm79/g9x+4+uA57uR7kWY3alikZzWFQXWElI3Sq5DUa/bKZKyZOx0XRYlq7wqje/Ca849s1AbyfQWUXmaHHNYhpw/U4Jjn8HTEI8B1jy/PMIFscF+zUfEw6BfZDgkcuuwBWfOx/dNHpOtOn4dD2MEvyo1VWeJmSKjyn2lDpXFhp8X8slNDwXg3aGIVfhQ+eegwUv30cbsrsuZXLBWUG7hkI8G0XZVrxcCIK0OLC2v7I0NjMAa6IdWOBgEWCNeR/5SKnrp2I4DP/c/QDOfftJcOp1AVjdFEttNmDRt7NNGFlbHek+D/i+UtKO1Axy4HIdrJA7UIo+p/S/tFArVXD2lZcDL9gGTc8BIVabmj/RpzbzvTX3wEeUUueOB1jfBvCWNX935hNTpgfMDlCvytKsls1GTvXWG9FM1N0ZJfEk2pGCuk20wOmsdgJhpAkEjz0pRNI/3vRLNJcshUtrjYT8qAAWIyx0sk8ieI6LkuMKER5xojlVFtCMEwSJ5gA5ypboAPe7TqmMZpZh2ErRvcWm2H3/l2O3/V4Gb+vNAaekI1q5doyQsYg4GDVb0zEuetUCWa3Uab7wykKQk3HWIcAym3yuRdzxm2wJ05phHMAmGT1nlSVDQ/CdErIHH8EffnEzHrzzbtx/993oqjCaGMszYkUYFzDyz6TU23HQN28jbLrtdjjojW9AZfvn6+1xTw8yT2u8EgTTbHplx/ofweJdF4WvVgOwWERQayD7/d345EnvRjVqwk9SSdVO16PoTUjuj0kVcohwgSfBmql8DpBGFKM8pw9P1moYsYEtd90ZJ517DrCQfElXxluDuwXLFl6QAKxWBEvzpBhBNpWG3NxMGhishORuNjzUwhI2pUpgc3566HFccMzxYlrvBA2UaPbMohHSHtp0GL1Azn11V3Ph3ES7YLSAl6P7jLpXsWIUy8JbP/lxLDrqMEQlbXf1rFU5t6lfZi6L7yiljhsPsH4LYK+ZzpluPWAWmLyczjQ/j6ywEMisIYwSEfy4LqcxvftPczI56uRpcWa2gf88gV//8BrcccPNSPoHgOFhlJRClRwj8qfSBK5lI4oCeFUfQRqLDlPKELjvwy35gpOaYQTbcdEIIyjLEYI7OVtBEqNn1ix0L9oU+x59JBbu+Hx4m22Wm3dFYuUh6uZUR6dwqalGFJuZQihLhDpzHbBxs32rImslaVRN6tXHZFKEPDWrQoRErclfulvDWG9jmcawMgzUB9BV6YSHFM3FS1GiOOtwE40HH8RDf/0Lli5+Ck8uXoyRoAHH9dA1ezY2XrSpSDFs8fztgU020RWhpbKkVmVz7AGNIEXZX3Gh2zB8CM1AHyvJ0Xp78wgW8UWcpPD5oGt1YMkynPfGoxA/9RQ6acxLBfxxXMbpMgOMAixKAzDao7lYPAzA8pQNprG9ahkD9TrKs3rxxNAAyrP6cOCxR2PXtx4HdHZKlSr1sVh87FoKfpHsmJcNjlYS6ujxugZY0m6Nq3TBMKUOaKYehcDiAVx07AmI/vsE7GYDdsaEJqNH7QPIfMUpyExwW3M1F86P9VzAn/N5NH2KjSq4KasxPdRSGzsf/moc/JmPIOsoUZFsmhdZTJe35Tlt5+1Kqb3HA6xHALT0G57T5sxcbII9YDzuNFlaJjyT8jCLhpkoC0gi4YTFyczzxhJUiYpEWZ2pwzrw9HLc9O3v4IE7/4Bl/3oUHWKim8EKIniSxgICFSK1FRxW+fGkeXpPmsLJz3ERppwILeFwpZktVYrkjiS+h4GSje6FC7H73ntiz1fsi/K2zwPK5GilOuXIqJlIOOiyc02uzflbvKKb+7YVetDUhbXAmOmLAiHXRPomMz0bgCUct1haqNMqZqWg+TXFW13Kj4bCzaJ3oFyTu3LJYaVAva77nGKRco4AIAgmoCJYo84Yt/S2lCwgirTAJIORxUXOkNwN0X3DSBeuAmAVihlYASt6T0w1BSG+8sajMXTfA5jrlRA26+stwOItu5RI4ZiJUzhlH8MseCn7UGUPze4ufPhblwLzZgM9vRLFopcjx+cKAIv0yYKnpkklThpk5Rs98eY05HkTl8zJWA7J7EMB/vctJ6DxwKNw6iNI4gCO+JyuRaR7grPrmr42HmAxklXi/lCiWHz3gZoTS78SYBFMNeGh5/nb4KQrLgZ6unSVdRvvYU33OPP7CfXAo0qpzccDrCEAnRM63cyX2tIDRvtJyxLkmlNaTGksaXx864pzUkvXQZcYUw9LjEeYYuDE1owxfO99+H8//DH+8n+/gjfcQK/lIqs10WzW4PaURH7BTjJUHA9uliEV8ACxImkmkRDgI2UhFrV5kUJtTSqsGqQtTOgq2N2deN7uu2DPgw7AvF13AXo6AZ/pQ4WMZHjLEZzBPwxeCbmUVYci7zB6cNIXSQkTnVhpFKtw4xN8ejwt71QkBg2QLW7zZeevVfb5uTxmKFcj2JKS9JwIn/9QR/Hyeyu6OZoo3iiQzhs9+RVugnc/Rb6WP3gTuRntjjxlntMUpYaA8gxBgOvPPgd/+9mNKNUakjJvFUNMkVta22YUU4Rc3MdHsIwOk6l2I4jhO84Fn+/ioGdj96OOwqs+crq8UI00hlvpkOiuAKyWuaMe5M82wJL3ovU8R98XcuUw1MC1H/047v35/6GXbAVy6jjvTbEIVjkimEpbAGvEjiRybwXkvlqwS50YLPs443uXwN5mS8BmFaS1Ui/RtR0HM5+bcj0wrJTqGg+wTP3WlGvtTINW3gN6DtQpwlUCrPHIo0UEz0FYYRJlViWUCjsNsrjwlEmHHxiAcn3Ef78XV3/xa/jrbb/FbL+K7pKHRm0IFc8TYdOgVoedpqhWSlBphlp9BG65nJcwaxIoJxMjDsgdYI9bxvJlyxBZCqW+XgxlCYYthS132xkvOuAA7PTKA7UUAb33yMtiCpPq1QwC0ZBaQBsQZjEiCnQ6YgDUqp6UaNHKghxMpRRJ0RMYZEWAJdwRk601gM5EzHL9S4Iss24JLaxQ5WkeC5kco81d8ZVsRedmdr0FD0vDPdQjS/elkeVgUFUboVuUwYgj3HnJZbj1a99CR61JFaX1BmAJxs9ThHzLNBeroFll3ANElBQYoU3OFpvj9AsvBDZbKBHUSClEqYWSozdso1pYeq4x04l+wyah0NB633T03bwPxuZIwKL8hjzQCGiEuP6ss/H3a36B7iRBnIX6mbZRRWplHCxa5hBgkexOkdS6m0BRdiXkztBBankYqpTwji99FnP2eQl3oUgtZwZgTWD+ncJfyZTSpGidVcqyjQH8dwo3eKZpK+kBHTQZXY714rJiyLxIpzBUITOhMUAtc3IBFHCJFzsXlaJeH0FntQw0m9rc2fIw+Pvf44qvXYJ/33UPFqYOvJBOfAyFA8qxpGjGsvUEn0WxVBvqnalpW6GNUSQip5lloxZFCFmRWPLQtGwMMwrV14c9998f+x1+KKrbbafThwRaeX6MmlNKCKY6xaADSApxGsOhpx/V0M1CMQZsrhuAxUVHLxG5ArbZhRejZuZNywGXAVlFHrHRFhLhwlY7NfGdD6j4rFuLkVx3A65CKoxZsyAzPioRzFbKXHOwuBjbrOhKQjz+y9tw+amfQFe9AYuOBStF4FN/yilWERqD9VGApd85412o1d8NEV4D0rrj4LEkxpve/1686ITjgWoJKd0alKO9Gs17k4/b8QBrXQRPzVBvnSvfU5jqT77fLieoKMGt51+IP176fXRHEfi/qQCw2K/cmLKKUHOwLOFfiY+rpV0b+A4zgmXbPupRgnqlgle97yTsdsKxQgNI7RmANfXftmfcwk2UUo8bgPUSALc/41PMfKHtPVCMd+h1XO8Gi4EbA7CKARYNCnQVtk5VjSvIklQVWZxAI6b/FyNDEeKhYbjlKvD0AO67+f/h1ku+g2hpP5rNOjyXlYMJAlrwIENHpYyUWjX5+fXfWila1HpUqs/tUzVeW8aQDK9c8rYyDJLr1dODYXr59XThebvugpce/Eps8qIXAp0VoD4CVCsA8z9xgojeZGWfTopjbD0EeBbBlemddRDBMgDLgEcDHeVezTWLES0zYvI0IDkvPJhi5FxshMlbA0sIXhoF62glwYM+sSmq32CrkAr9ahbkIsCSPqIUGYs3mGEm/I6aSB55DBe86ST4ywZgp2GrpL7tL/MEGmB0sFYFsEx6UI//fPzkaCawHfQrhc4tN8MHv3aRNhHv6kSWp+KZhh9N2RW3crnH6ATaO/4rYwCWmahIVci16hQBFr+URPjdJd/CbRd8HZ1BgNROkVn0ZswLX9ZBWyZyChYTSCFFrkVn9McI2lMaPZNLKoKjgOv4GAxCNCol7HDoK3HEWR8Hqp1SLVzUr5tIO2a+M+V6YC+l1B0GYJ0M4KIp18SZBq1FD4zNfxVxhPmNie6MX7/N77mG04BSUeimqFIqO1eSrB3hZnHXqBNwKeIohBsmiP7zBG686of4zc9+Dmuwho3KVXjNJuKRYYkMsGKxKP4p2jxSZaM5X42yjXocCsDzbQ9ZmCJsBvD9EqrdPVi8bDmsShmx56LOBbLsY8sdd8DBhx+KuQfsryM8nqsjWgJGGN1SCCWNkMJ3y6Npo/ERLOndiZNkTVRJg1x9HpP+NKmqVspq9GGMSbuItQYBFgNq4x9QzuESWp0odRejlTqOpcHVxO9hLQbY1P3IOIDF3mHNqYlgGYAlVWnSRTHiqAZ3sIaLjzwRjQcehkcZgDy6M3VvdM0ta+mljtP1kpRyPu5NpM68BvTNU9UyHh0awDvPPgtbve41QLVDTJSV4yGKE5SYg8/dEfToy7meK4Se1tzGlX2idRrzLPPwrAh3ysaD2yUdefz71T/Czz/+OXQ2QoixmxRD60h5+w4DWvU7qD0g8/c19yQkH5QcVdcvyaaxWS1hzo474KQvfR6YNw+p484ArPY9wGfryu9RSn3VAKyvAXjns3WlmfM+mz2wIsFo/HxjJsaVRbYYFeHUIPMVJ2fm2EzK0Kzd5GZlCWKVaFG9oAFLKXR7ZSjyI1KF/j/dgxsuvwJ/u/lWVBoh5vg+VBRqYGCEP8XGw5ICQYIs7vwani1Ay050JSKrE5nUS4JYxEerXZ1oxiEClclOr0EzGguo9HShY+48vP7Ed2D21lsDmy7QQIvCf1ww+W/yG3LwsaIcg+m3yYCTYupOn4fLz4pPZLT8vJWKNXm+nEPWStMWv5z3/6i2GRebXCm+tTLNACwiKnIHZUHOn/iotId+97SNFG2MmvAaIa59z8fw4C3/DyU7lZL/6X6sDmCNvbfRASYitbaLp+MQi/beE8dxwef7RgP4cqcALD8HWKPgvgCwzBieYK5wzH7HAKx8r2IAllAYMs4xMR79xU24+n06tQtPSQSrvQBLUymEA5s5ORWCZs+aCyeFF6y65u/TDK5XwhBlanwP3oL5+MCFF0DtsL0Yt89EsKb7G7hC+7+ulHqXAVg3ADhovbvFDeqGxi/r+X+30lQF/lNx92lxv2qOFRdrVuylsagtyMGSd2PrQiudKI2gohi+ckSh/F83/x9uueoHeOre+9DrucJxKUKOlupyvtMm4IqiGLayUPI8JEGEsMG0oYuuri4MjgwiThOx67FLDjJLad2tLEXouBhSHnba+6XY8xX7YevddwEWLdL+hyoTeQhOaiuDUhNcE8aNqFGZDIkkySJRAGz5j4rLtw5KrQSCtR6C/r5Rm+d3+cc8GRFqoFiROYXc6wY10EdvthDBWiXAyjk9/CtI6aUJOI0G/nLeN3DLJZdPe4BlqidHSf3jNwxmcKwkzKNSiawEvovBnire9dlzMOele4kOXZZb54wOLT3WW8U0ZvyZQo4JDMG1B1jao3Pxb+/Ad048HZ3DNcQ+XwFGH1eW/p9AYybwFb151KKiTuroyBUpGlRa4S6S/ctoPXsuZkWOiwZti2wLWU8nTvzkJzD3gANmANYE+n4afOVGpdTBBmD9BcDO06DRM01cZQ+sbNGmplU+4a4AtEYtMEQWIE9vUb7PbEzlUqJKnEGlSgr4ZH0PY6RZDLdcQphXHFJtWSqLogTZfQ/gl1f/ELde+1N0pQo+DYzznZycUkjbeiKitpVLbSghxCcSvXJIGKUaOkuxSRB1lOzwxPOQityUbXAoruiBbC9aUGTlErbYYXvse/gheN4+ewGz+zQ3iztw0dEaTd+10hyCZPIOLRhA8yd6Ycn7T8JLo9y2sXimAGSLAMsQ2nMuyaiwqU5hjY2ojaYYTZP4HAy44s+KfLlWlJG/ECuTDfi1yAerMTnXSmGFOgGucyQhUy0/DVB2HahGgEe+8xNc+dnz0ZlFcLIkT+voxVqPy+nRp2sGWCvehwYF+v2nE8BwFKHZUcXuRxyGV/7Ph4GOCgLKn7jUZRsdXkV+4Qq6KBPsrjGZRv2SymAnYOZB2ReVsv42Rv8f/oxLT3gfqkMjiB1aS0Vwbbttz6pIfSD3agWAJa9nJn+SKEVmK0Q2qQ4p0moZR592KjY76k3IBNByjtIJf70or25eWgc2RRN8XjNfW+se+KtS6gUGYD0GYOFaf3Xmg9OkBwoAa1UtHuP1Z3hEY1k9rfV7/KIj4IEmL5p2TUBUsV0J22f/eQqL/3EfvnXOBUgWL0VHEKMqGpq0301h+zbqTC9WfERMBcJDlRysZqhV4V0blusgykM13AkW9+Ja94eVe478zc8xtWF1VrH5C7bHfq89HPMP2FfU1CWiZdNvjZOYI/aNcZiggxpbOecspGegr0EU74aLrmgnCUDVq7QGSavgoKxsQc4bvJpf5U9lLMAy8+t4yLzC5Gue6QYKsPR6bBLgeQVtIaplUqtMdbkUZk1jKNqrpBkGfvtHnP/+D6Kv2YBHpwHqtzG6SDAu+mnULRp9cuMBl+E1MaI63Q4DIAUgONy4MKHqIJk3B++/9nvAgjlIOO4tX/TbxMd0fMTKpFXXkQ5VC0/kgNlsSKRQhALICDF0z734+nHvQZnuEkpHxqeKl+So1pgeDdq2SKvWsfDHd3zUqEDvewiiGE7JxwtfczhefOZZSMlxLTkIEcOlG4Z4F+aRalfPO2bTa5TuWz+YfsNvur0uE23vf5RSmxqA1Q+gZ6JnmvnehtsDcRyKNIOOuGhpTOFzhSEwUAMGRnDHd6/Crd+/Bkn/cszr7BCTXXojOiUXywOaHSv4KT3QKKvgwrZtEShtNJvwqIFV3EXnM/FoqpGK5pb8YepwJA4QezYqm8xH58IFeNMpJ6Nzu62AchWZbSNzfGSKLbQQ1iOUCQhztwpT6k+JB5XE8F1jY1GMYGkQ2lpwZya4tg1+QiIt9ErR1pWkaHOz5yRLRHbAZvSzqb9R+/u9OOeU96H76eWohGELTBkujFHFb0VtxqHk6QywzAOTVBZ5lQlQTT00ujvxhi9+Cgte8VLEmQO4TK/rqIpUuBYAfZZvNyYt9JkjBxO8IoBYIXUoDhMxRv7+T1x0wrtRWdYPxe1SRpCVcxfaNArNOBh/eTM/cTxxw+j6HsIwFEkaRuI5x225z0tx0EUXA9UyQpcQUosP+4RlEpIll5Qm3K3AnjbZXgfp2TZ114Z02QGlFDVxRQeL1eImur4hdcLMvU6yBySClWWwJJrEOYHhoQQWtarMLuzJJ/G3/7sVt//sOiy5/wGUGxEqtO5IE3hlT0yRqQZfbzZFmVnMohmbchzECQ1fjUq1nl0IbvSO2kLEyAO9ocnRch3ha9XDAE1kiDwHnfM3wh77vxz7HXkksNF8bSxd9sUf0fYrkjrybAe2zOEUKtUaW4xipYKidARL0p8rieBNsvtmvj6JHiDA0pGOlQCsPIKgd/8E/vxMBtR12hn/fQLnnHwK7IceQWcUjQFYLQCymghWC2tQy2CaHpr4n0i4pcMuo9+28bxjX4PDPnKqmLAnVBnnYs9M+0oAlo7QTMZsajQ0s1qARUcJSrrce78ArNLSZcjSgLr0Ux5gcS5rcqNY8pEkicxtMmLTFB1bbYUTfvBDoK8boUO3B8bXuRArqCi3q3B0kN3EuFsAywy76Tv8pulbs9bNDpVSvgFY04RxsNY3N/PB56AHWikaGkZTw4p2NvwhFyyWT5PgQeJWbQjwfIT/+Ceu/PyX8NCdd2GBW4FXDxAPD8P1bEQ0S2Va0LFFpsGKElTKZcRRKgrwYvFhNGW4sctzCJnnIYyj1q7QsTRAE7V328ZArYnAc9C9cGO8/qQTseig/Un2QlqtIiq5wuPiMiEyFVHujM3UJ81zJaU4yn9qVVcW+FUz89tzMNBWcYkVAJasXHnMKQdYRnVE0jQEzE1arFjASA1fPeW9GPr9n9CVWzu1Ujo5B2tUt3zVnKzp7vdIDpdEsLwqlqQx0h22wke+/U2grw+J+FFRoyl3cJKUuQ4n8+14TgGWlSH45wP46ltPhrd4KdKkKREsW7U3LrCmCBY3iY1GA365JACLwEo8WVlN2NuLD/7gGmCLTdG0ExFbJgeVMTlFmwr6vc4ArPZNMJO8suKRZdkcAEsmea6Zr2+APWAAllgxEwWJ/Huez1MZopQq65wyMtgstQ4i4MmncfuVP8SvfvATOMuHMJvFNVmChkoRkcxO3SwqbyexVOAQLDFCpQGW7mTa8YhAcmaJRyH1rjhhcRGVajtWOnIXqGzYloNQ2QKylsQBdth/H7z2pLejsvUioLcLdVZBOj78TMGiaSB35GmCJs/jaEMQrisixGr4PQR6uaKFUXDfAB9/22/ZeHG2IoxFgJU/H+MV2QJYNM9mZCqKcfX/nIWHf3o9egKqgrPsn2OAVZsUsNQ8mjUd0x1gsUQ4YyGKW8LTWYolXRV8+opvobLTdlKp6ygfdP0QYryEqHWPZLlky3MSwYojeS3jB/4lESz3qSVI4saUjGCNHzOcv5gi9DxP5ihuBpkm5M+Xex4+cOllKL9oNzStSOayFsBq0jGa+n5jzexnIlhreiOn1O/nEmBtD+DvU6pZM42ZFj0gxPY0hEf1dZJiTUowF/0k3mpkIaIkRNXx4MjClgLLh/DATbfiF5d9G+kjj6FC4rHnIExizbtyHVT8EmIxdNUH+VH60FV4Ar5YW8TzcWJyc/TFasWUJHXS3xWa9QDV7m4MNpuo+x6WM60wpweHH380Xviaw4C5syixLBWMCSsl/RJSZUtYXq5TVLnn5aUEkOrNOr5BCLbBKqm3eZSOktxNCrdQMVsAWLo+KxGRXEU+D5Xd4xi/uvjr+O1XvoZZYTJGh8iQ2wV05SnoVd3qdAZY2paJ904xNgtDloUlvo23fvLj2O51h+TaLK4UeNAcurXRyAEW30kdc5nEsTYcLKYIrQzpQ48IwLKfeGraACzD5SPniv+mX6pQIBwHyx0Xb/nc+Vj46oOQulR91zQL0bprxrBcbwzAkt8Vijik1yfV+ZN4bjNfXZse2IEA6wgAP16bT898ZqYHxvcAYQaJ7fKep5noZHHRsZiiY2qB6TZ6c2k0BDAdQxHQehPD/7wfl3/sExh88GE4UYqeSgVJI0CaxnB9F3US4cmJkollrGKzqYRyJepE2JUhpY9hq9ZPpzW6yp0YGBgQ4JR4Dho0uU0TqGoFm+28A958yrvhbLWZ8CCYzmwq6kZTOEJ4tSjnRYStySxXVTe2NTMAq73vhLGKaumQmeaQt5cHHelCYNQsRLU9JdBPcN/PrsfVp5+BOUEipGOzXrWqB3OAJePLVISOW9D0kjg9DwIsajjx3inL0HQdjJRKeMGhB+Owj50GdHfpnY1lI7L1Oy5cLEb37Lzq0rz7E+2CZwiwmCK0Hn9SAJbDSHI6SQ7YRNu9lt/jWOJ8yDnQgHFRdid9wfXwqg+dhp2PPxbwMoRiYq83hlaQQFF8ME8MGA7WmGrW6Tv01rL3pv3HXkuAdSqAC6b9rczcQNt6QLgFTKvYQiOWg5M3uR02o1bMLfDvWBOMWaDEz9tMGT78CL5/3hfw11/9BrPdCspxKv6FFBUNs1jUkLVpLRW3R3WKxFiaZPfMFpVkSROK2bSCsi3hO7Bah59heJ7Ajy7UUm2YaH5D7Diw5/bhkLe9BVsfcSjQ24Fhfs/zUEZJ+zQaZXuJXGnVhkSMg3QEbQZgtW3YyYW5zGsi6TiBzZUArDRLxPybav8EWE/89g58/YSTMC/UVV36hAVpBi6Mhf82pffFO57WAIujOIjh+z4GwwiJ4yKrdqFjm83xzq9dCMyfrzltNgGWNmZqJ8DK/vWoRLCmE8DiWBEAGwTyt6ki5M8HXQd7v/1EvPSUk4GyQuToikGPccGQCqVioJlr+OXaeWNKLNv77s1cfY09cBoB1pcBnLLGj858YKYHxvdA4WUn4DFYRABWbr+jSIJpcZc0QkpsIFC054ngBgHw3yfx0y9cjH/edifSpf2owkJvTxeWPL0YbsUHpSAI3TrLFaRxIpOV42l7CYI44/3VspRhWyxtYyEbbmVJSpFpTJLjCf7cxBISb1Tx8VhQx55HHYHDTj4RyZxZiCsV2BZp74BjWNIEhbmnXYYYzaiJEq0yJQAAIABJREFUslsSVayZFGE7Xw1DClo1wGIVYV7jqkVzyQ+sN2Sh/uyhr0PvSF3SNyLRQEsT10Wa6LShpHjy2ysCrJVGFNrZDRO4NjctlEYZqdXgdnUith1EmYOgtxunXf41ONtupd9k20JEQU8CrNa7POowMKlAytpEsCTqGCF75DEBWNlj/4WluHmiVIOwkqblMeK62PQVB+Co8z8DlG0kvotGEqNke3pjR4XcQvGy3kjkt1qgu07Lm98wGv0VAqwfAXjthnG/M3e5TnugwAcQTZ3cK9oArDERIDMx2DrrQK8xFiA7cRNuFAMDTfz4U5/Bg7/5PTqiBLVlyzG7pxtB1JASbRJFSVSmV6GpFKSuDImh+nqjdeT8V2xrl3vh3otulTaZ9skdTQA/1krycamEEc/Ck4ix+Uv2wJtP+yAqz9sKcH3ESQLH9RHF+vp+2ZfqqZgaWa2UkjGxWac9O3Oyte6BlQCsgio/f5uyylVpgVjD4YujSLg857/m9aguowxgDtSzDK5ltwCWaYbwvQppQjPahBMzTQ8NsIBG0ISiyXNmIc1c1Ko+3nXRBejdc3chWlNlPLYIsOwxAMvUs0zq9icBsJCGbZdpmMy911wXfbvvgbd97atA1UJW8tBEChfuDMCaTMdOne/+mADrdgAvmTptmmnJtOkBI16Tp8+46TIBH1mwDEmcgavxsuTkcVgpQhWiRKJW/5DwKa7/5Ln47Y9/io3LVaDWQBo14FdKIptAgqhOFwJunEE5Nhp2JiCKOz7+3AAtAVmUd8gBnfkeI1gCsKh7BQt1C6iRRFsuiU9YZdOFePcnz0Rlj110NX8Swqt0arX6NIFvOSJBYXgUYzXvp82TW38aWtjRF2+qiHsIsCQ6VeRLMWK1ZDEuPvLNiB/5t3hhCt0uzgnvaR7Ryk+6PgIsviu0omF6PXE8hCwQyTwMKIUjP3E6tnnj4eK0kNi2FH6wYlCqac3LPanQVaFjW1ZdmuA9JgsmmzgdwUof/rfINJgIVpYEbZdpaJlsm25ZA+AuyjowgqU22wKnfv8KoNMDyh7i3EjLMUVDRX+iIsE9L7KZiZ5P6ansDgKs+wBsM6WbOdO4qdkD5oUvTLjGP684z3DS1ITaQrqQ/84BUJQ2YDVD+E4JGKrhJ2edg3/95k5kywdQ0a6FSF0FmkuL9UQQwaL1TlcnBlmlaGldLAIsh0Knxiw5l3cwqR2CLHJIGMkiyGIThuMIfrVDaO0jTa2P1egs45gzTsVmhx0ojY5pqUPoJhwerRwdBgE8rzxTxdPukbkagGXWfymy4MJF/h85Vbk4qFrejyvefiKW3nU3XFub9Yp6dg6ujP2JjKf1MIJFgEWSO/sjZBowBnxVxrI4wsvediz2+dApQIcnv6P0r1QMFhd5895PZgysKYLFvLyw6iMkOQdL/fcJSRGmcROOxXezfcdkAFbdcTHS14czf/ZjYHYVKLkinUq6qE81rKKDltEgM2FDpUV2tZDMzDFFe+B+AqwnAGw0RRs406yp3gMr27EVCMZmw6sTaZRQyIlR/AVThTTZofYVY1/NBlxOqPUQ137i0/jD9TdiQaWKZGRYtLTEcsJ1UXJcRPWm2E80rFgruVOtgdGtcZ6FBlwVA2iibZVpjpZozygHyXBdOFXNFGiUXNRndeDYj3wQmx96sABBqiy7NL+lThJ1tmxPE6KnoRfdVB9Sz6h94wDWCniLvDlTwSWkdU1tkUc3NIgbP3wG7vn5DXBZ8MAYF1c36qxZuqy+GHFY31KEYqlOvTnXEd03juuq04HlYYjtXnUADr/gHKDLQcNy4NOMiBW7xYV+XUSyngHAih58uCXTMFUBlhm7q/KuLI5tAqz+ShVn/+SHwKK5QMkRgBVmGSoUUM3nyNZ3ioN7BmA9o2miTR9+kgBrGYC+NjVg5rLrSw+Yl3/MJDBaAWM2XlKrZUQ7GQmKqGCsYHuMEAUCsmi+i+XD+MbpZ+CxP9yNUj3E/K5upM1AhPqq1arY4cj8XlgBzaRWjDyY7jURCEN8l6gEKxSVDZWkcMMUVqLglctYWhtBz9ab4T9xE6875Z3Y6ag35BWEtpRO1+shKuWKPvW6SJOsL2OgHfexOoBlfseolMiRK6QEUJaS4jhnZBh/+tyFuOXybwnvSmQIMhZOpPAcR/4er9Q9vpJw/ELaji6Y+DUZrYvFSzTipihWArBG0gxzdt0Jx/7vl5HNKaOmHCk8UQKwjN5cflV22mTegbUFWEmI5v0PtYRGHTuVCFa7ldzHR7CeCcBqODaedn2c851vAbtsIxEsKv9R1U1qmFcGsEx/WdrmfEboeOKj/zn45nICrCEAnc/BxWYusZ71AN/1luu9MUBmymF8VCuXQxeQI3EsrZbNJU1Xy1B/NIUSp51YqgsxMIjmI//BZR//NJbd809sYpdRShRG6iPISi6GVALHsVEJE4lakYelPQv/P3vfAWZZVWW9zo3vvUod6KYJkkQBYRRUTOgMZkb9MaDoKCpKzjknsQWUTBMkiERRRBgVFREdw8gwRkYQEUXJqWN1Vb1w4/m/tc+9r15XV3dV16vqCn2vXwtd1Lth3/POWWfvtdfKVKeZqchEQlvlHXLLnVy4lETfhO72loWOcifikLkqCy+uXIHyJgtQn9WJQ754Bua+cVcRQ0W5gjhVSGMNj38vjsmNwBoBVgv5PWb92MgwMHMlIJsAq1bFP79+I7590UVw6KXJDkKOnziRLCnHAn/eesw4gJUpsscEnZFCxS6jYdnwttwch9x4NZKtNsIAHHSLSKsNnXnpNTmVEw2wpELIL3iI6l8ea1rlUEqPAGuyzZ7bBVhLbBcnXHYxZr/rLQKwAlHC8kQUl5PrKsOvpTyrC4A1ufPO6K7eT4A1AKBjdL9f/FYRgcEIrAaw+J+YLWjNZuW72wxk0czGyDkYgVJ2MSn+wALCJEKoAzg2UGLprVrDMz+9H9+58HIEf3kS8x1XSnvkYy1TDZTLZfi1WDhVBEwCnjKAxVvJS4ZD9bOMt6HR17JIXGdbvthYGJ8w6mf5ji+G0f2Wgr/ZJjj2sguhdtwB/bV+dM6ZL49pt7u4FIOp/QgMA7DMkGsBWJnuWV7eksSARbXsAC/ccTtuWHgO/CSFzfdv2aKh5rEMTZ4ddbOyo9UGJV9Yp3sGi48XpVRKtwRgecpD7PlI5s/FMTd+FXq7l0kGq5NyCNpusatqyVy1k8Fawwho3aPRqBtRHbVH/oYr9j0M3tJlolWcxuwinFyh0XYB1lJYOPics/Gyj/y7kNyZl6cboZNakkG1M6HlVnkG2ShkCLcgubc/hUzgGaoEWFUAWb1jAi9VnHpGRmA4zssaH3RI+3wO0DhFioChiIEmSFUiwoZOnMJuJPj1dbfgnouvwlZ+BdGyJfB8hbiipUxYoVcaPQmHUdsWAJXdYE4dkaU3MwLOOwv5T8l+ZabS/B3eDzNjzFSFnotN3vw6fPzsM4HNN4EudzY1aszEZzrO8iNXAhcOT7bjn5Evfzo8lJCkuWpl70c0b83PVBhi+c9+iqtOPhnesgF00myXaub1AQHvSZiIThRFTHO5D1GClzFkOHxiETVND94/nQ/EG50SDbGGnVqIyhUMzOvBydddBWuHbZG6DqzUkRjGGYWS3YcCLtvgILZ+/wUv5DyCFjkMkdFLG/B1ir7f/wmXf/YwdPZX4TkKSRpl+mbT8wVElo0+WPjocUdih4Op5u4iEcDowGL2apgNHIEVQyXk9jxe0/PxN4S7rhFg1QGUNoSnLZ5xakWAiStOoJxHfNFVyKZcG6jbxnjXD2LguaX4xmkL8dxvfovukFmFCDVUZTHU1GEYYydNs7NRFkxLuhGjrA/dTVP4VG9IHfSnMYJ5Pdhuj3fjfWeeDnR0Zr2NeQq/AFhTa2QN3k2rr+BQAEyAVf/jb3HBYUei46U+dBJkOEAYB3B8DzpO4KWurGMsoXFFE90rdrDlHL5pLHQ5CLAssxGJWBy3EZR9rJjTjVOuvgL+TjsA9MQj/4pZ5gz8CMBiFFoyfOs6BuSSuZRLrlKcu6tnmyBhWuo6SqnG8vt/g2sOOA4d/QNwMoBFeY3pesSWhQFtY88jD8JOR+yH1GezD5diCzb1bvJY5A+oUpHB4eGspkA6XaMwo++7QYDFBpLJ7XWd0TEuHm5NEVgVYLE9j4uXSK5LazgPN4igEhvVn/03rjztTFRqVaDeB2WFJmskXoRjm2RbyfAsLUqZ0TbEZso9UMqB5ceGAno9C72dnTjoy+dgm3e9C7BdwDGZs7wm2uo11pwTWzJbxUhY/xEYCWDhqX/iS/t8FqUXetGVAiHVwcXhm/XmdBWAlSot42EmASxm4nhIByUrhbBR910s7enAiVdehu7X7Qw4LOQbgLVKBmscAFZGwYSdG0e26D4RAJL0zRxAKdF47qc/x81HnYHOgapQ6mgGz5LudD0IsKqpjfcc8Bm87vhDkVYcpCiJoOsqACtPv7cCrNbM6QSUaKdrTKfYfQcEWBzDRtynOIoIrMcI5MKkYqvDUo7M9amZyLPSmh1FUGQk1xP893lfxq+/8x1UyL1I6kJ+tS1O/u0BLMmbZdytod6HVqIRKYWkuxPP6wTd22+HUy69GNh8c0lfCQcjK5MMVyZs/dl6DG1xqSwCawVYUQgsX4pzP7o3vKeXoptgOgngsZuL8gW0g9NmahQS+AwDWLI1yACW6ISxFwA2ar6LlzpLOP7ySzD3TbuuBrD4OUdKr1kGa4wL/BpLhLxAlsHi4qR0A16S4O933o07z/wyOqsNWJaWEuF0z2DVtIPdPrkX3nb6sUg7PQFYojc2VNBVmjOM9pXEvwBY02GOiwiwmKUt2qGmw+uaYfcopZesRCgTtqSDCLCU+AdKsoDdhdUqFIHUk09j0eGHI3juOVgDK9HpOEgMwhlzZJityrsP85MYY2kzwzmOhVocI7JdhJUSnqrWcMDpp+G1n/4U0iiA1VGR8qIohQ/JVuX+dmO+ueKDbUdgRIBVHcAln/gUwkf/idmwxGPSL3uiuUbRLBeegOgoKxG2ZrBkFZzGJUITXDPOZexmAIsZrBc6fAFYG735DasALGZ5+TUdL4CVa2muwsFqAViRiBZEsKMYf7z+Ftx78VfRXW/AIheJEhNtlCjbHlxtnoCbyIby8JoPvAfvPe906C6WB02JsABYbQZ3anw8JsDiGjd986xTI5DFXYwhAvkO1pTqTFdhs/uL2aHsnIpWNnVWshUeuekmfOOSyzBfOFK0rBnj9rnlfoWLQpCU2fAQXOUG0qmtoW0L/QMNqHIFUUcnrAUb4ZSrLge23gqwHaTW8ABrDCEpPjLOEVgrwIpDoFbF1w85DIvv/wNmKxtRRCNx00nILi5X0Wac/DyOUGYOKD7KzI0hG7cD7sf5Ucd0Ovp7ElzZmXE6S4Q1z8Hi7gpOuOJSzH7D61YDWLyQPU4ZrFUAFk/cQnQ3/qYpHB3AClP86pJFuP+629AdhlBNa/mxb67GFLBx/BDnnNAuYZu3vwUfvuQcoKcsHCzOhCLInAHNvPu1yGCNY/DXz6kSAqysSX79XLG4ShGB1gis2oXYorfOFHimCM/JVMWhtNVj6TIsOvhwxE88DbtaF92ido5ceJQZM4IqZii4gBL0JVaKhopFMV6HMeLUgtM9C/8cWIm9TjgCbzngAMBykFI+IrdfKThX7byOcf/siAArqOGuU8/CX+++D3MS8noCKKVhO2bwmQ5VC2FWBm4FWLxZ6rpN6yONpdOVpTYqufN5GyUPS2d14uSvXo6Onf9lzQCLQJMcqDb2ODqTy2xa8OQTApvk5BWkcJIGyXG454vn4A/f/C5mxXTsS2Arfnr6xj8HWJu9aRd84qoLoWdVoFVJNo025z/p0sxS/EWJcDp+zVICrKF6sdPxQYp7nuYRMPNqOjhXywSjEVq0WaaHXCD0TwxU8Ztrrse9X/0a5jCVHiamm2kMR578MqKjBmDlnoa8FwKs0NUIwwCz/A5ZgHr76yhvsSmSLRfg6GuvBmbPRep4BcAaQ/zXx0fWDrAiIGrgnvO+gge/8T1ZuNMklNJTqewJyV0nJpPKpguOQ5bG8vKxyWJN3wXefOVWBVisl7OLcPmcbpx8zZUos4uwheTeFOiVkn77AKuZsc674lq8tfj9jJHAjQPhYH7/jLPw4J0/xOwkkRIhAZaexiVCAqzYLmGj1+2ET19zCTCrA4llABaNmzI9hqY9UZHBWh8zxrheQxcAa1zjWZxsnSOQlQQMZdYsV4J3MhIn28Kp+s7/JY1+dNkO8OxL+NJen4CzrBdlraXjbyxkcgOwUikP5gDLjyndZ+6GHYXMYHErWUoVfMtFI9ayw++bXcbRF1+Inje9FanriraSnamFU6iUgqXFMfkRWCvASiKgXsVDt9+Bb515AV7mlxCHdTgsCyeRjCkqhXM0BJngI50HZhLAUjoRf0+q1nsenz/BgGujd/5snPm1a+Bsv60BWJlMQxNgUbOOAItjvo0MVg6wmCWU0+QsblHb16LT5aYJMBDipoMPw/MP/BFdFEYNGmKTpdjNO00PmXf8TnS9alvsS4C1YA40fFMibCrZZg83XAZriG7YNA3DTL5tAVh5UnYmP2jxbFMxAhx52SRhyLMmgyWEwBaAJRqk0uoaw+OiuKIP93zpAjx4z72oNBpwk/YAlgiPSgbLgpcoIzBqaaRWjMgyCoh2lKDs+AiDGA3fwcqKiz2PPBw777c/tOeLEvxQgFWQ3Cd/0K0VYKUmg/WXu76P2047F5tZHpKgCpvvPM1NnSjfYSGyTdNFa4ZzJmSwCLBYIqQ9kG27IGGk6jmobjYfZ9x0PbDFZkYHKzUyDRMFsOjwIJsrBjkjZvE7KNxMfueXrMQ1Bx6C5X9+FF2iuk9LK2ayHGlSmY4Hx5V2KgKwPkeAtelcQJVEb1mERHlkTQVGqWFIF2EBsKb8ay8A1pR/RTP4BocFWFzYDNjhwRZXTqB1RCjDhp8EQC1E7/2/xaKTT0FHbx9KsSHqruuRZ7BaAZabKqNQzZwZ26KtVJSuo1oNHeUOAVixY6PqWthy97fhP668EqhUBGDlqu0kSBNstf5sXe+t+P3xicCIAEsnePLHP8VNx52JjSJjyeLQuymleKyWcg0XwoAlQoWmNlqeeZmui3seXQIsWccpRRJrOJaLAd9Bus0WOOEbNwKzewaFRlmyo3p9TnIfxxJhnGWwWvWwDMAi/zIBnnwel+x/EMKnnkU5jlBxFMIwnPYAiyVBAqz9CLA22wiwykJFsFn6zJTccxyVAyyJf87RKuy6xmeimKCzFABrggJbnHYUEWgBWDmhlXwq2clm7e+yoVVAjbwYy4IXBUCUAEtX4KL9D0Ly98fREY0NYIkjInk0sj1kSY+K1jnAykwS0xiua6Neq6KjowNBmIBmiSLbsMl8nHD394A5swVM5VINeeaqAFijGAMT/CtrB1gJmLJ56f7/xXVHnIiu/hpsdhGqWEB2DrDocRmwNM0saiY+m/P+pJi87th+gp969KdnXo7jlGVCbh48x0evq9C1y7/g4OuvBjrK0DkHq9l0knURtguwclkWERQ1GSwxf8/I3QRY4lxKyYyHH8d5Bx0Md9lK2I0aukv0imwAyp228ZfuVHjo3vEV+Py1zGBtBDgVA7ByAdVhMlgFwBr9+J7s3ywA1mS/gQ35+kMAFjlYg2VCmsua4OSdfgZ4xWz1Amo1fPvML+Ifd9+D7tDwZdb9MO325jK8noU0O09TOiKK4PkW6mEDTtlHI0xgOw58q4TnHIWzf3Yv9OabNv3tCu/BdX8LE/mJEQFWGqLvz4/iygOOQmnJCjhxKACLjCCLXWpaiYk4ARaBFO2T2Gk6UwCWaSKn3puDMDQm58tVim3e8w7s/ZUvAd0dpomDHKwMYMnvjwfJXb7/Rlg4yDJYLMG2AizoCFacIPjvP+DCo49FudaAHugTgJVQKHaaA6wEPrp23Bafu+5SA7DsshjJW1l3dCsVa5UMFsWXW7sMJ/JLVJx7zBEoANaYQ1d8cFwikPWwGhA1DMDK8+O8WJI5oHJRqA3ggW/chp9ddDlmN9oDWAbFkdruZJ5zzGRRbFTDiUhYt9CwYiS2Qj2K4Vo2OlDCszrFKT/5AbxXvtzwWFp4WOMSm+IkbUdgbQBLCEdxA/HTz+Oyzx4K9eyL8Gm/wkWdaELAtzWjAZYR61Qyfpk5cZSDpUjwr/t/Fv96+MHA7C7EtgdL25lsglEOGBeARbKV8K1SBHCkIjYUYOk0hB2neOGue3H92V9EJYqBaj/KNmBzztD2tM5gEWB17/QKQ3JnidAuS1naaAIObi7JSy0AVtvTwXo/QQGw1nvIiwuuEoFcJCTTvMkzWFY24TbdoGW3K4qkADkyQQ1/+fG9uPOkMzCnDYAlJQg5bCRwENqk1Vpi6kvyfIlrgA4R+wpVHYs3mkeA1bCx2LZx1PfvQMerXyUZgJx7VZDbp84YHwlgqTQElvZi0ScPQPLEMwKw7JQFK44D9q/ObICV6Fj4ghy7luUI93EFUnzq7NOx1Uf2BLrKqwEsvl1vHIRGBV3x62cbgMXDb2aw2GSSQqUJVBDhT9fcgrsWXYFZ1OwK6rDiAL7rIEmZdZ46421d7sQUQFcHWEMzWJwiC4C1LpGdOr9byDRMnXexYd5Ji9IowdWgPrYUaQbbtmUiJuudNRoSXyL84yc/xW1HndAWwBKwJnM8newdBLYhNXPOpvxDR6oRhQ1YFRcDSYjYceBZLrxqgt5yGQfefjN6XvtqAVg554r/5FGUCyd/SK8NYLE8ZlkxsLKKqz6xP6K/PYEy5RnihmlwoKK/sqVzTszHtQWHygSi+G/e8XTmYBkfwhSW6yBqRHBdH0nqYIWjcPiVF2H2298KeC4iy4GdZbByaysBWLLyZ6z3sbzq4ThYpmlXDN/l/lQCVa3j/q9cjvu+fjPmuq7INgRBFZVSCRFb7qbpIeBduejZcTuTwZISId8BlfWzrs3m9s+MNzNbmQ1gq+r9NA3BTL/tQgdrpr/hKf18uf1grn0lO1GjO2UO1gC4u1Z0pEEaahEYFJn1oI4/3fVd3H32OVIiHMuRdwlSlqEUGZI7AVbg0NyXi6hGOYpE4FRI7J6DOjupohRdXgVPxgmO/f630bnTDkISDoIAvu/LrbSS3sdyb8VnxicCawNYbHpPKP0RRrjr0JPw2I9+io1FE6oqGctQs3xmOlqt3FxXG/A9qIVFE+jxudexnGUklZ21cRO1YtnbfHfKVgUDAxFQ6kK6YGMced0iuNttjcQjidyGI6BHoZ7tc8hFE4DFzU5bz58D1RbBVkONhLZCxIjghiFu+NTB6Pv9Q2bD06jD6vJRj0KxMjJdv1PzWNv7EfkPy8WsnbbDflddBGy+iemYcD3hYSmWbSW89GM00yIdJ2RmbJkip+aTF3clFd7CKqcYCJMWgRaAJZQXuRHO3INlO3b3UWcwb6qRDBZn3yTBvRdciD/c+A30BG0ALGUyEpXILKQCsGwKS7IcmaISpShzMotjWMpGYCkEWsN1SnjOtnDGvd+H+/KtpcxCg2ACLR55uXDSYltcWCIwEsCKVQw/THHP8Wfj4bu+j/n0hwsHEJSUaKCxq5SyWG5iSlg09uYhfoSZvMF0Blix1ZByqK/LCBMHod+F0nbb4tBrLkOyySyktifASkyuLYVaDrD4leP3wuxLxnQYjJDFscUaS04rqbJQAKBdq+GaD++L+C+PozNRCMI64m4PtThEGe60Blih42GjV78K+15xAbDpPKM3xmw4OaECsExXtQBcIbUbGWQBWG0B2zG9suJD6xYBscopzJ7XLWjFb49nBHKQlU0WaZbBMjs22wiOspvezZ0jUqC/T/7blZ/ZFwMPPYxOSieM4ZAMVgaw/NgArNhSCDOAxUW0lGq41LgisNMKkWMjIZhKFfpm9+Cs+34EbLLxaqCqAFhjeCET8JGRAFaiUnhhjP9ZeCl+fdM3MVdryWCFJY3Y1oLlZyrAgqK/ZgOOraAiV7JXKywPO71vD+x53llIfK73xgaKpVECrCBb17080cwv6kQArIQXjJGqENbiJfjKB/dB5dnFArDCJETUYaORxjMCYG36+p3xyUvPAxbMNXIxDjX0CoA1AdPB+j6lmD1zL1L4eqzv0BfXMxFYpYuQWIot8tmA5GRjcuSILCaRQpQ5UsMEK37+a1x6wsno7u8XodGxHNK5qIyxs5sYuxzKNBjOjclgeUkqXCxbJnyF1HKhPQ99cQz/lS/HUd+7C+gyQqOS2aAqaZHBGsvrmJDPjASwtNJw6hH+/NWb8YNLr8Askr2TAA0vEXzP8UngbcbH6hksnZlAT8jNj+Kk7ZQICbCQBsboOXaQlDrxPCx87gun4ZX/sZckU7Rlmy7DDGDlHCyW1cdDJsCYPZsY5zIQksHi941LU1rHikcfw4Uf+zzm9zfQwcyOThCUFWKdwtX2tM1gxZaFwHKx1W5vwN4XLgQ2nmMAFhX1NUvPlFktMlij+BpM1V+JCbDYGDV9DZ2mamiL+xo5AqsJjRJPGbscl4ULzr3Stgcsrw2gp7MCO2oAUYrbDj4ST//Pb1EKQ+NVNsaDWSym2w3HxjghijUPTaYJvrgAJwlcloqgEDHL5XnoTRK8/F1vxyeuuhwpla8ziQYuRlz0+KcguY/xpYzjx0YiubPipwbqePqOH+LGMxdiTpKKJVNkx0jpSUhlf2mCIA9rEGA1S1tj0l8bvwdsB2BRZJRdlBz7iXYw4PpY0l3Bl2+7FWr7bZE6fHJrNSPznJsuZf02y1TDASz5PnLDQiujpI6/3fdf+PrhJ2HzRKEsX/UUdV/PCIBVhYXt37k7PnLeWcC8WaLrRT4ECfDGIszwr5qk9qJEOH5fnok/U0SA1WB37MRfq7hCEYEhEWghpzJrlHdoG4CV+ZKxcTDdhfMsAAAgAElEQVRKkTopfM4yYYilv/g1Fh12LDZWDpJ6bZBwPKYA5yRbk8S1RdlPC9eUJGDl2NBRiIqQaS3UwgSx72KF5+LfD94PbzzqiEw7y4g18ihkGsb0IibkQ2sHWMYOR1Ub6P/F/+Lio49FTyNEWSeIEEoygZkEGRczEGCRqO9qLXzB1C5hheuiY9fX4IjrrwE8B9r3jCZThqLkn9l3lpY5Epc2qUBGlmWwxigJ61aAFTbwq699Dfddeg020w7cIJYml5qTCMDyKOcyTUnusbIxYDl4zfvehQ8sPE00xwRg0aOQ3avZN0JI7kM5WBPybSlOOs4RCAiw2BhSGucTF6crIjCKCAwKDbIwSMNXs2fOSJ2Z0F6t1kBHxRFx0fSJZ3DreRfgyV/ej3lsK6eKe1ZmGMUFV/sVsQrhTlFlAIst0pn/ecIWftdGHDTQYZdgw0Z/PUDSWUZjziwcesG56HnbbmCqn9kq/hluQR/LfRWfGZ8IjASwRKaAi/ZfHse5nzsQ5f4++HEo5WjHs2URzwGWsVLKrXFosyT5nfG50TGepZ0MFhftkuxZYsSlCvo6K3jbYfvhLQd+XuQXWB7kToPAippU8qwslWYle0bGaxNgtT62SF40AVYM0OS5vx+3nXU2Hv/hzzBfUwOLosIaNZvQTMOVLs8xBm89fGxt7yeybNQcD6//4Afwni+cAHRXZGtJBQxlOS0AiwDfjMOc5J7f+uSOvvUQwOl9iQYBVhUA32xxFBFYzxEgz0JILghF2NERMmCrxstAkqLsWED/StiWwu+uuhY/uu4GdMcJvJgckrHPrsYOxxDdY8sALIeSEJoms6ksKoljIQjq6HLKsJWD/kaIdNYspFtsjONv+BqwYGMkFD+0hZa/ijxD4UW4nofTMJcbCWDpNJbsFJ5bjPM/9WnYS5bACwKkYQOe54gWFqGFmOtK96C5CE3A5e/THGD5qXEniCodqM6bhQMuOx8bvWFnkQqQ7N1QgEX9EkXrIJPMYqbZjPz2j9UAFj0IX3gJVxxzDHof/DPmUC6jEUhWOXYUYpkxWrxD27+FcT/DSACrXirjjXt9EO847Vigg4UkAiyrKdHAGzIl6gxgSXZr8DYLgDXur2w8T1gjwBoA0DGeZy3OVURgdBEwLAMNjQY0bPjwRBIBSGMNq6TQm4TocizYYYRn7v4Rbv/i+ag06uhfuRwlx4NjjX0HK4ulTmTCCnOARSHJzGuOHCyuJ1RLclMLnltBAwovJQn+bb9P4l1HHQ5UOpA4zmo8lbF5I44uasVvtR+BfOETrlwYAstW4o4vfAl//OEPsUm5gk7bxpLFL6Kzu8voaa4BYE109mSkDNVIkWjNqraeS4jr7OBtpEC5hD7Pw8Zv2AX7XvZlYP4caPpy8rvALFbmsiBAKgNY7LTNZbDaBVhyX1kZMtaAUL+iBhR//ujj+NL+B6G0vBd+PUDFcRDHMeo6hlcqIY2NMfdEHRP5PWYGa7m28IFDD8Suh30O2negPOY6jBQDu88MK7QAWBP1fif4vFUCrD4AXRN8oeL0RQSGiYABWDwIsGgo67N1KyNjUZohJAm93gfvmcW4+tgTRQvHqTcQ2CncsgsdJGOeYFsBVqQcAVpsR88zW7wv7Zo9YhokgOMh7ejAS0rjhKsvRc/rXwt4HlJ7sEdkFb5K8c6nbARWyWwFIRBr/Pbaa/GdS68QqYYucYPL3TFNE4RZ6Iw/HDNY0ljXKvo4AU87EQBrEDTQkMpFP4BlnsLB5y7EFh98LwJLw/dW3XPnZOscYMXZ11QyzuPw3LLXESHNTPUhrEPFKfp+fj8WnXgSOup14V+VKJOSJCLRYFNzjgLA0xhgLdMW9jr2CLzmwH0Anx2EJSG4cwpsjq8CYI3DCJuUU/QTYC0DMGdSLl9cdAOPAFkUpvE7AbVfFDzW67K8d5Q24Ho2sGIpfnTRFfjtLXdgMwrxRAGiHg+BTuAkmW3EGCOpaPgrMM+UCPOUey4kabmWCIjSMiWAQs0vYbNdX4vPXXe56NXALSHNpBlad7sTufMd46MWH2uJQDODRYp1Qr5PgpUP/BZn73cA5kPBGahhdqWCGnlAUhqcngCrdRwOLZdyIQ9TC0G5hI7tt8ERF58PvHxLRNIR6za7YE3pLlMTzzJYSQaw2hZyzwQzWemPtRYaAHQMKwqhwggPffVGfO+Kq9Ej3bwpuN9J0hQRwZhFevz0BViBbWOZtvGZ00/BKz+9F7RnQ1m+sV8aVLBZNYNFx6aWpoCiRDilp7XlBFjPA9hkSt9mcXMzNAIpUh1lnAIKM1gizSPColYMlYTSpv3E/Q/gumNPxiYNjS7aeaQJ+nwgcRScJONsjTFC1NQx5OVVTWONTxuNnRXqtQCdPbPQG0V4yQIOWfgFbL3X+wHHhaaHD33DWo4CXI3xZazHj4mUBsnaiYZPgNyoA8uX48y9PobugRrs3n74qRYOHn+PHaTiQZhRYYgzRENtimew8rE4tDwomwrLQej4WJxG+MSpJ2CXvfYEOjsAryQEqzCI4JbcrIUkA1jkqzHbxOdvKWGN+dVlAIv/CKk5Z1vQaQSHN9Bfxd3HnoGH7vkxelzHaGPld2OZBoSmZdGYb2DtH5zI7zIB1pLUwmHnn4vNPvxepARYypfSLAdWnphbpUTY/HlmmTNBz12cdlwi8AIB1l8BbDcupytOUkRgnSLADFaKOI7g2mX5JCeXJE3gcqsaR8Dzz+Gak07B0gf+gJ5GjC7RiVFYkQbwOypI2UXYRokgX3gcKifLopMb+BpDtFLGRXHLFbwY1OFsvQVO+vo1wCbzgI4O4aoMlbKeyEl5ncJb/PIaI5ADLIoEiNRAnb0+wPdOPQMP/uDHmJcq6GodmnIFArCUgCtpwGDeVQCWSNO2Nf5GekXtlghzXbb8Oq0lbHKA6uVONGZ34sybroPaegtE1JUrd2VfAm5ick/h3A+vRbZ9PNInedMAv+5aw2HHYhLCZZ3+uZdw/eePQO/Dj6LsWrDSWJpIJHNlu4jSZNoDrKXaxsnXXIGud7wJsWvBViVEqcnkFQBrpG/HlP/vjxFg/RrAblP+VosbnJEREIBFDz/Ll/pcI9WSEPJUAhUHeOSWb+FbX74AcwcCdHM5S2mmo6H8Mmr1OnyvPRMCQjwCNC9T6ubCSQ86btQVdYKiFJVSB/rDEC8lMd72uU/ivcccCcybjUTZJus2Vq+QGflGp8dDCcAiy4oLe5qixIxlGGD5ff+FC48+Hpuw9Bwn0mHaCrDI0ePfY8topU11gDX0bbQCrIbDDIrCp049ATt++qNAyTOIil/AKAU8WzYczPHamaJ4c6xnDgxy/naAFuNJ6YuMNE/4pimRYWss+c0fcOuhJ8F7aRlsatIpLQR344dcEi4Wm1Qm8pjIzRIzWL1uCWff/HXgdTsgchQsq4wkA1gGyg8huRcZrIl83eN97vsJsO4E8JHxPnNxviICo4mAkFtjKmCZMlsf2VAOFacaSJ54CjcceQLCRx6DWroCm86fh2WNAdCF3lM+BgYGUOoYu4SbkJXJ+9AAvQi5aQ4c2uSY7kGWH/wgRdkrY0XQQH9nGYdcfB7m7f5WoKcLIWyjOF8ArNG86in1OznAomCm0XOKYEUB8MxLuPWYk/DSg39CWRvbpKEAiw8SUYdpmgOsuuug+5XbY/+bvgbMLmF5o445nXOAWEFTb6rimUxdC8BiUVTKopmFlYCrNgFWFMWwfCkKmlMlEWyV4IFbvoVfnnM55tZChEkNjmNJ1oqbrBxgtaOBN5oBOdEAq9E1C6fcfhvwis0RWRqWXWoCrDyDJRnWpg5WXjosSoSjeX+T/Dt3EWAtAnDEJN9IcfkNNAKxpPkVVMbt6FMJfJqd9i3F4gd+h1uOPgndvX3odmxU61WojjIs18PA4j7MmzsP9aghXJixHFw4RXVdW83uQXaHcVEhyCLg6kkd4YbUfRd6k41xzLVXANttKwtvSpkI2G2tL2O57+Iz7UcgB1ghu0Zp7h3X0cWVrLeGv950G7532ZUox/yPg9cymU7zdwHnAi4Gx95wpepcN2tNd0yQtrYjL2WuqQwuGl55aVuZzkYeeWYtv30CIxnvzE6x/KSAAc/DZ04/HZvv+e/QHTYSx4dD25xqALtchk5SpJ4pnTODxaMJsPILtQuwNOlvAUqVQXI3S4GqNoAfXLgIf/76tzFPp6jGNdglR7JWOtbwHF82ZnqkALc5VNoFWK2aVbyV/D3ytmuujWDeApxyx+3AprNN1lxKnywR2iLxR86/bD0ziyARGs02BeY9t4dv2wxP8fG1R+ByAqzjAFxYRKqIwFgi0K5yOSfvoFZHyS3L1iz2KPYZA0GEr31uP6z8ze/RGUaIbepVZaKPqQ0nYf+ShdRK1gqwRpogKaaYc6+YsSpxUQUnP8M07dIeBsIIy8sutnnn2/Dpyy6Ctm2oUsVopNotK/BYAlh8ZkIjsDbbIpamIjqvuMAAEpT4h7y/vz+Fm446CUsefQy+UvB9D0v6lqG7uxturNHor2P+rDlYumI5rIprxh9FMLMnMYuoyYjmC+rQ7lQBK0bHU/7kx2oLMjlJq7H8zG8TXLnUS+B3yEkRORoJ70WlcNlxl2p0uD7q9QaU76MaxUh8X+w96T7wuvftgfctXAiUHKQk85PblA56D/K8uZl1fovNLFMrQaidN8jyYBTBcmgRA6xs1NHj+8DyPiz6j08Dj/4D5SRA1Y8lw8Nss5PYWcbZQpJlEtu5hbV9dkQOXAbwBoHTYLNMKxCSphkOuMRw9qhAX/V9RC/fFiffejMwq8sQ/KigLzY55AZmIqpNBVaDpkj7zGUc2u7inKjAFedlBI4nwPoQgP8s4lFEYCwRaAdgrTJHS/cgUwQK0dKlcJ9+AQs/93n0rOhFOQkROIlx6Ugt2Kkrk+x4ACyeL1FaSoO2jtEdGHX3mmvaoUuJjdDxsLTi450H7ovdDj9AtK8g189Ee9opkYwl6MVnRh2BkQCWaFpSaDbL0pSSAOir4fFv3IFbL7gUc10XUXUAnbM6sXLlSvi2i5KykTZCVCoVVOO6yWSxVNzSbGHMwwcBVn7DrSUtyShlQGtNAEsPcVNuhfODAMtC4MQICLBo70SAlWoBWY3ePszpmQtaUYXKxkqlkXZVMGerrXDIeV8CXrEtEtedRKHcFDqiWKgDOJZkj6Vb8E+P4dx9PoPZK1fCSSP0lyJEdgonceAmCn7sCMBMBFSOejis8y+OBWDl4DkHWAY0p5ItJ4biOGFBtN8vwd/1DTjiqiuBsmcAlmsjoWF8E2BlNdp8bJGDRZ5o9iQFwFrnV7o+P/BhAqwdAfx5fV61uNbMiUC7ACtlq7XijJHtjWlB0tuH39/6TXznokuxKXlQaYjYMorr0LZMxnbKfwKpkI3XXCIcKYOVAywqUxNgdYWDAItcLze0gHIFy7rLOOLS89Hzxl1EvT1uJHA8Q8wvaoRTdzyvDWCxBCOE9VTWdqRRAJcZyTgEnnkR1xx/Ehb/8WHMVg7iehWlkod60EB3ZxeC/qoojucZHsn2ZAu9GaerZjLWFKGhpb/hMlitn13197nZMBdNLHY2piKAyj8WO/JSYJZXxsrFyzG7cw76kwQDFR/LPAuHnPsFbLnHuwHHR2oPOhEIKBwC6iby7aZpbPS2ItNwoBwF1Qjw1Hfuxg2nnoUFcQRbG4DF53NSyjUYgEUQOxUzWKsBLFGqzzwthbFJOy6g1/Ww5Z7/Dx9feLYAK8lLldxMeplIip2bjiHB5anDLINVAKyJHJXjdu6dCLDmAVg8bqcsTrRBRaAdgCWLEjMIcQTHsmFxdaEeUbWBS/c7EP2P/Q3djTpKSQitDMCSZvEMYJlFrV2AZYjMsXCuUnQylZFlsFJlwU9chK6PcPP5OO7m64CNZkN3dyEOSLT1CnA1xUf7SAArSMjnUbBjIGwMwKMfXFCXcs4/77kPty68AJXeAZRqIbo6ShioD9A/Br5ro9o/gIrrC77OM1GG52S4SqtmMFYPFMHSUB2tNQGsNUuRGI4UF3BuNOifKUu50gK+5pY6sfi5JfBpwdLVhZccjXd/fh+89ZjDzKLvlaEzo/P1CazyaBiAZTqB2SFIIjtW1vDjs87Dw9//IboaNShEqHuJdPey25fPRaAlqZysm3OihmE7GawcdLORhpw4HgKumKHSGssdF2886CC884hDBwEW/S9lBjKjymVmTzqBsifkj7kHyBTBigzWRL35cTnvfNn+6BFH0bhcrDjJDIxAuwCLIWFWwPNLRtOmdwAvPfA7XHDk0dgICuWwDj8JxYDZ8FVYZDG7V8k1ycoz9gzWIAfLiBaWOHMhRcNh6dBCRflYqTUW7LYr9rnqEqDiI/Z96R+cwMrEDBwpk/NIawVY0Ei0EnVwWbEobOtZiOMQFotqYYofnnMxfn3Lt7FD5yzUliyGV/JQi6rye57nQdVDyaQKmMpKfoYAbzJYsjZmJUSDe1YtHY4k85CDnuG43HJ+AVbmn+Y6RnaEIIRZkjRkkqqEhuNhpWPh1Xu8Gx886xSg0wcc1sUNl3GyDpFJkaJ8lkFkWnHpSly+z/5In3oOfmOgCbD4nGwyYPbaSLySL9aGCN4oHnrEpZEs9GFKwXyvOaSS99JiSi8ekFpjRcnF+884HTt//GMA5WYsLRnRSOCVaZ5hE01T2r1J5DPDlUdGVBjFkxS/sr4joHhkAIsGJN76voHietM/Au0CLH4+0TFSy4YnAKuOO884Gw/dex86ogh+GsFLQ7jkZwk5lxkn7njNzn2kNu2RduUCsLLuK06KBFj8e93hAmkJ16s3TfHW/ffB7icdB1Q8BPQshI80TuFyx10cUzYCa+dgaSmHpS0yIfVwAF6lhAARKtpC46HHcMcFi/CPH/8c85UD10pglyysTOsCtuxabIBMC5gy/z4IsExwco5WRn5vRmztHbBr61FlxsoALKNKny/07MpleZCZXiZkwxLV2lO85l274z9OPhHYbBPEQR1WuQSLzSWTuFOQJpc4EukthyWxWCF88GGct88BmN2I4JETpyIh8TOqYqUl+SB+/y1YUxhgyQvJAHW2zgqwMj9W6K2U8ZlLL8LL3rm7yWAp8skUIh3DVkYAhkp7q2SwzFDK7VoLgDVlZx6ESik/B1grAMyauvda3NlUjUC7AIvZAttxECBGiZPPn/+Jrxx4BOwVvXCCGlQSwEtT+LFJmocWibBmch2NDtFIAIs76PygsCh3yDxvnsFSIdvZHXzyi6fi5Xt/SMQXG8qBY3mgfk/JdSZzfZqqw2LK3NfaAJZkFQiwghBWVu6t1qoodXQgopxt0EDZ8rHif36D6487HR29/bD6VsLv8LACDURJiIp2M3X3LJOUPflgZ6ABVDnAIjFbIEKqhD9IXpHR2cpg2JCEjJXxoYbL0wjAyrpoTceikRth9soiuLIs9NpAOKsL7jZb4IiFZ6Nj+8y0g3WoNXAIW7M2I31/2n3RArAoy2ApeHEoVlkPXnsz7r5gEeYxt5UEYpvF8iCPQUFgU3RjuW0iMdZIGaymFVETpJouwea2K9XCMaOXKT0Uk8RkqTjn9XVXcPhN16Pj1TtJ9yBzXqlyEIkzq0Ar+f/Vno8Z0izwhUxDuyNwwj7fq5SanQOspwG8bMIuVZx4xkagXYAl3TXkPMUNdCQaz951H752xtlittvjUwsmgpOmqEQmWxXYptOIJZhsM7fWCXakBSIHWARXPCO9DVsBFkmmjY4yDrjsy5jzb7tJ907qlWQCzOgQBcCawqN7RICVAew05SjUsvBx4Q7Jf+GbjQIZE8/e8X3csPBcbJRoRLU+NHxa9rmwaqFY6OSdYquHwiyQuVk0QZABQ8ycGssdktLXBWANgjcDsPgdMsCKAIsdaAZcVckT667A3+plOPGri4D58xHFMWj7FNfZpEHbqcEmjeHAxEjfn3ZevRT3NQGmIRlZ9SqsgQi3Hn0inv75A9jYdRBFDcnSMUY8JJGVyUxMVYDF+5MyLUuBCY2zbeGZUfMvpFOFZcEueejr7sJJd34L2GpzaJ2Kt6KyPSRZ2dS8ySyH2Yqws2ypXKedF1B8diIj8IxSaoscYP0fgNdM5NWKc2+YERgOgDXT5CR/UtQzqMHzXSCMcM0n9seK/3sEs20bUb2K1GY3VA6wgMBmmdD84eqQtz2PNbq5qXN+Hi6WlIMwQM4WOYZGVwWn3vUN4GXzgUonqingW4aDVewgxxr5KfA5WdepG8WVypKswKAwZ4tNSRSJdMNfbrsd91x/I6IVS+GVmLlMYdciWBm/hnwgZiv4J2XZOzVcGjmnNpmrwX+atBXHMcfgUIC12sKZZbK4CCcspdk2XNdGLaiiYruwGpF01zlOCVUL6PNsrCg52OHdb8eH9v88ul61PdIohvZ8WI4HuszwlJMp45ZjhkbcQMmxoaIQjd89hKtPPgP+88uQUqJBvCBNdpCHgJZMWLVpNj2xNKy1DtTcJD6fR8QAPJNiaJ2bHMdDEIVQrocGg+/aqGy/HQ688zboEruROR5UMzOVX7TJsWopNYoWVvYLBcCaAvPI8LfwJ6XUzjnAugfAHlP2Vosbm7YRWDvASsASiI4CKFsh+vs/sGj/I6VF3qf4IBIkjgFRZcr76BSUUxgEWJxwh0mhjzJahphsJkReI9skC/cqEJI76bcu4rmzcMK3bwQ22xjwy2hIW78pDRYAa5TBnpK/xtQTb4wgy5Sdmx2B2f2GUYwyeXbVqojfPnTLbfj2tdeiTFHc3j6UE43ZHV2wbCXWTVEUoOQ5AoD4756XWTllCyTHlhxZXTDvAFwTwCJYC6NIFMwd35OsE7vSwjBEFEWYN3c2Vi5bjm7bl2sNxAmWxgGw+SZ41dvfhj0P2g/Wli8DLAdRGEn2ikAySgCH0iSTnAVh1pBxYlcmqjU8eecPcP2ZC7FA23AaDSpythTxTegMqd/8+0SWB0czZHO9M8OHG5xP8gyW3B/FRR2j0E6R4kBKwxZevvvbsNdVi5CUjA5ZTvbPFRnMFjJ7ziGNCAXAGs3bmdTf+bFS6t9zgPVVAAdP6u0UF5+RERgJYEnygD5bSYS/3HEX7jrnIsxuhEiqA/B9H7HKzZjNZErhaqpVmwxW+wCL52ImQrqTSFZm/5hlIbIJ72zJCDibL8Ch37gWWDAHsH2E7NCy7MxCpEjTT9+BmxPMjRK7LGe5+Ge2uNHGpcwMQxohWbYEdmc3nv/JT3HR8adigdcBp9qAFYSSCfJ9VzYBMT0NOaY88vSiplwDy9qamTKZdQ2Uk9Iey9PZijk0I0HejhnoFiyHIpTU4800lZSFxooBzJ49Gw26HfguFocB0tld+PAB+2PXT+0NdHZIB5sQyZ0S3JIvZe4o0XBtbh8md/yKHQwhH0FhtYEfnbkQ/3P7XdjEK0nTC8tl5sgsgcyEkfGcjLPDZB05743XZwkzB1hmXkqldOxoW+QnYDvQli0NMrHroJ6meM9+n8UbTjgaCcdNBrAEQK6hr3P4bNXkPf9kxX2aXPdqpdQhOcA6DMAV0+TGi9ucRhEYCWDp1MgjYKCGu874Av78ox9jHhykjSrKbC+PDZ0zJwcLHyPjZHBCk5+3ps/XITbmXIbb5Uv7t+F2tQIsZfuY/apXYN/rFwEbdQOWj0TKPSSuTu7itA6PWvzqMBEwS7cIBAyOIclkmSOjBkFHEfrq/eihnQmtdHoHgMeewtVnn4elj/8DfqJh0VOTgEm84+iXFwnQ4ibByDaYPwZg5dlRLc0bkj1dA8AiX4ekaJ4j0qmUmWh47LguSl4ZSS02Mgy+g2drfdjl3e/AZ448DIpZK2bLXNekqtySuQ8xTGDXobEon2yAJdkagsiBPuCFF3HxfgfDfnExVL0O36ImlM5KbpaU7s3GymyI+L3Nm10mY4APBVit3pQ5wPKUKwBLWy6046CKFInjYAAxDlp4Fjbd60OIfNfY4rQwqvJM6tDnWh1kFQBrMt79KK55uFLqyhxgvQXA/aP4UPErRQTWKQIjAizaR4Qh8MQzuOjAQxE//ywqXHQStiqbso1MqTmpXRtBxZz0KuThNgAWJ2xO1EKip1WYMtkrgixZMpWPLd78Onxs0XnA7E7A9qC1KaysR8HrdYp58cuji8AgwGopNQ0FWATd9QB2J82IUzQI/N0S0NtA8te/43s33oinH3kULz79NHwL6HJc6DCAq1N0lUuIG/XBDJZ03BugwHHGBZp2NiMBLHbZERQp14bKsliEFpoFPlUClaIanSW851N7460ffB+8eXOBSrfh9UhWjqhPNcUpTXcakIiwpxH5nNQjjEQ9//Hvfg83nnoWNvN8BLV+AR22ouad6ZBkyZ52QMxg8ftqp8xkDyrmr+9n4H3lJUJR0c+ya7wPihaLbyJNccSU2kXqOqhqIwGT+B5OueJSeLu9GZHnSjdkxtLLHsNkKXOwP2jiPXRTVwCs9f3eR3m93ZRS/5MDrM0APDvKDxa/VkRg1BEYCWCR5I5agJU/+SUWHX8iZlkaSW0AHgX8ogS27UovTZQJ+lFwlDJ7OanUgKuxTTIEaZwYORGaCRsIbQexZLEUIk7eiYMd3/t2vP+Cs5B2l2Fxz6/czOh51GEofnHKRmBVHaoc0OfZKyPyKO688q9hEsOi/pkhTwG9vXjozv/ED7/7n1j29LPosW3hZal6DXYYG/J2JjmZK7xzIU5l4LMrLit3DZPBEgkD0YiiQZ9tmi+SGFFCWQMLSamEmlXB69/7bnxo38/AfeVWQLkEWAr9/QPo6uwRcFWrN6BtC57vZTkSDadVMn6ymdL1QJoNbj/2BPztx/eiIwilQzNNIimxUXKCXZfcDNEjlG+im04KKTmZecl1/Q+w4QDWYNNMBpxTS7SvOIcltoWqo6QJYdamm+GYyy8FdnglEs9oXrVmsHJrnRxktQKsbORlDzy2uW/9R8OPkPIAACAASURBVGuDu+LmSqnnml8tzT7RouKxwY2CiX7gkQAWE1OqbwC/u+ga3Hvd9ZjV4SINBsRtnjs/7gCpDRNmZRKa2ArAkvZ0bmaN6fNYjkGApVGJ1DAAy0GaWNj1w+/H2790EtIOH5b2hDAszWcFw30sYZ86n2kS3AeFGzkhckSZdi7DyeKfoBHCpyEvQRYZ4i67XAfQEcWmDLdkOX7xrW/iV9//AerPL0aPUigniZQAybMiyOKCnFvoGD4Wz2aWzuEwjvCj2bLvGiPkehSiHocolcvYePNN0bXllnjf4UfA22ZrwCmJRhscl98OUWnnI+SEaT6T5F2ZpQ0bhsPk83myZ5yst8LHj2Kkj/8DX9z/QHQvXQa9cjk6Z3chCCiRwUzfIMDqF09kjdkNxjXNmlEm5+b5Pp3UZNDyDJYALGX4VzKWYiVdpUlqoaE0opInAOsVu+yCT51/HrDJxsMDLGm8MM8lGH8InBocL2Ob+yYnYhvMVbVSpuTSCrD6AHRtMCEoHnT9RCC3iMjraeSh5GrGOkEaNeCsHMC3jzoVf/+vX6HLo8UHd+jauM+LVYQl2SQOVwOwUkQ2s1jtc7C4K2Y6vxyZBD1LDnkGi4rxibbxlr0/hN3OPh5JxRWAxdb7NAGo4lAI0ayfYTQhV2mRaRCOVAZCBgEW8YcF8gSZMRI4lBhphboCfKVQQoy0v99AfMcDnnwaf7z3p/jjz36OJU88JSR4CuUSDORt+60lbZPxMOmrQbsd44/JjFXqWAgS09ThdVYwf4vN8JrX7oLX7fYWYOedga5OwM2AEk/lsMswQU3TZcBFoLXcJ7lWaRTB5aDNQKOJaZsAq6WdrVUtwZRGsrfWIitgFp0MLvC/N6g1b+GxO7+Lr552OrayXdiNGtwKjbVrIIcp51myRFjzzEm7QoIYUgUmN4PFd8lnJcgSo+2hAEs6jl0RGG2Qa9bRhZUOsON7dsdHaPJcqQgna7UM1hCA1Tr+VwXjBcCakLmhvZP2K6W6hwKsJwBs1d55i09vcBFo6SkedoLlqpXPCPnEzhKJ8BciMUsbePAhXLDfEZgfpLD6+uHSwNklqTcW7lW+U+SukJOxLHD0QFUp3Kz7byxxz814heybSSPLRCk+cvQ55OTt4K2f+ijecOoRiDs6UI9TVJxypt5dAKyxxH1KfSYbtKtVzFYbzIN3nWcUTAIsgcPyNf9Sb5gBwcaMl5Zg4Nnn8esf3Ytn//Z3vPj3fyAeqKNCF4A0Fe0slhnl3zkAHbofatSRIKJdimMjpmuABSx4+dZ41et3wU6v3wWbvvKVwPy5RoXdNvk22kzlavEC15qG02w+FLg4KCfS+lyrrABjeCsCULPPNe1bjOOCXDXjRsbM+DG7JodpBpCCa5ICQcC6K2444lg8/Zs/Yha7NrVGkIaw2DHQItrJfxfOVcutErRO7mHmJ8lOKiMjI5b0GQcrDAP0dHdjYPkAyuUuxMrFUyrGBxeeiNd+6ANwOnuEnyXPyU1o/jzSiJD9bHIfsLj6ukfgSaXU1qt8vbTWvwaw27qfq/jEBh2BkXawIwGssI7H7/4BbjnrK5gbAqX+Bn10UbdixI5GanExgmSYjIyCg8gmF4O7fC3df1ykxnrk2kcGvLW0W8sywEXPxps+/iG85axjEHZW0EiAkl1GtpE2H5psDstYH774XNsRiNiQQY4UNwUsaUumlig9AfoGRJgWy3uRPPsclj//PBY/8Qyee+JJLHvhJYS1KnS9KirezFbZvo+OubOw0eabY8EWW6Bz/jxs8cZdAZYmK2UDUlh5sDRSZrUI0kRna81ZjIlUYjeKn9n4pz5ds9xJgEFGf3ZfWQclAWSahHC4MeIOi3X2Wh3RX/+B848+AXhxOTaixU//SnR0dYipNj0KeZgya9YkQHpmppAqP58kkCWgPMtg8T6Eo2cbf0jOVQRZCf1NHRdpPYFObTh+J57xgX2+dhG22f1t8jPa6DQBVjYi23fIaHtoFycYewTuV0q9dSjAuhnAp8d+zuKTG2QERgJYrdgnW3vyja+VRkB1Je4+/yL8/tt3Y1ag0dGI4VO0UQdIPCVpd05WpQxg0cDWkF3539jmbiaysR5NgJWdg+fOVIZMx1dqYeePvA9vX3gi4p5O1FMF36JGT8sVC4A11vBP+8/RCkXKh9pY7bD8ZcqJWemPHC0KlQohKjElsaAByKaANW7jh2j+8HNMh5DUTt6VJ/wkktZZ+uM/KfOQlysNsJrEElEOsDIsRTBhFpUMYJGfFMWwfDaOGPshQgmyw2zW2OMQqIe4/9rr8d2rb8CsMMF8p4Sw2i8k9yAJmwBrUFDYlASZyeLB7/5UBVimFKqFS1q2SggCGoV3onduF46443qUXrFNAbCm/Qww7APcopT6zFCAdTKA82bm8xZPNWERaAFYvMaQvw6yM/PRlpUH+VeLE+yyJVh06GFY8fDf0FNPUIlSeK6DvqQO5duIVSJLCAGW+JBlAKvhsIQ3KNQ41ucbCWCx+2e79+6OPc4/A/HsLoRQcNACsApwNdbQT//PDVNuS3QsnnLcGFimUNakPMUIQbYNzXMMBEtNKYxmwM00qAEO+W8Ntu6bn0vSRCux4WGWY1JlFlpKhExWGYCVGjJ9mqGumA7NQMDsM7N0Uj6MRYYFtRqwsh+XH3YUeh97As5AHbOUhbLjYMXK5fA7qN2VbXeajg0GYA16kU4+wOJ7yT0SWzNYotNFWZkoQYffgTixUNc2Ol+zA/a76XJEc7thwy8yWNN/Jhj6BKcopb48FGC9F8CPZ96zFk80oRFYDVGZq+XUrKbZbgtXSzR8SGCnx9tjf8XC/Q+Gt6wflXqEUqJhWwpVsF5oI+KEnQIlZqqkHGAyWIGtoC0tRrxN0uyYHjQz3812360ZLEn/2w62eOubsOeic5DM6RIGCSnDNNXNq0FjumzxoZkRAal0pYY/Y9FLjrBJC5+KykZJNmLYqB8jEnDFxg0WjxpBAx1+ZwactJDTyZbmuUhGJ+iSbtXsO6bYHMJ/z4nqrehtMqKZA6xcRJXZuwxgCZrKS4R0GiLZO+PXh0EVnXyGMMDi+/4Ll512BuakLlR/FV6coLNcxsr+XrhlT0qnPEh0b/LMhKpkCobtfffbC1orb4/djjxaAZb0jPI2OadRz8utYEk9wJs/+THsfvYJCMseHOUVAKu91zAVP72HUureoQBrWwB/n4p3W9zTFI7AWgDWmu6aiw1Z7lYU4YUf3YNrTz8TXQ0NvxGhlLLUkiJ0NVIHTYAlXKvEiIoaM2aWS/Q4lAgGAZZUPJolQi4QNizLwcavezU+eu1FSDfqooa0FDmshO3XBf9qCo/M9XZr3CyIsbNNYVwZ3U0idqxjOFxcTbFIMhpuTiwSyYcYFonvLCNmh3SlpfyTmp83ic/ZL+SbFQEaaycgTSgHK99J8XuTSU6Qgi4a8Tkyks5GoJG5HojNT72Gil+SUul3jj4eD//kpygnCh3KEu0wncaodJZRDRrQWVyMoPCgsKeh0udy+2OnCLQ7SHKQxblJlPItzl7GzofdyfRa5RHTwLRUxrIE2P+cL2Dz/9gTiWeLzEzBwWr3LUy5z79CKfX4UIDFVgb2zBZHEYHRR2C4+b2lGWbo1MfuIdmRpxqqEeLXF12IX978TXQEGmXprNII4xC64khHFbet/H0/NiXC3L2emSZO6u3wr/KHFKXoLOsWcT3jYiC7bwWV2Jj16u2xz/WLoOf3QDslkW6QHXUBsEY/Tmbob7YOf5YGmWUSXzn+kXGVAQF+EdhdyM45cq3sjL2dd9YKJYsZKmbCMuBuAVGkpZuOYy3/LondTZJIFliETNeCsdYLwMokLozKV9bzkQMs3qxrSoRCMUs1vDQW0Nh45C+4aL8D4SxZBjfWKNk2bMpgxKEArIFGHRYJ4jJ2so2QNhY/kh1TdHVohbPrf5Blnt1NRfehAIvZTQLoMNKoszN01myccf21wGtfhcThGKHlVkFyX/9vbkKv6CmlaPm5av+T1roKoDKhly5OPrMisKbJPZt0h3LBCbDYFSg6DY0G7jriGDz+i1/CbyQoWRZcat0EDbhdJVRpmusaAVA3MV2EBDaUUjByCu2WB82ryH3gjGBgtsZJSULRgxrd22+LfW++AumCOVBeBamoSxsvwqKDcGYN53V9mkYYwKdkQnYwo5TzppoEeIIqDtZcziHHBPwO+HkmJjtB65hqMZ4WTNEUnWRpzACNSZdiy7JpOcF9FYCVZ9pYIoxS+J4FlSRmU7S0F/ffcQfuveQyzIkSdJUqCKo16d11XRfV+gAczxUJihxgMQZ2ap7bbIDYsadFHmGyjqEAi/fSavqs6FFJNwrbw4okRXnrrXHsrTcCG8+RuYYF4xwEt4Lhootwst5o29etKaU68rOsQtHVWj8JYMu2L1GcYMOKQGsJo0XzipvXWCeyQ4vSAL7lslpgdvGchaoNXPDuPdC5ohe62pDWdpJ2LdtGqGI00li814xnW9ZwlV2LGlUERKuy6Nc97Dm4ktsiT8biBGnBSi2ZzG24qM/txtHfug5q+5dLHxSJ71bmjVgArHWP+YbyiRba4WCZL0dK2fZWDKDXEpDWCXqwiEhAMUh6n+x4Grw4CIPknpnBypQYlAuEsqlKjAUWye1LV+Ccgw+B+/d/oJtehMPsVeS8TU2vjPyvTWZQZCCmBMDKrY5a3k5WKsw3b2Gcim7ZSpu2W+/Gx6jgTiDW0VFMH5M9eMf/+k8ppZp6okMBFolZ7xn/axZnnPERaCG85rNlK8BKEIGe8QKwIhJMADz9DM774F6YVa2Jvxtb3bmLy1WRxfLDMhOqKQ8OJoyYJxhvgBUrA7BkYkwdAVie9rCy08dBNyxC1xtfI4QSTWKqtOZPbpf8jB9T0+EBh6KjbEbNf5znVoYDUZmQQ7MhJJ+M86Wafzf/3mQcDYPG2lRiH4cYDwuwhOQ+2EIpWZ0oFpsbBCEevvO7uO3CizB/oIqOKDHiqC33ksciB1m5tRA9CZnRzgVGJz+DlUlT6JyEP6jqznvnfXJqS0sl9DoO/v2QA/GmAw8APGa1VrV3HodXUZxi8iPwE6UUGwZX3zRorc8GcObk32NxB9MlAs1deg6wWkYWJ80AcVbMYN5HmfZs7j7jFEv/+wFcecCBmM+JN7ciSVOkJA1TpZo2JdrY7xqC62BUDLhq/2jyr1QqnV/SRUjZocSBKwDLwRLHwscv+SK23pN7DwfadqBU5keYC1S3fyvFGaZbBNbAP+RjtAKsVpbQ0GSvAVEZMVw4TFx0M1jW+p2SD2Zqls3vGGtMkwywsgnAtKa0KMYTYPHINFdt7qwagWSxsHwlbjjlVPzz/v/FgihFKU4Q26aKmpfccluhHHjRKqv1v+VefyzJjddcMJbh12o638rlZDehPH7CXhkHgW2jMasHB138Fcx/066AXzHPM5aLFp+ZyhH4olLqrDUBLK4g0l5YHEUERhOB1QDWkF0rZRbYts5lQ+iqYQTFmkGU4sFbb8PdC8/BRnEspUFZiOgvRiK8UrBtW/7OYyLBlSyIqwEsC25qw0tsvGSleOdpR+ONB1I7zslIyq5poS8A1miGycz9nVGCrKGgS8Z0k8ueC3S2hKkViTU/nEMYAq0MWE0FgJX7KLaS3EXJ3TxgEEbwPRdo1IV7+fy99+H6heei0ldDZyMQJwa6M+QNJgRXuUI7v/esNtIfdFCyIVd2N+BqqgIsAVCRhsPuwSjEnJ1ehcOuuRzYaCNor0PuOxOkn7nfjw3vyd6rlPrJmgDWpgCe2/BiUjzxWCOQrwNNnmn+g4wsPgiwmMHSsBpUpmbfdowfX3Ah/u+WWzErCgWpCN8iM4IWgEUdoOzv+f21Tqb5jnas975KyZE+YlIiNGdj27Unf2wsdRV22Hdv/L/TjwccXwCW5OMGazhjvYXiczMpAmsjU63pOUcgaJv8bXP0Z/kuk+niMakZkFZaQJOQn3cSDt53FCVwuRGhKv2KXnzz5NPw6E/+C/NdDyXSBSi46pgGEwEdKcQCy+jeZQCLICtPimnAa0nyTQWARbicUxl4P/QkNAArgdfZiRerdbx574/gvV86HanvAaokXZWT+v5m0ndv6jzLZkqp54cFWLJR0pqOpYNtMVPnxos7mWIRyEsfshPPySbSbm6256ILI5KKhhouujAxSQkK6K/hppNPxdJf/RJdQQOR+AwOtrjnJYDWR24lvTYH8FgWtezDowFYbmyhr+yh8o5dcdAF5wI9swF2BcWAcosZcooNyfV+O80NRn7l0Y7HZqZ3+A44cxpjbNx6ytbfnvQuwtYSZpawGiS7Z+wxeYAENr9sjQi99z+AS487CZWlKzDXZiY7ksxUIwNYfGqxxqLDEFVaMo0tApa8w1fpVACWqFo0uZjr/dXLBfMSYSvAEmoES56cHhoRbAqnKgv7nHYittrno4gdF7ZlltgCYE3Oe5ugqwZKKZqDNo/V3q/WmmKjFB0tjiICa43AaABWbAp+slTYFGPk9o5ZrMUrcPFRR0E/8gi6IjK1NEgyZ+lDFg6S2pnFyrgc1Jfh9QaFQLMSy2gXtGGexAAss2RxUhw2gxVZGOgqY8W2C3DclZegc/MtAb8kxr6W6xYz5Ab+HRk6/Na8YJrxO/TIVJ2GjWIrj2tNYZ7UCvUoAFZCzlVKE2wALy3BHedfhId/eA82DTU6EyBIYuFfNRxLSoQ8XGpyRqYMKIbJBCxO2gKwTAZrKgEsMUbKSputAMuNFCIF+As2waGXXQC8ficMOAplq2J4pQXCmkkzyONKqVeMBLD+E8CHZtJTF88ycRFo7uCHrgYZwSSi+GI2idhIhPSJgTrwzIv48sGHw376n+iiX5dlugepLSo2Opxc6dGW2W1wp9gKsJqdVm0ALEbF5AjMkWiWCA2ZViZ6lggjIOqo4KluFydddyXmvGoHoNIJHWoo1j0KLayJG1zT4MxrAlirD8s8t7PqQxlS+5qPkYb3pK7P+Q6L5cHMz5pPMrRyngY12KnGwCOP4rRPfxabxBrdA3WxxUqdzPrKMR6DPAhUaOJueFhGV4qk8Uz5Qc4vGzApLraWUNf/gDFzBaUa+CaNZIMBWOa+Ot0KVkYR5rx6R+x71WXAJhuhmqYouWXx/qZ9UHHMmAh8Vyn14ZEA1vEALpgxj1w8yMRGIFsBBieaXGV50JAwkmwP4VUIjzCJXIzfPYLzDjocpf6V8BOirsEOovyGW4ntMo3lLfCitN7+Y0nreEY2zkm11NfiZM6SBK/fESjAdfGSo7DXScdhx333RuqVYfEXeLA7anLn+PYDUZxhvURg+AzWern0xFxEdjxAXK8BXWVunwxA4neV3CMhXqVAEAB9/bj5tDPx1K8eQKVWgx0E6CqXEMWGqJ5/F/n51q5hnnG8qQHjGQyhNUjmimiQWTZu0pSYUVOMuEOX8VIcY4+TjsDrP7cP4DpAmTZAMUq+N6h8P543VZxrsiJwglLqwpEA1r8C+OVk3WFx3WkUgZYVI8ld7wUpZSAr+/eEk49rIUIo9rdeECL6xW9x0ZHHodwI4LKMMAmHcMQysEZCO3fOnOxZqqh6Rnuos0H/OIWq7eC1H98L7zz7RCSVMuzEM8/JNaQAWJPw9opLTnoEBPlQpT5B4rlS5mcW2KUIcBjDJ5iIGkC1joGH/4LzjzoWXX1VdAEIqv3is5jbxEz6s4zxBlLqcuk0A1hJk6wvJkmpByuy0Vvy8PlrL8Fm73irEcXyygjiEI5bAKwxhn2qfuzflFK/GglgzQGwbKo+QXFfUygCowRY1LXSjhKApRDDrwdY/L37cO3JZ6KLE/IkAqy8QEiAlZdbCLBqWZtST2QhDGNEjo/KTq/EQTdcBSzYGEicwT77Sa3TTKHxUNzKhhWBHGDlGnaGQikHuVceuQF9A0CY4NYTT8Nffv4L9KQpOi1xwEJQr8J2p3c/1VCAxcS2KXUax4dYO/C2ehmO+Mb1wGYLDAVCKSMySgrEhjViZvrTzlVKLV8rwJKkg9b93LzP9GgUz9dmBIYALP5VlNrl59lMm3UVkj/BEiEQw6s28NgNt+NbX7kYs+g/OMkAy5DqB5WY2a1UI9MWQFdqQ8cakXLR11nGMbdci8rO/4KYVjoehSSKo4jABh6BnItFb0WXbqMGYDlxDERA78//G+ceeRw2sih7EkAHDXS6LuIogLKcSdWxavfNEWCxUcYTE29SC7SRZ0htxMpFzfPxug99AO85+zTAI2fTARzTHBMzRlZBwmr3HUyRzw8opZicXeUYdn3QWj8MYKcpcuPFbUzVCLQArDgrEa4GsFj9Y4u16OTQcyyGWw/wvxdehZ9cdyN6lJo0gCVYMCsRinlzZsXDMmHdNaT6UkqBVAdxpLHCc7H32adi2098BAEJrX4ZbtFqPVVHZ3FfExyBHFcJRAj5N1ogaERJDEslsPmlX17F9Qcdir7Hn0C8ohddnR6iRhUqilAqlRCT6D6NdylDOVi58CmdIOqOjaXlEg798pew6fveZfiezNhRnZhUhCgSY+vimBER+LNS6l9GC7BuAbDPjHjs4iEmLgJrAliCXPJaQQawUg1lkwYbwwpC/OTUc/D7u76PziSFw3aaST9MBot/jFCg6VqyaOWhXKShRlAuYfsP7IE9vnAKkjkVBJYLn+3Zk37vxQ0UEVj/Ecg47jL+pTtYtETJs0xhsz0uiPH8t+/GVad/AZv6JehGDYmOYDsKrtZIkgjK8qYtwBIbn0wImSR3ZrI4d7Cj0E4d9Hk2qlsswJk3XgdsuYVpGZRuoGzGmMbAcv2Ptil/xVuVUp8eLcD6HICvT/lHKm5wciMwGoCVtelFSQqLrXqIYDci/OdRp+BvP/k5ykkyqQArB1QsaeYAi49FgCUSXGkCO1HwIgtpqYx0801x6FUXAztviypsAVhOwXKf3HFYXH3SIsAMlGUNqnnFSQiHnKwoQfrQo7j5rHOw/JG/Ie3vw+yuCqphVewTKyUP9WoNtlOaOQArk2jgXGInNpaXPWzz8ffjY6efBFS6AIvWXyJJiqZ2TQGyJm3sjvOFP6+UumG0AGsXAH8c5xsoTjfTIjAEYBE+ec1nzKSds9+JuMNzElg6htWIcPtBx0jLdok8hEnMYLUCLN46MSBvOSbAYkrfUYhrDXTpEhLHxYta44Trr0DpvW9B1VIowYNdAKyZNrKL5xltBLLvd0C3BsXOuUA0qvDCUvzpW3fhe5d/Fd1xii7fwYplyzBv0/no6+uF0glKpQpCdtVN4yOXj2UnYVM6RtMUjOVBDx+9+AvY4f3vARwKfFuI41R8V1dRnS1A1jQeAc1bf61S6sFRASz+ktaahBmh1BRHEYFhI7AOAIsVwyiuw6OkczXAjZ85GIt//38o6xT2FAJYsjhkFhgibGgDaRihElnwy51Ylmrs9JH3413nnYKYcg1wRae+9UiSREyqC35F8b2ZSREY6gtKQBHXEzgVB3X6eCIWCQas6EP60GP46qlnIXz2RfgJfaVYQ6RoaGZs3Zw7prfGCSt+NKWv9a1ET0+PUCN6+6rombcx6vNm49Bbr0YwfzYq5R4ja5yrt4uUTdLkY82kcbIBPkuslBqWTLdG7Ky1/hOAV2+AwSoeebQRGAZgDZK+WzJYTJ2T6J40jOnryipu+OwhWP7gn+HRp2wSAdbgo5qJPgdY7AiithdBljRcN8ixcBE4HnpevT32uvBMVHbcDtAO4kSBoMpiR2RBWh3t6Cl+b5pFYDiAlTm0o+ZqNNIq5tDIfXkVPzptIR7+0U/RmZoNFK2uDFtgVTfF8RAMnsww0pSef7ROxAYsSbR4DdYsC2/8xF54xylHIZrVBQe+dBzHGQNLnjvNjO+LDNZkvsLxuPZDSqnXDHeitQGsiwEcMx5XL84xQyPQArDCbGe6CsDiY3M+5R8HSLUhwGJpL76276H4/+x9B5glR3X1qY4vTNooFBEIAwIjG8nIBJGNbYLBYDLGQoAAEY0EImcQQYgcLECAABMMGPQbbLCNBYhgZCFETkoobprdnfBCx/q/c6vrvZ7Z2TB53mw33zKaN/26q29VV52699xzJ3/5W/h5umYAllGON9rRLEzN3XYHGcLQBzop0jhDUBvG7tDFo15/Du7yxMcCbg1ZUVuHEy0PAi0eaZqacEB1VBZYBxbYL8CirIkTCT3A27sHN37nf/GRF78CG6MMIRNFdI7ENcE0t0h+sTDLqrYPqnmU0pIN2GgModVqiSixPzaGG+MIL/3Au7HpIfdHGjAP2cwDLGpPJ34FsAa1x+ds97uVUmfPF2A9AsC/rSszVA+ztBaYBbD4KyfZAqIYjSjOpJkRGlUqBbIE2L4LFz7teej87lq4ebKqAMvWHbRFpemncgRgCURCFwm8MBAtLAKsZtDELVELf/q4R+GRb3wNMDSC1HF7QIqLEP8RZDFMaMHW0hq+ulplgZW3wJwAK2FBPbp5cyDuADdvw3lnPhf+dbdiJMugs0gaSvFNZtjxPdPcZhVbe1u/b+WfZmnuyEfvdrvww7qU/fE8X7KN89sehXM+/H7guGOgfV8yC0lwz4vypawaUYUIl6YP1sBV/kYp9bX5AqxNAHatgcZXTVirFjgUgKWBLGUGIctiFADrlh0GYF1z/aoCrHL9Myq5m4XAbC8DSTtPEXs5Err/WfaD2YTUtyFv7Lij8dzzz4P3Z3+G2FHCw+A/uUaW9f57rXZd1a7KAvO1wGyAxe9rZgdzN9LuAnv34gef+Wdc8pGP4TZwUaf4Zk5xYXuQNkBwxcLOhbdXa5E3GMSDj82aznzfWXvQ80MJAe5Ehvs9+ww86PnPkbI42vWhmJJMmkRBOfOqEOEgdvn+2rxZKTVn9ZsDRn+11tsAHLGeLFE9yxJa4BABVp5RA6vwYKUxsG0XPlJ4sDydQrF+xCocs2sR8mVIHCozG4BFza7MB6bSiAsxHQAAIABJREFULnSN2YIK3nQuZPdt3Q7++qxn4dSXnQPUfAkTMERoQ4IVyFqFDq1uuawWmA2wbIF3h8ztdorx/74UH3z1azGmcuy5+WZsHh2Cyuih5p6FolEONMEVXAEk5Dk6Aw6wdJ4K77LLgvZBiE4cY3p0GM/7yPuw+V73AHRgiOycK50KYC3rAF2di29XSt1mf7c+GMD6KoBHrU67q7uueQscIsDSrCLBbDxysJhRtGM3Pva052HqV79DoBiUWz2AxR0l+RC1YmtJgMXZMCwAVu4B0zpG5Cu4ykXQAZpBA7umWxi6211w1ic+Cvf4Y6Sr4jhGEBihikqlec2P3qqB87TAbIAlYT8ih8kJBLdO4p9f/hrc8OMr4addOCG5Vwl8Vs/Jcvg5KyUopMqTkHpCgCWYg+LDg+vB0mkCL/ARZbkUAssdD8fd51Q8/n1vBbZuBrKQHxpL09tVYC1T8aIQCaxI7vMciWvq9EuUUn+7UID1LAAXrqnHqRqztixQVMhIi0myT+km16Igcxa7tzyL4DBkMD6Bi05/Pvb88jeoC8BanQl2bg+WMa9P/hSJ7h7QVTlaKoPnuqgnDnwEpJXhBp3j9PdfgDs++IFwhhqI4wRBaIrXxkmKIPAK6JiLkIPMowXJ13K/qrl1bQ3nw641dpN0oIFoz6GnqjiPBdH53jpJB06mcOkb3onL//Xf4ExMoe5peE0f0629aDieaMtJaU+tkEjtQUc8xYI5VtmD1XsPi2c03Mv+US7jY8tq2b+SP8ZaggSeJK+30gz+hs14yDNPx11feIZkE3pEVPxXCLiTiUBTSE5/MXcedmNufT3ws5VSH1kowGJtnZ+tL3tUT7McFtCszccLW2eUy72pKfnMmq+kMOk8hiIRNkrx8Sc/C3t/+Rv4QnJfHYAlc1yxYFh5hh75trfwUK7BkHRljrS7UTiYDHw0T/4TvOA97wbGRoBaaJ7fM4RW1nWNZY+fiR0kw5J6Fdy3S21GUzSjAlnLMSKrax7UAkK05kA1g7C83tvhn6QJAtcHpmNTpJjlXlxgr5OhgQzBrt2IrrgS55/7KiS79mBrvYl4uoVmo4Yk6vSKGdNLLFFCeZf6Yg2rmUVY5mAyjElw1X8XzZxkz5GfypzDw8pLKIKrKEYYDCGuNZAffQRe9KH3QJ9wDLr1AB5cESJ2ionGvvdVbvFBR+egnHCSUoq1m+c8Djq3a62ZBtIX6B6Ux67auSIW6G+ACwl0AgxBIgZg8UgzIKRrPOkKrwntCJ946rMx/vNfIxSOxuoBrMUYqe25mBoewZmvew2O+csHA7W6gZQuMDXVRmO0gYT1yZDBQ14CWJ4Uv7Y72YO+hItpZPXdygL7s4C8vMW7VxqEZSeOiOjyA7K3+bPbAYbq6DoMq3eBX/8WF519Dm743dXYMjSKaGIKNeWh4XuY3DuBer1eACujg2U3NLZJzK5brWN/AMuAJ8q0mI2VbXN588Vz2HLXVeh2UtSbY7il08Vppz8FDzrnBcDmYbQJyKBkE0U5Yh52TnRMwZzqGGwLxEopE7JYBMD6MYCTB9sOVeuXywL7ACyLlVxH5mR7cMeWxx1QhxCtDj7z9Ofj1it+ijBPwEKpg3hErotducadH3BfPPXt5wEbNwB+IGrNfCRu/LNCCIzEeZNjyBnbqzxYg9jh67DNPc9z70U2of3ePsl+XvzM00RkTOBSUHQ3/ueCd+Jrn/g4jtqwGYhToBNjKKghT2I4VoST736hk1cGWAbIrB7A4t3LIcLZHqyy96rc9RZc8ScTW8i/codHsS3J8LIPvQ/N+98bqLmibk8gxfeexXPkfoXUKj8vZoN1OKoOm0e6Uil1ymIB1lsBvPywMVn1oPOywP4Ali55sGwYTACW7wCtLr74/Jfguu/+ALVscAFWSq2rsIFxR+NZb3odjn3EQ5FnOTqOi1qjBp1peC73qVZt1SwodpK1y0u1k53XkKtOXiILiFIAeVQ9rqQQq3phMblNksP1HEy1p9FoNqBZzDll1qDGr770RXz67edhc+gjhIvJXbsxUmtAZbkArGazKYkfxvNjPEICKizfST5dXYBlTTmbe8UMx9ket3K77X+ztmAeBJjyPBz/5/fAk992HnCbzdCORlpUdeBjW4Bl3v/+c/e4mUvUp9VlVtQCb1NKvWKxAOuvAHxjRZtd3WwALVCECG0tvwMCrA6+9vLX4yf/9h8YZRmaAfVgESh5YYjtURdHnnoyzvzg+4BGHVmzCe26SFONGsm8ltyizCJjcoeqHewADvJ11WTjqTLcSVFYL5GwymCIRWlT8cYwvD+NEAG6l/0Y7375KxGP34qxeg2dyWmMNJpQLN6sC+jGAu8sIzNjB2GKIovQpvXorOIOYx9gJd62Uliw5GMTz1XB07IAi+KiabOOW1WGs970etz2UQ8HghqyPIMT1oR/abdV5okLvb0CaFUczIF+pf5aKfXNxQKsEVaPG2gzVI1fAQsUyKogGdCDVSQhG2X3jP8iOGR6T7fx7be9F5d++nPYqJhhtDoyDUthlDxJkdQCTNVDPPGcs3HHpzwRLLjIDCIuXYFsg4s7cQ0TgJUL8bU6KguspgWsB8ss+5RRKFrTd0tLKDvSOSTpL+uiRvD0q2vw+TddgF9/5/vYOBJAJwnSOMFQWEccRRgaYtmYKfBLUtGg9JDkW3LkO8WHzCgsZ+qtpD3KIUH7yBZczayYaLxus8EVrRZrjVboIzv+KLzyYx8W5XYJn8rk5/WLW1vjEsgqUtqK2qdVkstKdvlS32tUKTW5KIAluwytfwPgTkvduup668ACvV1vCWCJpmAfYFFoVCidKjVq7u0IP/7wxfjqB/4JG1nrLxtUgJUjzWJogqlaA83b3w7PYkbhUVuBkWF04aAmmVrFP+rg2KzF3rJTAa118BYM8COYGoEmzxUwCuPFeHWBiERvWQM6aMYJcPMO/M+Fn8C3Pv15HDMygvbePRhu1ilyh3a7Dd9x4ddCdDodBLUQaT4zNEjPlfyjyHuRmbeaAItSLLLG9QjtMwGh9TntC7AIDBViKEwN1XCvZzwZDzrrTKDZKIRFCz0GRxvHoKRRFjItFBwtuFj92q0DPIQOz6b/Vil154M9+iE5Z7XWFQ/rYJY8XP9eCivIzGxDhCWAxfKDzO6WbatOqciJX178JXzhHRdgQxoPLMBiMWjHV4hJ/NUBpj0PD3r6Gfjz5z0baIbouJ6kuNtwCIdIBbAO1xdlDT53kS0H1U9ImQ2wugQeeYRGmkHlOS5/74X4yocvxNH1JqI9e9AIKE2SihYUFc1ZyWD37t0Y27QRnagLXQoR2tCgBVi0CPV9VxNgWXoC9amMHAvV5k1flcnsMwnwBiiljkLHDRBvGcU5H/8QwjvdDllQQ5RmaLi1IuSa7Quw6MEqpCoqgLUG34tDa9JB+Vcyhg7lWlrrBwC49FDOrc45zCwwA2BZdWLuCM1O0BQ1NTaJ4wh+zYHqRrjlP76D951zLrbkialZtp9jrvpn5VPJ8TjQsdjvH+jamZNjKp3CxrENcCYzTHVTNO50B5z5ljfCu8fdoBsNRPBAImzdM6yrdpKgRvIr5SmkdmHlwTrM3pi187iWB5XnyFlUr3hfuSFiJFBC2aEDVyfAZBvX/8c38Jm3vBPYPY4jN23ErltuwXC9MWMDwWuIE8xqXrH4eQmwlD1YsuFw1bICrAO9/wRNvvDFgP0BLJUr5FkGJ9Oo1WpSoYGhT3rpxqdbyEbHcNIjHoJHvOlV0I0AbdpQhagxFEh9Gq8Q0ONsaD1YFcBaO+/AwlvyQKXUtw/29UMFWFwJqIdlMs2ro7KAtYCdpO08UggX2pBDb+fHos/c6boZvCTDnu9fgXe96CUYnZ5CIyWNdu5jsQBpsd8/UEenTo686SJpt1CfyjE6sgm7HYWt9zwFT/rwe5H7Cnl9WMIveaqF8OtT2DnPRPuLGjrML6qOygKrZQGKZPo+6+UBaaLhkDdVlHORxSHqAJ0OOlf9Ah941euA7TtR1zkmp/Zg66aNiFtRUWvQPIEFUxJ2pFdogAAWvWnWgyUSDJpvpwtNj1StjqmpKdQadSQ6RzvqwtswholaDc95yxtxxF/eD12W/fEboHYYMy1pSyPiWsoiplCx9ZRVQsOrNewXe19GzUOl1EG5LYcEsOTF0fq7AO672JZV319nFigBLD6ZKXtDaU2hssrcIntjnueQMBsjTHMkv74G7zjr+Qi2bUOTu8LScTBQVD53NT1YBFh6yMOeXeM4vrYBWTtBJ/Cxpx7gUS8/Gyc99UnIHYXcb0iTu1GKeiiS9hBsJbaqANY6eyMG6nHoPJaxyKXCDkcH6MYd1DxPqi7El1+Fj7/5POz+/bVw4y6GagGiqIV6LYCOSzIPElYzITbrxSLDy8gdGBI9N1xWNV2mBUevqgfLLdzrxD3lEKENZ5Iyyv9u1pvYM7EXfrOOFBqtNELUbOAOD3wg/v6dbwfqARInh2JokM+VZPCFFzELYBUk974e1iGGkQZqVK37xl6mlLrfoTzlfADWCwG891AuWp1zmFjAhv96ac1FuRzkQuLkTs6WoNFpDuU76OoYNc7qN+/EO898DvQ11/YA1nyAlbXwagIshgg7RJBpgqObY5jYvgv+0Aha9QCTm0bwqgs/DPfEO4Lw0QsaoHxQ3Omi0agJEOXzKlbBro7KAqtggR6fPdbwWFzTc4QnmcRtOCqHS1fWL6/Fp974Ftx61S8QJgnCwIPWKbI8QZ6n8JQ3g6tkldktyKK8gyEAFMWdC4DVy1hcAwDLEtzpcSPwEUxUtJMA0leO1B51Ag+tNIYOPeSBh50KePEH3ocj739fpN0uvJFhJFRXdh2JDBK7GQbDTB0809VFrdZV6Pfqlou2wIuUUu87lKvMB2BRzZ2q7tVRWcBYoMSvMhUv5gBYxTl5nMIJPURIEFLqfOckPvqCF2P3Ff+HoVkerPmYdzUBFifmJGP4IEDS6aJZr2G63ULs+ZgIfNztIQ/GY1/xcuDII9Fud1EfG+mRHpO4Cz9gBaqKgzWf/q7OXToL8NUk6M+jDKF4W3Lk3RacWgDkKXDd9fjM69+OG350JUa4QUpiKI8eqhxpytCiD1K4hQZQlI6xoTUBECJHYDhYVlDUUgas/hQ9WMt5HIyD5SjTPnqvhDdm5ROKTEePrq1cI0kzhCNN7I0jZKGHiSzCnR50Xzz1Pe8CGk0gzoGA2ZQAv8Ii8ZzmGCUkG7Vf0L54322JoENegZfTStW152mBU5RSVx7Kd+bVvVrrcQAbD+XC1TmHgQUOCrAKAUMJP+SA7yCiLAOR2e5p/Nub3opffvWrPYA1GyyJSGFBQt2fNVcTYHFt4ASsPBeT8RTCRgjkGZIshz80hm1xjIed9Szc86yzDOF1ZEjiASTKeo4L47yqANZh8Kas2UeMEw3Pk4qDQLcLOIZWkl1zNb7+sYvxwy9+FcewgPP4XuFc7dw9DjfwJUEj0+RU9snxDP2VAZZchyHCArjMKJbMkU/lglUEWGyfW7jSbEF3G8rks3jETNpDGsVwfB+RyhGFPtqext64g1d95EMYe+B9kAVNuKkHdFOAFAC+4+SxCbjir0b1iuWyWDDLOLWK9144Wmt2eFQN29cCu5VSmw7VMPPqWq31lwD83aFevDpvnVvgUAAWJ5IkL8IPQBspGhx1EzF+fvFn8LUL3ikAywIl/iyDprUMsAiu6pEh8041NCaSKWwY5mSr4DDxKgeyo4/GU152Lo75iwdCB76QaMlQC4RYbKVY1/k4qR5vzVqAqikE+pRj8PIIXhJj6re/w3c/+y/43he/guOGR7Dt6utwp9vdDrt37EToByIe2okjaM9BXlAIhVtFPpf1ZmkjIEoOlhDe1cyNhCL6UAyRr54HywIsvoUmPNjnivHdJsDyM6pQpHBYDieLkTZraKkMJ97zFDzuXe9AsnEYmd9EjQCrkwGBCfl3aRe3KAjdkxVluNRIDKsKYK3Zd+IgDfuyUuqxh9r4+QKspwO46FAvXp23zi2wDwfLktxt1XimeAM6ZnaNmXg6OkGd8gTdDDd9/Ru46JyXYEOcigudezvlmGw76udwesoKIcBeHTCGNEqlLA5Wk36xAO1APchJuJk4MjmPexGcIQ9ZFCFrR9hYG0I3c7A7CBAcf1spAovjjzOCYJ6S58rzHL7LMGHpKK83tkBuT/vRPK1YcsZ563ycVY+3fwvYcWCJ5XImA3KlN2O2lIodP/b9zXLEOkLgO0j/cAO++sF/whVf+To2M6OwG6Ppu+i2O/AcUchEGIZIM43c1aJjJXpwJYDFy1sulgVYVGyfa8iuJsBim22IMOnpXxkyvs/kHPlpSvswdJjVfOx1FCYChX982xux6QGnIRsbQUtrjLSJUEPjjco0srpCV+cISe6X/jBMNNMzhWq+7Zd5rcLVy7DKFniGUurjh9qGeXWt1ppq7lR1r47KAsYCc03epfW/VyGCWjucplzjIk+npuFu24lXP/yROBYK8XSLBehFvqCbxBKG4K7X7nzd3IA1IYdTU6tgz7OG2jJvgvfb0yZEaP4cebnwOGQyFYIsp1QPkedhZ5rh1Ec8DH97zguBo44AGj66UGhnMZpoICzCBFlKYjFXJ/I+ssIdIGsa4qJumwcHhGTMbhJDcKc8r7e4GrjrxgLiGsqE6ENKD5MpDIgxfhJTVlzKKsinHF8SqSeZnWNGsi9SoNMGPB+4ZRu+9M4LcPnXv4mj6w3k09MIHAWlrRp7LuPahAENx4pjfoYw5xwOqdUSEj1YP9v3l+1LHM41fFbaLZf3WiGjSAPyOEItqGM61+iOjGDjKSfh9He+Gdi6GdoLBDSV9f7KBbOt385ysIoe6W+Qqnf3YN201v5+Z6XUbw+1UfPuXq31tQBud6g3qM6rLGAtQI8Nwws8yEPyd0/gzY98NGo7diCMyc1ixg4QpzFUGCBWLJVqPF9e1gdYGUm23Dk7ObzMZDGt1tHfmc5eaEyIhOwLd3gEN7dbeNjTn4rTnvts5H6OfHRMQBY5HkRQksBF01ivQhKBxiDHRYrtygM6sACr+MC4s+b9Fq+Wtar7LqkFZKxkJlXNlrQpABZZVeT8CMDiQOQ5xXuSRjk8C7J0BExPAbv24MsXvAc/+c9v47iRUUS7x+Fwo+MZaEAvleFQmffQKUJcttzNkj7XCl2sDLBS5cpmjs9nPU6OpthMKmx11/XRcTyM12p41jvOwxGPeAgm0wjDtaHq9Vuh/loDt7lOKXX7+bRj3lOz1vpCAM+az02qcw9fCxgpAjPM+N/8R5Aln7e6uPjMZ+HGy36AjY4PL0tlx9zNIiDwJAMp126RMs3Jj2sFd9PGW0QOk5uvLsCyPcs22cNmVNFz4AV13LRrJ4aPPhqToYuHsZTO6U8SLxa9UvCbsoCJeo6tAUc3Q5GtZeWJjOb7HN66eb/Bh+9YXG9PLp7cgjY9o8SNiM8R4JP/pBB1O2iEdQFYnamWZK96dR/xxCQCjp8dO/DR174R1/z4J9jqhuhs344tzSbyjNxIDcqRiG5TAbBEwqAAWBZ4DaptZYMk3mazkSPJnQe9dg4y1BwHrW4HmeuiW6/jmNPuhSe/+wJgbFiUtwPXqwDWoHb+/Nv9EaXUs+fztXlPz1rrxwP4wnxuUp17+Fogy7KiJAwTCY32EwGWgK5OhO+dfwH++6JP4gjXh9+NZGcdZRHSwEWaZ/C0XwgUFmEOqqcXYIaFWhU9QKt8mDR0A/hmpqw76HZiDLOsCDksWzZjWxrh+a99JY576EOEi9VhCR2vgdACrChlDEfSvMvgqheCsCFZCiNWpRVWuedX9/bsfwIs+lxCCRcWIJ3Nop4twVGxuUk6LQSOC9cLpB5o0unAD2vQv/gN3vfa12LX9TdhKNfwplsYUi66UxMYHWoiyuOCAN4HWLy8BVj2XVxdSyz87gSIRgDVxNqtXIM8o9aU60Y7jdEmP23DGM46/63YeO97IyWhf7jyXi3c8gP5zScopf5lPi1fCMCiTMP1AIbnc6Pq3MPTAgRVZQ+WzRIUD1anixsu+X+4+A3nYUM3RdCN4LoaCVIkgQOCs1oemGoTRVaS4V6RC2L4WuQ5reYhujkMnxRlQvocLJOyTo2h4Q0bMdHpYke7g9HjjsYeneBVb30LaqfdE9rXyGoNo/xMwrs2tdnoIOimOWqeY6KAJkZoDoIryXoyXJt5v8SrabDq3ktmgTk9WNaRanJEJJSeWR2mLEZAuRDHA1ot7Ljy5/js+e9C95ZtmN4+jg1hgHqmodIUw7UaWp1pCVObOn2FMKZwlPok9l519yV7qpW7kGyMik2RyK2wgLMyzyuvmQiFpUCjhh1uhhMf8iA88e3nAUEArTxolxmVK9fe6k6raoEpAMcrpXbPpxULmpu11p8D8MT53Kg69/C1QDk0aK1gAFYH0U9/hvee81J4f9iJepbA0SlyHwKwCM7qKUOHxnXPxYJkck7qIaknJN/CW9ZSGwfvNbPw9HbyNqNKeCqUxQkxOTmJxsgY2nmOiTRGuGFMVJ+f/qpzMfqX95dwaBYlcL0Q2vPRSVN4ntfjsIv3yla9KhZOIRdXAOvg3bPOz+AboOR/tspy8cAF+bybJxJybwYhAvKJpqdFr+naSy/DZ9/7QXRu2oahDBj2ffhZju7UFJpBgJGhBnbu2S2hxPULsIw3XLIFBVXRS2fI7paY7ygPe5Ai2jqKc953AcZOPRnapVc9QJ5pOCLZXh2HgQU+r5R60nyfc0GjQ2tNcEWQVR2VBQ7JAmUulqwFBFhUcN+xAxe+6MXY86NfYIPOkaXkXzmIfbp/cjQSX1KmyYigeF+Hv4CfGw9WqlYfYPXWNoYuS2FCAqNAuZiebmNsbEw4V5NRF6pWw0Sng6NP+mM87HnPwlH3v4/UMsuVQuoH6KYaNc8XT4HNUhQjF2+rzdoyyvnVFvqQBuB6PEmQfTEubEZf6TltvgSJ2t3WBIYCD5ju4v8++c/45ic+DWfvNEbCUMaY7kbI4ghbxjYi7raxfddOHHn0bTDd7cjGxsosSJadZBJy5FFEtM89HDwTGz6nSJ8UHix6pCkRI9pYBFu1AONK4+S/ezge/fpXIRexZIWaqpvkmur1G7xuX1iLn6SU+vx8v7pQgDUC4A8AxuZ7w+r8w88C+9OiUpQiiCP889kvwQ3f+D62koTbnYYTKnTdDCrLMZwEsgBwsiPAavum7AQBlpczm9AzhPdVOrjY8DBq1f3Crr3SIZlG6PmIUiq8pwibQ2gRZHkeppVCcMxReMGb34DaqXeXmETq+0jIR4PLEociXSEArlfKw+As83ElVLpK3b42blsCWByGdHLyXz+pVgNZDDeJjTTDTbfi6//0Ufzk37+BxlQXjVyh0+mgHvjQaQbhNBacLT9wkeSZjGvDS5K03SLLjkOVo9AWah5UkNXXp5JXV95l85x8wyLXwW6l0fyj4/Gi97wdwZ1uj9hzJTO4oQLkaeXBWhsvwrK3Yi+A2yqlJud7pwUvTVrriwH8w3xvuN7OX04hy/Vmq/LziAeL9c6SLn795Uvw1be8F83JFnwnQ5R3BVnkcYKR2ACs1JkJsJqx8WBlLvWyFm6pxfSfcDQklkBh1KIkSG9Hb8izbrFgiVhhUZPN/kyZMal8NI49Ck940fNwm4f+BV17yMIAjheg281QCw2UolQDF09ezq8A1sI7fJ19k/Xu7CG6VMU4IY8x5LhsTaHmh9j9vR/ikgsvwnU/+BHGNDBE3ac4gnKNnpWROpkJlGScOq4Z4sVGgjpYJpGjAFgH8WIttpTVcnYXcwcJKllTkUR2nSuMNkewZ3wvavUhtL0A18TTeMUH34OjH3gaMFxH5gVIcmYvOwa0VsfhYIFPKaVOX8iDLnhp0lpTLv6LC7npevrOYhbo9WSH+T6LACzW6dApdv3wx7joRa9Ebe8kELXMEhE6Unoj7GZS7896sGyIcO0ALCOdQIBlSbMzQnglgFVeCE0JWAeOG+DmiQkccdJd8Kgzn47jH/1IySJk8Wh/ZBhRnMML+irY9oUl7GLBXY9ZYdVxWFqAmCjKc1FY53iIo0jGYBj4prhwnAJRjKu+9FVcevFnsPvXV2OL62HE85BnBFdAlPUlT2ZsgIpftGNdqH1y+0yAZbxc+zvWMsASbmMcI6j5aHPOcT3oTopmnV7mDJ1aDVvueQqe+sqXwDvxjxDnKfxABFXkIAfLdRe8hB6WY3ZAH/pxSimWCZz3seDRobVuALgBwCEXPpx36wbgCxXAWlgnCcCSHXMKbNuFf3rOOZj85W/hdafgUq3d1fCUAz82u8XMMST3pMgirKWFB8vxF0VyX0z/yUJTpBz1AZYRZZQJWETZ91VBtR8xJJGlQDA0hD1JAmfLBjz86U/DXR/7t8BQA9pVUEEd7W5HwhFDTb5yQJZn4rVznaKu2cK6oPrWgFuAI4uezYnpCQzXa6ixBFWUFI4oDdy8Hf/63g/ghqt+hs71N2FUKSm0nrTbMkZFC0uzHDOPfqi7bBZVBKONAGeRWSfhtAJkMEdxgAFWmGtEmcla9us1tCdbIsGw6TbH4Pp2G89+x5txzF/9BdAIEWcaAUtd8aD6e5bCd1c3i3nAh/AgNH8cwHFKqfZCGrtggMWbaa0/BuAZC7nxevnOYhbo9WKDhTyHsVuOnByRTOO77/gg/usTnxS07qYJMp3CyTMEhbgmswjpxUqZmgcgzIoaYTaEsZBGFGT7A331QDtwGyJkuMQCLAFWksFlpBtYxqQcerGLlNHecRCGdewc343RTZsxjRyToYeH/P0TcdrpTwG2bETSieAPNYuaOKbOGUVIGV7k0kgRi0W9xAu0W/W11bWAZOYW+mss5yIlpFodqG4XCBto/eBH+OS73oedv/k9wijBWOBLDVDqX0lyhKcQp4nRW5MB1A932S0BNwAc/2VZhtl4Q8LmAAAgAElEQVT7hayX3jq3Pda6ByvQDuI0Qhq60L4Lral7lcMd3YDjT70HHveWNwKbNiLRGl5oRI11kkMVXuXq3Vvd92AF7n6RUuqZC73PosaH1vpvAXxloTdfD9+rANbCerEHsFgMJ9OYuuxynPfs5+EIloOJOnCVlhBYX+XJcEUsrZv8K7ORLDgiC2uGZDMuFGDJ/XPWL+uXyekBLEvPKgEsQ3wvhA2Lm3K3zDBfGsXo5BnckVFMhy5OOO3P8ZRzXgwce4ypo5MU7QxCwHWRsqSQzlGXYrLVcbhZwITYmf3XhQp8gMCKvqjde/H9T/0zvv3ZL8KbmMLRoxswMb4LaZ7Cq4XIdQqXnmGHSRQJcscANTMyZx7cADhFiNsCK+ut6r01LNVzgGMtAyypDJGk8Gg/z8VU1AHqNXhjw9ipNd7ysYuAu95FXu52DtSbgdhcaoaSCClHxcNa5+/eo5VSX13oMy5qbtZakwByI4CtC23AoH9vsQv0oD//Qtvf34FreO02MD6JC04/A/H1N6IRxwhdCo0mvew5m63XrztYACwSSRZxLLb/uOOVaXYWTrNZhZqFeIVEbNorddwKkCVgjOravid8s1Y3kpBP13OQjTZxxIl3wtNfcjZ8gqyNm4QjIoR6lkEhObkguy/qJV6E7aqvro4FerpyLPSsXa74wrXa9sMf4msf/yRu/fmvsDnLgelWIfORQ9UDZJ6DbhwhY2arcosxa6RFyAfscwcNqd1kq84cXXZcW6CldHbAWqBrGWCx9xRrEGYZhuo17O200Kl52IUMj3nBc3Hac84C3EC09lgTVIo40yaCqXJkeQLXIdKqQNbqvAnLftcdAI5VSklVs4Uci56btdYfBvCchdx8PXxnsQv0erDBQp7BAqyEU3u7Bb+b4dJ3vgeXfeYLGNMs4pyC/FoWfJbqMIWCtFCwSsKenCAXcyy2//JiVSrzU0x7DMOMc6+p4WZrJxYyC7kpnhsVRXR5qibPamhIQqG7JicQ12qoHXMUHvHM03G3x/4dUAvRiSO4QR2+58tOWor2Vse6tUC5EoJ9SI5Zfu5Rlb2TApMt/OhfvoT//Py/wGW4mZ7e9hRCTwmgCuuUGNXo0lvjBlIih4NTvDcFQDL6T0VSrAxGExrs+0eNp8uWkilKEcLNBhdg8XlcP0S32xWh1XaeYrruoXGn4/GPn7xIFNtRH4NWAahSwYzNlJnBLoFnCs0qFVTFrwDWen3//kkpddZiHm4pANYjAPzbYhoxyN9d7AI9yM++mLaXPVhOHMGJU+y89DJc+OJXYDNFRduT8H0XsU4MwCq8RP0aaCYst9gA2WL7rwywBE+VPFkEUNzB9zgt8ncrbGgAluMHmOq2ETZCqFwjiVKp1cgUL10LsEfnSEaHcdcH3w8PP/2pGL7TnUXKIW5HCEZGza6a99lfZ8yOgM4+8cAR0gNceDG9v3a+u7/HX9DEeABbz3WfAoIbYxQyCAU2742ZRHQYcpH7kLHDQuCMK/NnkuGa/7oUl3zsk7jlV7/FMUPDcKemoDstNOoBkiwWjpXDkHKaipZVza+hEyWIkxSNeh1unBr+1iyAZcexyR00rZ8NsCTkna8uwNondDmr4/oe79ljzniA0zRDs9kUPbCWkyPaPIyz3/MOjJx6MtAYItsTWeoIqOJBgJnlGk6eFJubQjtr7QzpqiVLZ4G/UUp9bTGXW9A8Ur6h1jIzMEx41GIaUn338LRAniWg4KjiDLZ9HO9+zD+gvnsKe8a3YcOGJmIr2yDgRIE6PFw1CFMEYMkIHiyhw14WYammGxWxLTnejATDiVFeIIKH42mC259ydzz2mWdg7OS7m230yJBkFOZhAI/nF6u4LIrMcKRtSJGxTi7uwFlrzuWiW5DjZypTGkBlZ4Xy7LDomWLtjW+ay9ZHtiayjzn79znHGMei/QIvNhfAKsJKDMLRF1tOSWAPa53BYYfIuDZCVswe5ULOcHFBgYLKY4RJaj6IYuz+0RX4wb//B674+jfRoCeKXD7qM2ktYWjb3rLSOhNFenzBnq5V/92ZKxvQhOaLrNjiWcuhxP0DmKXp7wNtgKTETdEYqbkoNROLDYdodQH1MEQSxciTXDYuErKnB5C5IlAIHA/tKEY60sCtiHGvJz4aj37NK0TJN3YDuIppNsZuvaP3LlRCv0vTy2vyKrcU4cFFLS5LMm1qrd8H4AVr0kxVo9auBWRzTi0sznYKmOrgm69+O6685OuoOzny7jQ8j+wQQ6SVSY6cExZ41m4BsEzpnEE8uEB4mdkaZ45G5uTyT+BVsUCQLxMnGZqbN2O828GE5+AxZz4N93zG0w35fbgBVpyNSVjOGEU0Ug5RN0UYeiBNRzATvVzlaCrDQVEm3o0Zh7gKZy4mc64tg2jwWW22z2VHz6zHnnX2XGOs+MZBvIT2zxZgmWXZjNv+BFwoiPcAmcFrjAKqNELIDmQHX3MtvnfJ/8Pl3/wWpm+6GaNZJjUE1+uxEIBl5wpDldKmLJdy4XKsF7E+VSQJhE6AiSRGa7SGoRNPwFlveT1w5GZ4GzYillLqhGGGOznDFV3005IsoOu18wb7ud6vlHrhYh9hScaH1vpBAL612MZU3z8MLdDLQtJMi8Oe//wu3v+yV2GTBtrjt6IeMgiYyQTH/T/5SRL3oC+AIKQgnA6i5QiinLwoelMALOtxsABLZUCjOYzte/eIwnvjNrfB9Xt3Y8vtbosnPP/ZOOEvH4goiRDWGoAbSuiIfHrFbMPSYs2oEsm5nl0o7Jos6Itf6HuubF7YTNzAfhBpVMMusyGtJZlBVqn3rC3KMdxyU+bw4JVBmZEvMF+wGa7lnDpTcKVwcpUxUMnW9K6wLI1WVH+DqITHcQzPcdHwfUNgJ8rasRO/+Po38O+f+ywmb7wJm8M68k4HLNlpM2pXyYrLetuDASyb5Wg9V31wZbJ1xWPruchcEwilm1i8fZmSKKv2fUShj3FX46XvfhtG73cv0bya7HZQa44IwJI+nNV/1os3yMN/WTtu8C/+YKXU/yz2MZZsfGitrwRw98U2qPr+4WUBbXfxLPzM1WnXHnzkH8/F+I+vwnCWQuURXKaW062vlITLmNXjFvIIgw6wVOGJy5VGplh8VrbdAigFVCYanufBC2si4zDejRAFHtzhYcl4Oukv7o+HPv6x2HTiiRI6AsVIHRdJliBzXXhuKHpZRtCCgI6reBGWkg8YVjGrx2yPDj8rh8oEUNjh2UNfpTDZoA1dQ2+a6ZmQFbp4kNLPsm1mevT6/q85I4QE0bzObCdTIe0hDhVoAVUsMlzzKQXA4ps50O4At2zHNZdfgW99+Uu49qqfYlgpjHg+8m6EoAh3DZrZ59PeQ+VIWsDDJBiam+FSCQEz45bZkypHknIecRDCRT1zRPmk5XvY4wIPfPyj8eCzXwSMDUmx+U6SwA8bUkxdxv0cAMsGCJdsEZ2PYapzl9MCP1FKnbwUN1iysaG1fimAdyxFo6prHB4WMByYTFLBFcGB4ACF//34xfjyG9+BOzSGTZgw58TI8BnQ9pjt5MkOVADIAHuwBMBo47mgUCnDgxZgSY20nIDIkexCAUCuh9hViJWSgtCJ56Krc2w47hg8+NGPwMmPejiwZRPSNEIS+lBBDTFBqnLBUIhvuSQMyQoJxUFktPQL71TfkTXD+1JGX2WkIBykAQdY+3vVbPHuWRisvM6a8WsKBnMZZsK+FAyehbRMskOpNHcR1WZfx1RUd8jxyeUdcGjPOAH+cDMmrr4W//G5z+Kan1wFtxNh6/AQOtMTiOldYWYgAYMTruvJ4kAAi/aj588cZlNieGj8abohYgF1ZlM6SjiOPjzU4SJMgAgOblE5tv7JXfG8t58HHL0VaNYkOcCpNcWb6DvGg9Ub9oX30XoqZ2w61nVPHFYPd65S6vyleOKlBFgnAPhNX3J6KZpXXWM9W4ATIIvSysLPMAj3nm4mJXPee/pzMbJ7CmHUQUASPFIplUOAlSkPwToDWORgmQXDrL4EWKKZlQDNsCYk3W4cQ4UhlUnRTlPEOQnrDvIgwO4sxtYTb4+/OeMfcMe/eIBwszTjjG6tgAAsrq3hKk8yG7n6MBsqcV1TRFrCWbmwTvhTgIKEAgsPT9mrI220vq3Bl4kw/r2ZuGg2kJrrPew7v2g32q8gQ88CWMW+oVdUuShiIKbtJhEadd9kBiY5sG0HdlzxE3znK1/F5f/539gUBBirh+KdTOI26vU6HE8hIeeO3SjM9MHvg/3NcwcDWPTSykaFYKgg+hNc2f6MSVZ3tGxGyDfkuNZJCj/W6Loepo/Ygn942dk4/qF/BQQutSugG/T6+qwzYeamCmCt52Vo9rNxv3lnpdQ1S/HQSwawZJOr9RcAPH4pGlZdY/1bQHaYBcByubiwlBoShHGCb7zufFz5ha9iY5yglmbInRScLCVEqBzxYA06B2tfD1YfYJExIlwRreArB+3pjiymQyPDosUTpQnqzSG0Wi2owBPg1UpTTLvAsSfdFQ9+3GNw+wffH6j5pq6hchHpHDrTqHlGkZrLUEY5CMsVKofMysDKruGO8XalFFksFh76TxanRLZ649x4oEqepVlNsZNjL0xaBk5zxAOFB1S6noBWegoFORcXl5Xf5BSKSCclOdoRutdeh59f+l1c9Z/fwrZf/gb1OMGGRk3W/D17xgVUuYGPTrcrZG0CrW6XXK2epPjqGXIZ73wggCWSCa6px0nPlc2kNFm6xuNNr2/EeoskubOIepYjot28ANnYCP7s8Y/DA595BrBxA5DHTDtEO00Q+HWkeY5QvIv7Etz5DvAQUL2Mz19desUt8C9KqScs1V2XdGxorQmuCLKqo7LAQS1gQyzide/GcMIAE1kbo56P7d/4Lt7/gnNwdCtFLU2RuhliNxeSuwgEFkqHznLniR/0KRZ3gkmDJ9Ahx4zK7mbiZsiIYVHutkPPR+AEyLNMSLtGzoF8doaXXPFIJWmO3HGQuA6mkCPYuglb73gHPPypT8IRd7ojcOxRhuVO9wlJQRRIlLXfLNC9RcS6ZcqAoABYbCqlAwiyrPoDAdaglrudTcEykLN/zAj/WJfWbNeWdX/JYm7sY00nHkFmq4lNGZYtfpJfJb9nmPzNr3HFdy7DFd/4FvZedz1GkhQjtGmWi9ZS7moJQ1KFndmiAsq5rGsHuXh91/dxqAArpOiueK5MBzHcbt4TowHmKU8057pZhg40aps3onbM0XjO+e8Abnc8VX7FM5yws6QOjkKuqXhfxHatmYsQYQWw1u24e4JS6l+W6umWGmBxrr2W+hFL1cDqOuvXAmWApeMMru8gUorSflC37sKFzzsH8RW/QJ06Ng0H090WGkEoejZ7p1uieq6pozXbmzAgJjOZgmbRlN12sTCY5psUfhsq7D+jOd+U3zFcE/l+ATylILZSQu5NlSeLyV1PPRWnPeKhOOLepwJHbhINiMx3pAxITg6YOA8VXKdQabIga1bkyTpiyg4Z8V4V9RzLZVFYfoS/28/Kf7OLJn+KqOpqHnbsaC0lU9ge8SqVnsuAoVmSDOWZ017DSlmpDMwG5dpsuGwUB02BTmRQWKuLvf97Bb7/X/+NH112GfyMIasUfhojTDU8LvYMULmQsLjVd+Ki72fkHzrwiiQP1hIsa12tpilX+t70YKWOI6F0Fn/3JNbNTRiQcDMmWbOuyJEM+w0p2Lw7jhEP1zE1FOANF34AtZP+FPB8wGUJKlPjk9nKFlzPkGfgA1YcrJXu5pW8H/U8b6+U4gu4JMeSAiwzJ+m3AXjZkrSuusi6toABWORXmVwdrutdUDQxRZgCP7n4c/jPt70XY2mOVt5CnVyUViSeG7fREB5Kua7foBmrDLBsmZJeRh8X6OKBCLLs3F5W/OYiYP/W/1w+lUWC6tzN0THcuHsX9uYZjr3bXXCvRz4Uf/KA+8I/7igg9AG/Bu34YtNUBF8dKcMjTDC5L/0lhY5WD4wULixCQopiFlIbFiyVgZMFU2sSYNGDFydQlEPoGZgRPAqAGk6caCeVQJgkB/AfQZhRue0fMi2L9oYxUNJFniZwPFMvMP39tfi//7oUV33ne9h59R+QTExirNGARzAq5OzUhA25yBMEe2QeMrvULPf0WnkCsJT85NinZ/dwBVjsHwIsmpsAixmE5DCmpBJ4pr4iQ+xh7kK1M6SOD7V5FDfnXTz6nOfh5Mc8ChgeRe66Aq6YxWn4iBXAGrS5dIna+3al1MuX6FrlKWXpLqm1PhXAj5buitWV1rMFKNMQ5yk8h3XDyS1ixmCKkAvbH27CR55zNsZ/9Rt4PvkQQNBJEXXaGNq6BRNTkwhdb114sLjzlpCVDf+VOt0Q32dggN7vNkJlMg4hRF8rY0kv1mTUhTc8hNQPMRFHaKUJth59JO5179Nw53vdE1vvfjeoI7cCJM9zYYq7ktbueLVC3tWkqQvPxWIHG1szzPgZHGtbJ088QSwTVHi3BL8UsuRzfbYqY1y4NSKw1gdLUvjYiIdYqzNEx/8xn8wuvmxvmqfII416LRRQFHcjAUuO7xlR0E4H2L4Lv/3Ot3HFt7+D7dddj6nxncjjGIHnoeF58NuJlJshSDL9r6UGp4A3ZbSahGuoTVhQ5cVP0YLLoR2S3WdrQKyKNVf8pkZ7zHiwyMHihoWhQXr9InYBAD9VcFLA6Wo4jSGMBwp3fsh98dh3nQeELnLlmQ2GGaCyMTFvkNmmsHqEHPZFk/P25dqt+MNXN1wOC/y5UurypbzwknuwZCxq/R0A91vKhlbXWp8W4FKWpBlczzdzWCZV0ShfDdWN8OOPfApffO8HsGWohnjnOI6oN9Ftt6DqNUQMrRTlPwbVOoaDZbgj1lFiQRY/NxIOxRxPr1apdEkx18sfuXsX7SwbMhR9KwfKD5BSLwkOUtY1TDKRfaBsQ9oIsfnuJ+H4U07CKfe5N0bueAIwQsFSxlaAiF4tRRVsyi16hcyDCDf19aMMXWXGId6fOYDVXF6s8mer0odChcqQZKmQoJXYqv943TxCWBDJ+Zckj8XbF3iUvXANwZ9fYBYgDcGfN96AX33/h7j6ip+IdlW6dxJOtwOVpcjyWBT1Xd+Hw6xOSjNklOhgfxl+nA2tkj4t74MALHLmjCeLfcm6gmbgkPV1eAIsYwBH7ENPrqmVaEKDBFkCkxJmzroI/CGMd7vYctJdcMbrXwH/lLugm1PktSkgzdYMtaWMTCSwBLDKg3NWzsKqjNvqpkttge8qpe6/1BddLoDFCtQfWurGVtdbnxawVdoYaRJOkUu6Sgt1clCuux7vP/eV2PuLX6PZjrC11kSep5hKuvBqoZS3H1QOVrk3y/UJzZrNRbTYKRderX6+m1Gptno/AsTIOyH2kXI7/SU3ZwgsJ6/NR+D7AgooNColeOgxDALsTSI4zQZOOOku+NP7nYYT73kK/DvcDhhpGk8KQ1zkeNGzU6BABg6FXJ8YorUNCzKkVvZUlUOEs8GUKWGyLFPQIb0oFkilRYiTemHWcrGOhJNV92oCftlKryxwRUOksbHN5JSE/K7/6a9wzeVX4saf/wKdbbvgRwkCJiJAw/dYO5Nh2Fy4hhzz7c40GmGz39bCE0WQTG8ZPZIEYQRWxAsEzJI5Jxw7MzaERH+YAqyZIXZDarelpgReaQdZqhEMDWOCw3TTGM583aux8YH3RZJ1RMqkgMhmDJe8V1LWiMB2fzmyqzdsD2lsVyfN2wLPVUp9eN7fOsgXlmWYaK2PAHA1AJYjr47KAvu1ABcxLsriveL/UfnSJwbowg9Y2LaD733y07jkTRfgdn4dTjeC77s9gMVSMoMMsHolN2QXbv6ZQ/x4xa7cAKjZgEx0sorzuWNPGR5xGcwyXBR+pUYZBu7iU+P9EqVr/nRd8RrGJHcLevARKWAij+EMNXHsiXfEcXc9Efd56F8iGBsFNm0ARoaNsChxSJoLadgPatBaCRihZ4ehQQuyyp6sMuF9rbwONB2FWEUfSWAKywyl8gyGlVXwreIIyBiHohdJAa1ptG65FePbt+OH3/5vbLv+D9h5/U1Qkx004gxeNxbSeggHgesgo1Cub8jzUdxBkmXwAl9Cibw/+9qEAQ2gMuPAeGbKh2SZ9oqCm78M8thf7DiQWp45NyI5EtLc5B0x4z6QecEBWZpxEOCWPMXpLz8Xf/zkxxnuYS0o+FbGyPQWlqOAvY1BBbAW202D8P1pAHdQSm1f6sYuC8CSqUnrjwF4xlI3uLre+rJAlpjQDCkrkrxFgCWlBnNolxT4DpKrr8Onn3Mu8qtvRN5pC8BqZTG8MBDvzKAuMobYbsI7XFAJfmYvrMIFKjxSNnPQLAjG12I9GTQCpR1MqkA/Xd33fUlTJ/hRlGagMGkBiKwHKY0Tw++hGCMzqchlocfK99FxHBxxu+Nxx5P/FCf8yd2w9YTjUb/NFmBsDKjXkKYZnFpNQAnvIfcpsgfn8l6tpsdqrjeHnjzXZUdopBRypTwGs8oSZv11AS8wyup79mLqmmtx9c9+id//8le49cab0N27B2FnGlm3BdrQUw5chmWhha3le56Iu05PT8qiLyKhhZ1omzjP4LBmpIR4TY08Kz9CpTEJGzKJoBChtdIdlO+wYJwkb/b64XiIBzczmLdNrVbXeHYJrhoJQauDNsWMN4zgmPveE3/35tcBjTpi30UQ1mVTIH0/lwfQhritUrytvTnb0Mu2gh6OPbpqz3yRUuqZy3H3ZRseWuuHAfj6cjS6uuY6skCxS++0u6jXa725jiGU1I2RqxS1LMPlb/0AvvXRT2LYcVBXGp1ORxasJCZBeP/2mO0FsGce6DsrZd25ABYXBSPP0PdaGU8WS31YTojZaxNKcefOZ2GoiAuvqcVmFhqCVNZfs2E+5fmGhyVoVomGVk5Va8cVcCDJyUL6LnF9fB9daEznGTos6zI6JIDrDnc9EVtudzvc9T73Qm3DJmBkhCl3htxdpLIL81vQIPUK5KkK8vb8LGw9C7McOvtcZN9hYItSlzhK5YvwY5ZoIrK32lT8b+FR3Yjt116HX//kZ9hxww246bfXYHLHDrgUaiWBnx7BqIt6GqPOFH+GS6lXRRHRgkfF/hUelVIIXG4iMnQLodAwDEVnKeJ9URQg1twsGLCUUuqBFKIewCrClKJYTs0nYxUTNhxcgFX24JY7tDz+Z3d0OZxOgEUg2vFzCZETdAWZg0YixXOwO8+w9ZSTcPr7zwe2bgSGh5mnjKyTIgy9YqwaL2I5BN8jPtoxXAGs+b20g3X2w5VS/74cTV42gMXGaq1ZjfqBy9Hw6prrxQLF4mdruBVcYVOEWJYaZBN7EYzvxQfOfim2//TnODaoQe3eK16CNPAlVduG1KxVLEgxPIryYciwZUL5alpy9gKzf0A4awEovBY287AsV9G7RuEds/CCCvg8ypRouzRbL2A5RCkhqaLItvDBHC7oFCAwdd1o95YGmps24pjjbovbnnB7HHvCCTjytsdi6MgjgNER8893AWbWST8R9NBVV4idygJmWfxMeSh6hl6w4nMzJCi4acjz4iEr/mdy/gx7huPBBFatsGdm9KvIsRI8wvtLjSAgjoFuF7j5VmB8HNtuvAnXXXMtbrzmOvFO7d05jqg1jeF6owCtJoHAtNRYkL8HLFdU/H6wMTVXyK9AoL1woO0HK9th+rffYwJ9xVNZHBQcXcZZ/FCLLS/kHZq5wShCpDbpgyVtZKwZq1qQTTK7jJheN2dIKG3BIueug6TdlY3CSK2JvXGEsRP/CE9/w6uBU/8EOggQwUWaawxRj4y8LHrLRVZj7vdrIc9VfWegLHCpUupBy9XiZXw1BWCdDuCTy9X46rqDbgG7cHDRNcridiblPCshMJatoBs/6uLyf/4svvC283G8W4e3fZdoCHGBJ/+IWVUWbNAqQoAtFkELtmRpZOixRB4fdAsud/sPJLMgmYnibVGCWdgPXMQ8lngZGoLTrGHrscdhaMtGbDn2WGw59hhsOGILGiMjCBt1I2fAEJz8DAGKnzKMyZVP4qGFB0pS9Ui0Ly2Ekslo1LdFy4CeN/KZqG5O8MSwHsN8SYZkegp7xndjfPs27Ni+HTu3bcf4zl2I9+5F+4br4aeJePJ0nAr4kmxMAWsmdDjbPzQboA5qiPpQxs5KASwJjwuSMh5ca3UB1aWG0ktbBlgsITTd7WB0w0ZMTLUkBFtvNLFzYgL+1i0447Uvw5a/ehBAcVFR1K3BzV00bIbDLJmRQ7FJdc66ssDTlFIXL9cTLTfA4vV/AeAuy/UA1XUH2QLGXyEeANH1KZwDhVODa2yUZqhxxUti4Pob8InXvQm3XHElRtsJakUYzZB/i/IxPXMYknDZkyXzd0USnteAORDAon0bYUMyOZNcC2GbIUgJkZHH5LvoJOZ3m/lGQnlYbyCs1+HV6hjeshF+o4aRoVEMjTTRbAyjVg/ge6HIGbBmnGIdPteX37kMZ1kiWZD8GU23kaXURuuiM91Ca3oa0xN70ZqcQtxpozUxiZyFkZMUKjOhU4p5GlJ+Cq9Gra7MjBXKJpBgnpkMMuMX3XeKtF5HtmY9gyt5X0pyG3MNnMVy6iQZQxDUTFK/fZ+zWfc3Hjyj9CaZtL4nbYynuvDCGuD7mHI09vgOnvDC5+JPnvIEIz1C/O16cJzQVIvixoD4fH2XcpzXu34YnvwrAH+s1PK9xcsKsIoX9BwA7zwMO6965INa4OAAS3wWOTWxOuKR2HvZ9/HuV7wGG+IMqtVBWISHrPfKiA+aCVv+30acirZY0U7rhbAT9kGbepiecDCAlbQ6UnCYWXGies5i3AwrkspFPawCpthwIzMORYTUcyWrrkXwI0Rjc74Q5UuLqg1/iddx1ueSRVbUYmTRXZb6IclcRBDoUqNOGonmrNNIAdDC+2FBU6YytJxM6v2Jx0opUf4myJJFfFZ4+WAhwPU4ROks4HYAACAASURBVJYbYBmpUOO5skd5s9RXhzN/ldI1pTCpALxcoa59dJIEamwUv58cx8Oe9ww86AXPAeoBEITQLA5PbylDj9yYuUCcsvC5DUSvx96rnukgFniJUuqC5bTSSgCsLYUXa+tyPkh17UG0gJ0+uRstebBkBjVzrhQVFpVmlh5Jgalp/Osb3oQrvvk/GKNOUZohyFNT/Fg8VPvyjOayDM8r74QH0Xor0eaDKbHTgyBehiKD0Eoz9DgyrK1HxXK/AGA5pMQRs0fpRaI3y4IrA8iM4rsFYfwbQRfJ4zPK7hSlauI0EZ6OQ66VEslIyIZUiiznvUw+w8UzGY4ETryWiKjWQxH4JCATUMaxRkmGAswRwNmjLOot7Vr22XMlevjA91hugDUXL81ys4QxUJQssuOpD7DMFiqJUjSFJ+cidX3c2Gnhzx/3SDzspc8HjtqCKKBKu4M6yVaSNZBKskge+DK3sH7EYdCNqz+Q1l4LdhTeq53L2bQVGVta6/MAvGI5H6S69uBZgJRmw6o5MMAy6emcTROAnqxr/oDXvOCFSG/djq25Rj2jmrU5OJnahbBP7p7LNhXAOpQRc0AOlmGWGyI8+S2SMGiy5ugRohtLvFoEX8Izz6SyIR1WDPkxe5FgS0BPoWUvwKeovdgDXnPMUoZ8D5E5IPjivaw8hEesJeT5HHHXKJ27cg+e40pI0IwVk8XHMWPDgSK14Dg9zxhDi2UvmrSpZLj1DrKWG2BZwDTbA209zX09qpI3uugA2UrlCrWwge3je5APDeG297wHnvL6VwJ3PA4dTyH36jLD1ISPqaEZKmZiTEGgD3qpFIfyNlTnrCMLvFUp9crlfp6VAlh3BvAzIyFZHZUFjAUswDIJ1QXJ3aKigofFrLVUiMdMTc8ALpiei29d+FF86zOfw4Y9ezFMQvPsQ2rKmRRuc6+ZVGWbDj/IxaJXYhwdzINFHpMAKxbdLf7x9ywnTyqTz8x62M/SopinAK7CS8QC0+IpKhVPFs8Fy9bYrEGpE1f0ZVGKh3/z/VDAnfWc8QyRDJXPMoQhF9hCG4z8sEz06M35OVCrNUQaQQAiwZYlzHMx1sb7Zo/KgzXHa7ZIJX7qfvU8VoUu3Aw5DsuPK9TsZ7RAOwj9GvZ028hHhuEffST+8fx3AMcfDWwYFY9WJBQCZZIFi9KZhkTPUDSBd79/V+J9qu6xJizABeMkpdRvlrs1KwKwZIHT+iMAzlzuB6quPzgWMIk8Rco7pz+bRWhzsqUsiEkMC5hExs+ZKdbuijfr3c97IVo/vgqjUVQitJssI/FP9MKGfc9Wn85oSfDlnLDBsd1KtfRgHCx6oQiyBJcwROd4EqIzYIShPcKdrAemCJpmq7qXSePWEyYeKJ7LaF3Bv2Io0sI0eqTkMPiuF1YkoCvmm6Jd/f7VIsYq4lQiqEqvWRql4lUTHTB6ueYoSN0DWMV/lD1ay0ePXakePvB9ltuDZWtxssSNCfH3+0sSVCjGKpw443E2Y8X0MfW/WImgS8Hho7birDe+BqP3OAUg2T0IEOdKeHk2YZA/GfCVpJqeyGgFsNbGSFvRVnxUKfWslbjjSgKs0wBcthIPVd1jMCywX4Blm6+AmGRjhny4XJO0zDR+FiHeswfd627A+5/7fLg7dknRZ09EGDXCwEOnNS3eB1MAtsgw5Nra09kZDBut5VZaJW1LUjZ6TfRImLpwBuSa381v/cLV8ntxzv6e0SrX9zxHVG4oFllbWoYeENun5WuWQZu9PtvHc207ZakuFm57zlw6ZLNDhIeTTMN8xt8Mjtwhf9GCJbMh6nkb6dXWkFqQ05NTqAd1kwDB0ph+iG4cwRlqYFvUhXfkVpzxqnNx7F892NTLDGsgayDwA3M5qVFo+JwGnrE+JAcj/1iIjR5ye6sT14EF7quU+t5KPMeKASwZz1r/K4BHr8SDVfdY+xY4IMCyDorip3FeZfBd8nscaBYx3rUbl3/yYnzz4s/ATRKMBiG6u/dgiOVHdAav4FmUQVYvNFjEIdY7h2Y5R8HsmnllW4ozsuSNKAOuGYrZPeg1l9DjTAHIPjAyn/P+trSMCfuYo9+OPuCbLSRppTotB2i2nWYo6RdjsAysLPirslD7llsowDL8q0KfrpBtkKoE1Ljrpti6YQu2b98uCRG1oSbGpybhhjXsRYZ860Y89gXPwR//zcOAoTqyoIYMLnSUwQdlGYjKjdPLlpWiB8ukLhQAazlfkuraa80CX1FKPWalGrXSAOtRAL66Ug9X3WftW8AuijIQZ5AvzM6TESBDVzZkaoZ1CJwkNEPu1fU34NOvez1+d+VPUUsyjCqFeHIKG4eHkXQ7Eq4SiYBCuLSvXF6Ekg6TbLDlGAkmBCvU8bkvLyG5wmsgYd9COLT4yYXOSCHMBFIzAViJuzXr+/amFJmdq7SKADx6LIufswGacP9mj7nCy9YPR+1bqa6svl8BrMUBLMuNtACL1pbcCWqCapJ26Y1uo9EYQuY62NvtwqFIbaOBPZ7GX575NNznGacDoYcojeGGTak04GYcE0xsKB0mk0H4VwUUL9hZy/F2VNdcoxb4W6XUJSvVthUFWLKGav0dAPdbqQes7rO2LWDpVtLK8mJn1daZIFYQ3osfRaxJwyXxJ46x57uX4d1vfDOwdxLNboox8oLabVMzWgCW3R33bWE9WTZ7aW1baW22jqHX3GEtPLbP+JDIceppjwl4Yv1E035xJMwCNLbMzHye0I6ZPnl+7m9LlmGppuN+ztrn49nhxdksPeu94hcrgLU4gGVLXNl31IJuEXzlu5/kCIIatOsacDUyhPG4C29kBI985hk4+cmPAzaNIOLfAh+OFyDOMgRuKPOEeKost9NOIEIZsBnMc0nJzmc0VucOkAW+q5S6/0q2dzUA1jMAfGwlH7K612BawK7FNm3fERFJ8lOpWwT4zGCjq6HTwvc+9Vlc8rFPoNmKMJxmqGcabhLDdVk3jwCrIL0Xi64lypaqug2mkVax1fuGXim30Rd4tYCqXA+yDL74fVPmaP8PsT9O1EwQ1/9++fxDAVjlOn+z2zEXj4t3sv42AY1zeMBWsUtW9dYLCRHa/mL4zkq28CGs2GsaZxgZ3YAdk1PAUAMt38Okp/GIJz0JD3jWM4CRIejAN9pnouSSwfONxlWSsQqEb/pICIAW5ferPghAXlWrVTdfQQs8Uyl10Qreb+XHlqaUM3AlgD9dyQet7jV4FrBrF4UkSXAVLSMKiRYTpimxk5hadBMtfOJVr8c1l/0QtalpbGSWWBKb+sLMVWSWUnkm7SlHz5RvGDwrrW6L+8RkE8qbzXGT7K+iiWXww0WPi6rULzzAIxxo8et7xopQ4AIWSwHes+5f8fIWNqbmC7DKSvk2EcWMIesZdKRk0u7pKThDw5h0gelaiEed8VTc99lPl5Nyv4bMdeG7HtIkEnDFo51ECOS/mSNaAGHpaJMx0wvzLuxRq28NngWuAnDycpbFmcskqwLetdZnAfjQ4PVR1eIlt8AMElb/6n2ehP3MgRYxS6cnl8SMoUgnqJHI2o6Bq6/HB1/2WmTbtiO+dTuGfVfUvLVKwTTwfSheArIqgLWYPjU6Yn0OlVXS711zVgmU2fea7SU6VI+QDf2ZhbnvU5r9/T7nbt+nnF0Kx54xH6dUBcZK76zVNTtEbSyTJGG+LxugUhfZzFTux2PHRdZsolX3cP/HPxb3e+4zgUZNdNbc2pCpS5lQbiOHVzMAazpqoRbWhNFlvVT0f9sNQO9Wq7ICLuaNq767QAs8Vyn14QV+d8FfW5XhpbXmW0Av1h8vuOXVF9eHBQ4CsNIshed6xTTZy+KWSiZSWNhz0I07GC3iVTdc8jV86LWvx20bw5jetg3NwJMadKKzU/C6yqGrfop/OX2/DxjmKuWxPgy/+KfoE9RnktRn6FoVtykDr3KIbXYr5guwUgLn0iw2ewHdH+DifaVYcAlNzeR2zW0fm61ofx7uAKtM+KcHS8ZECWAxAWHfNAFj2z7AmpsjSZ2r3Pcwkedo1UM87B+eitNIaB+uIaHILInvGQuBFy82ZdGSBF7gCpE9zlO4lHUpDkItAVn8fT/zzuLfiuoKa9ACvyi8V3MoUi9va1cFYMn41voFAN63vI9XXX09W0ASCYuwkCucqwiIEvzook/gy+//EI4K63C6HcSdFkbGRjE5PSWT/+jwCKbGJ1D3gr6wJOnYJMRz+lVcKCxpe6YFrcaTlSDYZ0c8YAZfrJCkANB9svUObIQySXyx5tofT2p/1+3VSCy8LVLSpzgOhbNlPWf252Ltt9jnX+7vH+j5RAC2AFPcqFjeVLlN/Dtr/83GM7bwNtX2qVeX5hk6nQ4CJ8DQ0BCmWx3ktQB7NDDdDPHXZzwVDzrzGcBQE0mcwG80pcKDx7pIcx77eqzprV61BW+5O6q6/oEs8EKl1PtXw0SrNt601qxh8RMAd1qNB6/uOfgWsNzVOAVcB/B0IoWhccON+K+PfxJf+8SncYexjUC7LSGERqMhte/a7TaaNZZ/VdAs7FscZeX3Pg/E/N16LAgm+Ak9YvJ5KQQ2iBZd7wBhf30yX77Qwa6zX0B3iOGytTp2DjY+bLy+/B4Yr+8MwuOsRIa+TALfx0aNgqAKvhsg9HzcsmMn3KEG4kYd7aEGHvXsZ+Luf/PXwIYNyIIArheIB4qRadWvxb1WTVi1a3Ut8FsAd1dKdVajGasGsPiwWusXA3jXajx4dc/1YQFOsmYnzfBADC8zmYPZb6/Bp86/AL+/9Hs4yqvDme6IbIMX+OhkEVLf1M5zjcaAHGXJhtnSAmU5AQvJ1kN46GALaDncsz5GTNHX8+QLVQBrXwuI0KstTKWAhKTzwqFkS9sEmdE5s+8TkxpscgMzOFlMu+Z48GNgKKhharqDyHXgH7UFtzgZ/uqMv8dpT36C1BZMogR+rSmoKu1m8ELWz1pAZsN6GsjVsxzMAmcrpd59sJOW6++rDbCGCy/WCcv1gNV117cFWJrQdYGoKO7ruDkCerGiLtLfXYsPvvTVmPjl1TjSDeBHCTIWAB5rYmdnCqnSqCmvV9+uXOdM9uAFCddwtmyNw749y4BsUK1cAazFTYHr3X4Hej6GBMPcbD0S1wCs1DWlqfg3ioWGWV80lOfx77Gby/n8vRGEaI9PYsyvI41zpCwOPjqC7QHwlHNfhBMf80jAd5CQPUXvleNDJ7nItDhBUeZmcV04qK9u1e6DW+Cawns1dfBTl+eMVR+aWuuXAnjH8jxeddX1bgFiKfJoW60O6s26IbcmbTS4tc2BHd/8Nj79lvPh3zKOI/wAE3vHETRCtPwM7TSW3XPZg2Vq6ZlPLF/HkqFnZJ0VocF+3b3BtPR6BwgH8zwt1kO33u13KACLNo4JnARg5TMAVpADHkFWIfhKDxbPFXkO0h2pc9UYRjQdoZtrBBs3YhcynPXWN+CI0/4c2DiCThLDD/hGU8SW77WGchzkSQKHUgyrvooN5rt/GLT6XKXU+av5nKs+NLXWYwCoUXHb1TREde/Bs4DlYOWFp4maV9TM0siMinunA8Q5fv35L+O/PvYpdK6/ASOeC+gUCBykKusVCu4V9J1hhj6B1hJ4LchiCEQEonuFjQfPfmzxegcIFcBa3Lg8GMDyixeHnilmdPb1rEyWoM8NUOHNsiWreI5wGFl4O9XwghB7Ol34GzYg3ziKl7ztPAQn/THQrKOTdk1YsCCoS2UA2TxJumIFrhbXvev523+g1qZSau9qPuSqA6xikn8FgPNW0xDVvQfPAlRrZq3CNE/QcIxic3e6g1qzLhNv1u3AzTIJF/7vxz+D//7c5+Hv2YtmruHEXeFqUT5gZhFf85uRdChnKFFDhztxU/eul41WAazBGzglYFl5sA7cfQcD4O4cuhpldfzZV+/Lopi/OF4NE1mMzugQgtseg5dc8HZ4xx2HNMnhDQ8LkZ1qwXGSSgaw67vI+WE+S75lIEdh1ehltMArlVJvXcbrH9Kl1wrA2lx4sY4+pFZXJ1UWYCafAKwc7biNDcFQURHamCaLM7h1F3mewMkSyST8xgc/hG9d/DlszjXGUo281YYT+iZUUdZDKkCTZAuKjo8sBfL/bm5Svckvkc1BBbAGcixWWYSH1m0HlWko2Ot8H0xdRsNVNN5du1ExPwmuDK/RvEPcwHSUxlQ9wDH3uQee+JIXonHnOyJxfWjtwFe+KIBk3Qxu4EphQSb9asfcI9MJfBVWEcJD68rD6aybC+/VrtV+6DUBsGSh0vo1AN642gap7j84FhAAVPifPHKiCHqIungICqJOVoZcxwg5Ke/di29e+Al86+OfxpZ2ipHcQa7J5zBhB5EnzHNRiNaeyTiM86wAWQZgMTQo2VOFTtaBduuDY8mqpZUF5m8Bo+1rdho2hO6WkkH4flLfqjbUxO6JSXnDhhvDiONYBD9jR2FP4OKvz/h73PsfHg8cfRt0yONSPgKEUuKG/K2ei5mvIEEWrMZVDlfEVqqjssAMC7xWKfWmtWCTNTM2tda3KdTdj1wLhqnaMAgW6OvpCCLir7PqbQg3BDkSdDGkM6ibduAbF34cP/rCVzAa5fAdBVdrBCS3p4noZfmBKyRaltugh0t4JUJ+N6U2DKeEutC60Pcp33QQ7Fa1sbLA4i1QBlgm07YvyWA9wlGSwgsCOJ5PsQZJ+e2mGbpJCj3cxJNfcTaOOvkkhHc6AfBdTFMN3qnDhSM8SvEUlzdNJMcL17IAdpV46OI7cn1d4dZCtX3bWnisNQOwCi9WxcVaC6NiYNrA+EGhJK68fvkLiU8YL5Z2gYmojVpICBUjiDPghltwyfv/CVd941KEUYQ6F4YkQagc1BwHUaclZXiGR0bQSjsCsBgqnA2w+nHFCmANzJCpGrrkFigDLRtutx6t4foQtt26A6ObNqGTZZhGjhY0Nh57NJ527tnY/Bf3BZqBCcFr8qsUlOub8H8GiNRVeeMkSK7vOeuVvlnyp6ouOKAWWBPcK2u7tQawagB+QO2KAe3cqtkraQFJI2Q2Ere6jgFUVl6h4FRlnJw9oJtHqDkudGsKHsFYlOELr349fn7pt1FrdzHkh/DpwZpqYSgI8P/bOxNwy6rqzv/3OedO79YIxVRUMVjKoGJADCqCAyCjBknUqB0SUdPprzuapKN+X2foJJ2h+4vYaTXpTqKiUTMYNRIHRFFRg0FQAhEVERGtYrAAqapX7707nXNWf2vtfe4979aruq/evfe9M6zDV7yqd8/ZZ+/fPsP/rrX2WrVaDfvnZ2GqgVsdZdM3GAr6FiwVWKs52XquLBLoF912tT6T1bhseeIFIegR6jNN7J2bh79xI3aHHew4+0y84b+9Fdh6FLpHzCCuNlBn1SRCylq5+F7rchv8T/cdygZ2uXBIsWLZz3RTAo4AV4Y51xjTzgqRTAksZ8W6GsAHsgJI+5FhAonA4i5ygkKb+ko2CbiVC8r9gsVXHHK6dxjfuRN3PYib3v8h3PyxjyGeXcDJW7ZgYfdu1Mlg8/p1eOyx3ag2G9aCxV+wRbzZvFnqIszwdaFdWzUCSYZ2vj/66RfcYhDpROyBKhUsRIRus4GfvuJSXP7aq4EdnJUnxEK9AoKPBrvcOYKdBZZnJLkoCyj+w/ey3HV8cycVuTWD+6rNcY5O9IvGmA9mqb+ZE1hOZH0SwEuyBEr7klUCyXI+a8FKwjUSkUUhx3QYhPMLCBoNeXh3OX1D1YfPeXR+tAs3/c0H8fmPXQ+zbz+OqdXhL7Rhuj00mw30om5fYAkBCXLnwrZ2HZT9xq4uwqxeHdqv1SGQJOeVRR/9JLwe9re7iOsN1I8+Ci94+VU45xdeAxyxHp2oi2DdBkRudW7AqxCluKC9j+VW4xW6yerd5MtSarWvlslZnbnNyVk+ZYx5adb6mlWBdQGAL2QNlvYnWwT4Wdtz33DFjZCyViVCi3/f4ySGAXufB6sLFwho8MrCuTlgfgFf++CH8M/XfRCNuRaOnVmHeG4OcdSDF9hSIMmSc7vU3BMLFgss+3sVWNm6MrQ3q0EgbTGW0jip/HCxsasEezMNzGw9Dle/+dex7nnPBQIPaNbBlXdj8tBki5Vz+yVWYu67T5Hcf1LY2W0uxaj9V3LLqSVrNaY6D+e40Bjzxax1NJMCS76sEP0lgF/JGjDtT3YIJC4E7lElLbASQSQXEi/l9hDOthDMNCRoo90JYRoBumEH69kd0esBj+7Bnf90PT77gb9D95HHcPTMDNpzs6hWOB4kdpYqmwfL1lmzaRu47Ae7RtIrqBJCkqx06A5L1zdMvpQXoWh0dq4K7ckoAolbz16fVqnYLyc2BUl6Y6Fk1Uzyc/HnSVC7Tb5r74nQM+j4ARYqHp52/vNw1Zt/AzhxGxBHkp19gX8GVXAV0Gp38A2J76OepGAg1KUwzsAaZuMrB4l/pb9pd+GoQevnRSbwV8aY/5TFAWZZYJ0K4FYAm7MITvu09gSGvQXDPUqev/04rGQH50pkgdaKOmj6AYJWCMy38L2PXI9Pvfc6xHv3wQ/bCLsd1GqcJZ4f9lwcmitLh6BOBFMJ0K5VpK4auzg43QMH94pty9iyIVwSxCZdtOkd7H6c38e9jFzttrWnqT3II4EDBZEdxVLCXiSUpFJI9onR45I17vcclJ6IpMTNFxG7wfkgT1ztIsZkbUkILyYEnEfO+Ig9X4QVV9XdR4QjTtmBZ192Cc6/5mqgWkHEMVVBAM/jdlhauRUpyU3sDFmpW9QKOyfalkx21b/B8zhz2ucJEdgD4LnGmHsn1N5Em8mswJKHhCYfnehka2OLCbDA4i/Q3V4XG/0q8PhPgPoMWrfeiv/1lrci6LRRC3uywol6XaAbour5qHnWitUB0PZ9CYBnYcUvGyuwYnnBSSJUt7pK3BvOjZK2gHH9NrVg6ZW5UgJ8Lcmz0jXQr6m5hOWUd0n252sx+RLAPxNhNShl49nrkgyCasDfLdBuLUgS3ka1hsA3iEOu5cmh6gZd3yBsNMBvu+3POAM/+yuvx1HnnSuGrzDwEMnKQCNpQSU16KhvRysFoseVjUBmkoouBT7rAmudS9twRtmuGh3vKhCQVNN2rTf1ejAVDqiKgHYbve99D+/5n2/Dg3d8E1u8AJWFDipRjFqlik6vjXbUQ33DOnRC+6awiRbJ/bSlPPgb+LAlgYN2079bopTbKgxcT1EUAuMIrDQDFlPJSsBF12dkQFEPFQSoVQP4xkPU7SEMQ9k/9iuobNyAJ3od7AXh8qtfgxe87hpg3QxQrQFBRdIu9G8Sd7OkwiWLMhU6jtUncLdLyzC3+qde3hkzLbDkmxnRNQCuW95wdC8lcBgExMTkPBEmhKl46HQXUOOv6/zV+4Gd+MS7/hLfvvmr8Pbsw5aZJhZm96FaraC+vonHHn8c6+oNK6VcPIs4XEwslixbm83+SfIFcUxLj90h7s5LBwYfRs91VyUgBA5XYKVdhLYiAdcjMAh9Epd2mHJZsyXW63GKBCOWW96fhRX/4TJS3swMHu12MecBx5zyZLz219+IzeefB3Q7wEzTplvwagOfpJsz8uy5pP8Sa6WbElgRgdcZY963oiNX6aBcXNtE9BkAl64SEz1NWQhIHi0gbrfhzdTRi7vw/AA+Yszu/jE2bDoS+PFj+PL7PoRbPv4JYHYem4IAUasl+bTWc9qHFjsZgR6X5PFiicdKAod52XmFXYfsNiR+kVkrAe8TejYGy35WFuA6zkkTWInASvowWA3rOWFFNmbQpR5hgRWQrfbH7sAwjCXuMKjUxIL7aLuF6kkn4KyLXoSfee0vAcceA1AErFsvsYtBfZ3ELfYT1CUx6vxlxOUV7eermzQYba/oBG40xlyW9UHmRWBdDOCzWYep/csfAYpiqTvIK5dgDNqdNoLAQ8UPMPvj3djAIiqoYecNn8WH3vnn2HP/A9jaXIdaL0I4ux+bg5oMuuvH6AQstGIRUazc+OVXiWx8VrLqkC1dLLBs6Z3FS9vzR097vNYEEovUcmOw0kHxLLACMb166AW8KINEaPG1y+KK/1ohg7AbSWC64eoGUQ/zFGNmy5FYf9IJuPDq1+ApF18EBAGbt4CZGURhD+RXpchCpXKQYsy5ePOs9ezq+Q9B4BJjzOeyTig3lzkRvQfA67MOVPuXHwLWQ8ir/AzCTgfVoCbJR6NuiAiEao2TP8Ro79mDeqWC1vd/gOv/31/jnn/5V2wODerzLawL+WgSt18niEVocYFpzo3FLzNZNShWLBvknmy8qlAMaLm5A/Mzr2Xq6cFWES6HAX8BqIX2OuR0I/batQKLr9sqZ1PoxQi8GvxaHXOewSNxF/7Wo3HulZfj/KuuRG3HSei0Wqg11wMRIe6E8Boz4haUKlYc35jqTD9fXToIS++B5UyX7jMg8F5jzBvyACQ3lzYRnQzgSwBOyANY7WP2CfAzvkVdqU1Y4VxZvQgVF5Db4wzwVYNeHMuqQRP1bPXZhx7Blz/wt/jiR69Hc6GDDZ0QldimZLBxLDHi1MpAfgHyH1ubbRCPxRFaLK6SP9mnpT3MIoFxBBYfyxZWNriyuFpU6sZds0ZykFSwL4zRnqljx/nn4sJXvwLHPO8cYKaBFrlkoESoxD4M583iGuxhDL/mIXQpUZKMCiyw5D44oKZVFulqnzJIYCeAFxpjHshg3w7oUm4EFveciFi1vjsPYLWPeSFgn/RJEsOk3FnSe75B2KJV5aqzYQ/otMWVuOtLX8YH3/EXoJ0Po86JS6NQVlhxvcOAl6MHAVrteZv3p+Kh4rFZi2AkqN6mc2AXIb+/xrFiGS73M8ZGEtC/8m3U+de6/XH7N+7xo8iOan/k8fHS89cvuuy+MEQUS3A6n69Sqch1ybmsok4XjVoVcRTJ6kD+ghHHhNAQ/Jl12Nfr4bGwh2NOORUXv+pVOOPyy4Gjt9iSNhXO1m7TkHKtwKXqBYpoavvfEQAAIABJREFUS6WREIGVLsiumdhHTbF+vpjALxtj2JuVi228p/MaDJGI/h7Aq9bg1HrKohGQd5PLUp1KPpr2XoiTsB2D9ZXkdOAA9xkuuxMDDz6MD1/7Dtx/+x1oP7EPzRhowhOLVq+1gEajjk6vi4j/o5i/ICDwfFQ5salkyAa6UagC6xDX1SgBMkrArfXxo26ZUf0befwIgRXHMXzft6v+PE9EVrvblXxWxiOJN4w515sXoOZVYEK2ZHloecATcYjq9m143pUvwfOuvBLe9hMALwA8m3pBhFPV3kEsmpJVs/0M66mKCsNprzS4fdTM6udLEPgHY8yr80QmjwLrdOcqPDpPoLWvGSQgKdZdvzjw3KXFSrszAgKi+Q78SgAEHBDMy9R78Ouc3T0CZhdw96dvwKfe//eY3/UI1rciBK0ONlfrmN+3F5uO2IhO3EOXa6t5nPXa3nLEFoMoEsE1zjbuC3qUQBnVt1HnX+v2x+3fuMePy2/U8QnfYVdhclylXkOb87pFoVhVPQ5GZwuSMVJnc6Ezj3q1it58W26ARr2J2TAEbV6P4896Bi655hex8ZQnI9i2FTAVdHuEKlvFbKjWQFmly1MlYksu9NQ95kpH8WFJrVApcTVqkPq5EgAeda7Be/IEI5fXNhH9KoB35Qm09jWDBIa+VqdrG/I37L4rI4pt/BWbsQJf4qw6xKVCItQ53UIvBB58FNf/xbvx9U/ciM28eqoToo5YCtbGHErPOYF8zgvE67Mi6y7k+KyhGoqHS2mUABjV3loLoFH9GzW+Uf1f6+PHHd+o40cJLBP4NikoxWLBArsGQSLu+XebjtyEJ/bugRdU4ddnsD/s4aiTT8YFL/9ZnHbZJcDRR0kX2ob1VRWG74rQxlGJ9zH1BYVTL7i0cgOLVuJzT761yApam9+XN5Z7433FGEVIPy8IgTcaY/48b2PJpcCSL0ZEHwfwsrwB1/7mgUASgQt5EbGLhbeQY6c8zpKV2qgLj90tC13Aq2Lvl76Kj/z1e/DE/T9CNDuLBsdgxRGMieBxeZE4lj/84q8GFUS9zlh5sEYJiFG0RwmUUcePOv9atz9u/8Y9flx+o44f5jtsyeLVsGy5Mr51D/Yijmq3MYLwfOzbO4vmliPxaNRBfdtWXHr1q3HOFZcDmzeLKzCcX0Aws0GEmS1TAAlcZ4HEXw6qiSWL/8GfDRm2ZOVsIrLc8Rx7mAgxtWCNmmH9HMD1xpir8kgizwLrLOcq3JBH8NrnbBBYXLIjkU7JT5I0DoPv2B74P1lQ2OPVU4GsNGx3F9AM6kC3a98cj/8EX//wR3DrjTdh9qGH4bdb8LmGG8fCcE02tijwi47fSWNmGR0lAEZRXmsBNKp/o8Y3qv9rffy44xt1/CiBxRYs3oetVXJVe8bm/YxjqaUZelXMbNuKcy6/BM+98iXwT96OKPClBI7xKwhkJQYHC/L/2IdYBWdi70hrBnXOw+DCGJMSg4N/poo1pwfi3jqJUWvUGPXzUhOYda7BO/NIIbcCy1mx3gzgbXkEr33OIoHk6zinHbUiK/lN3IvgwZecQBJGZd8vmFtoo7m+Ll/u2R1ILKbYb9KLQPf/EB/9q3djz/0/xJ4f7YI3P48ZryJlR0AxopizZo9X7HmUgBhFeZRAGXX8qPOvdfvj9m/c48flN+r4UQKLVxP2+MtAJUC1Xheh1eq0Ua1W4R25GU+/5FI858qfQe3004GwC9TrQK0ubrxeBFR8yBcKw2kYuFanCRFGLK/YslvjJR0wbLpKFowkqsllg+fVuWmLr9iCxarl0rprtPuoKS77528xxlybVwi5FlhOZN0AIPMp8/N6gZSr3xydMkjUwN/5+eVUq9RcxTQPcYfgOZdh3CN4dYNWyPEt1oviG/dK4bisNqd08LH7c1/EFz72cTxw5zeB/fNocN4tsvuRc6oMG7Lk9cNBLUts6bQOaQEwXFh6kdHAmeoSFxLf+DbRKtnSKHwuE0tJH1aPBwuaTrfJ/VhrATJKwI3bv3GPH3n/mENEIPWTRdlW0teIrW3JVyjJKtT+vEretcF141WqaPW6iNkqFXjY1+1gZtMGvOiSF+M5V70MOO00QKoVVOwFDA89jjn0OSCe3eL2184DyEWhQBRKpne+toGqHCP/Hgpo5+uJv5YkXkJuQ0Ls5cIbuBw1yn3kVVLWHT5jjLk8z4MvgsB6rnMV8p2umxIYk8Dg+/aBLozkm7o7hfOepDwkNmC3n/4hBlpt+/La8wTu/cq/4qufvhE/uPMu0L45NE2MDRWAugswvNw+JhAZm8bBC9DthjYQXt5w1tVDMb/K7GpE+/JnC5itHydVT9xqLvtKTBeb9iQwOUl8yu3yMR22UPCuxEV3OT8X2yNsAL6EzPQXAgwsbYmQkxfniCfIWgugMS+GkYcn9pm+U7nPY2lxvCibvySbdYX5hsSUPfFgnokiWXmKmFeeerL6lPXNXNyShRd2CWyMihfA42uEs7AHVXRZMPke9nuE2jFH4VkvvgAvvOoKBE/ZwQGGQJMjLHw72dJ3W8KJ/yHXf2p+7V/TbvSB7HLdXcyLr0t3HSYfSBvDqbty/xYaeZnoDodPgIu8ckLRWw//0OwcUYhLm4h+B8AfZger9qQMBPg9wWsEefMlOitlZXBipxP2UAt8m9JhoYNw14P4/jfuwtc/dxPuuf02zHTnYbotNCpV1CtVoBMhCkMpsssv4xqLM8mXFSPkYHnPg1+tgI0MYl3zrfWAXToSPCw/7cs9sWyIWCIrsDjBaSKcxH3kGTkm+V2SbZ5fr2krFos4eTe6cY0SVsn8F15giQqxsUaWUSJQlr4DFlsqRcqyvTCV2jwtagm9btdZRz0JTA+cbuO574QdoOojolDipKrVGhrVBlqdHrq9GFSvoeMHaB53LM6+8AKcf9VLgVNOBrottAMP9eZ6kFi7lhaDIrPGTGRbhueAjnEqBH7XGPNHU2l5FRsthMCSBz/RFwG8aBXZ6alKTsC62GyUFgssca8N5dUSERZ1YCSZYwWijNpd0H0/wO777sU/vf99mP3xI+jML6BuAtQikjpwdeNLMtL52X1iwao2awjqNbTCLvYvzIMCD+vrM/AWQhFNYr3qix+vL7gOmCKxVNnNFgoeCKn0yz9xIbJ4SCxVYiVLRBaLMhZsrvzPwS6FIguspNCy5cbCylps0uJz8SKKtHgaEEv2T+9rhXAsQeY8/yx0umEHC1EXIa8MrNdQq9VQRYC420OvG8H4PnrGw1zYQ7x+BjNbj5Hg9TMvfAGaT3+qravJ1yELKxjML8yj2Tj0GiEVWCV/yK3N8G82xlywNqee7FmLJLCeD4BFlqZVmew1oq0dhADHayWh8CywrH9uELzLXpuetfvAsJWh00GN3TISu8L+Rc5iGuLHn/0sPvfJG/DAt+9BPDePJgIEvKR+/xyO3LgB3XYLvV5HVm+ZqgfidA8Sz2JQDYOheCkb85K48RK34UCAmb4A4D1rIb/0EyfnwKUzON65H1PCKm0dYzF4qIWQRRZYTqYuK14tfQkNYqacu22JWCsW64kFkVecSmqPwIdXCcSly+kWuJhy2ApRbzRBfoAW+wnXzeDYU3fgeVdcih2XvRg4cpNNkOuz6PbRiXqSeLQS1DBT47oDmuhTH3CZIsCPzQuMMV/JVK9W2JnCCCxnxfotAH+8QhZ6mBI4TALWusOWAVlJZdfB2zacu65NsdQotJ/EqPJOHADPKR16vDzLByo1YL6Fh267HTd/8gZ8/667YOYW0OBd9+3FEc2GfGvozM9KG83mjLxw98zOot5YL6IucfGlY6ySwfALmfvJdQ/574k7UVyQUYxAVjPa4PbEAtMXWCmxNhxEX3YLliTM9NhyZazr1Vn0bKzbsIt1ENs9iF1j5yAHjNvYt/TDmOdBLJJ+gC4HVPE3RxNYiyHHWsGHqVbRrjQwzyde38SOZz0D5770Mhx7zjOBDU0R76jVpLZgxMs02L0cyBUo1wOLtLrva4z5Yd71uvtUCfy2MeZPpnqGVWy8UALLiaxPA8j1yoNVnH891VgErMCyK6hSFiwXMCxB5K78jpUuJGuuOFWppHKQNy2nbOAAd/bzAZibx9z37sUtn/kcbrnxRtDcHPyFBVTDHpp+gDrHu4ehHMPum9AE0nIisIaD05NgdiuqbJ25yLOCypAVV/zSTtx/cg+JK3DpWKLEWrXcDPRFtmANBBbHttlFAkFkFwkkQlfkt1uAwNyZa+x+csqDII7gc5Z1J5IT0yPPD+/Lkb4isDiwvVqXouG9XoSoF6Lt+WhsPwFnX3whzr34AtQ4vmpdw5qkaoGIqmT9X9+sz3PtUoxI6NdY178erAQmSuAGY8wVE21xjRsr3P1FRM90rsKNa8xWT194AimBlViwJN2BGzhbOFIrDTm7Fr+EWZBVnCiiyFoufC6lwxYHtmzxqsGwB8zN4RvXfxL33HYb7r/zLpjZ/WiSgd/piQtxplKTVYeJG7AvjuT81rW3aGk/W9pcGgb+KTFD8vIfxFlJLNGieWMhNijpkwgHFgRWOBw6j1eRBZZYJfuwrAUw4Zq2HkqUnlgPFwssFlbsMmaByxNhY7HYNZjE8xkRU7XmOqBew09aC3i0tR/NY7bg7BeehzPOPw+nXHIpFxC0NimOvfJ8idGSufcrsjCiGnCJGxsvR2w0tafpZ2ZXlVX4B1UeBrjPuQb/LQ+dXW4fCyewnBXrTQDesVwIup8SWCkBmzfLuQjTMVj8dzZqGYgVIjEa2PPYhEH8jmOhFXYJxiP4vkEU9cSiIcHFnPiRsz3OzWP/t+7BbTd9Hnff+nUs7H4MlW6IahxLPi2fbC6kpGX5ywFxPbJWzaZfSCkotqawJUYkmQTJL15RJrFA7rgkoJ1FhR9bgRX6g+OXYlhkgcUcJAat71plsWm5JG7YJH3GIL3BgFLaymXnzq7oYwluHcoeKo0ZPD63H2G9jh3P/Ck86+IX4rRnPwuVbceJtWqBj6tU2WGIQFLheuiFnKuKUK1Yd6C4BGNCxTN27pOim5yUSoOwVnrr63GTJfBrxph3TrbJtW+tkALLiawPA3jl2iPWHhSZQJLxvX8jJRmqk0En6ROWgCBJF7vOVSjvVBYrg8Bnzp7tsVWLM7/z6sOFNvDgbvzg7rvxtZu/gu9+4xtotOZhWm15cXKqBxNFCFsdsOOwXquh02nJ8n7O5M0th3EPIVnLFceGcToIeccaGzgvcT9EkmCSf/pumT47IdMCKxkOx3UtN2XDNK6DUQJu3HPyCj4+B8e88c8k/xj/lLQXUSSLBMRy5MfoGiPJWznWTUS124+FWJUMAs5PxXk8eX2D8RA269jPCWnDCNVqHWR8tKIIXS5x06xj08kn4Sk//Uw84wXn4rhTnwJs3ghUA4CPBaHH+dFcihBu0wq+1OYPEn0esKJRA9zHvTz0+MkQ+EdjzM9PpqlstVJkgXUqgC8AOD5byLU3RSGQBLinE432VxGm/WyJdWnobhNrAq8k5E3itmIbyiUxUFZoSbA0ixz+pySadHXhntiL9mO7ccdnb8T937wT3/3mt9CdnceRjXXYWKsj6MWIOYdSHPUFQkghQsOOSjad2TQQZiGUJKdJADsHQvNqNS5wnRQIlu65biYusUTYELs213CbtsBKCnMLD2OEpfsC5+KsJKpKLFb9BQRcENy3CURF9MBDEJHU86NWV343E1ThNRp4qNMGeBFDpYZeHKGFGJu2HoennftsnHLO2dh25jPsSsD1TQmeaoeRTdvBYkwun4ErWOxfiT5P5kSysw+uKRZjnFokidtjka/LrtfwAtZTPwTgQmPMvUVEsbZPxykTJaLXAXjvlE+jzZeUQKKhFgkseZulgCwOaDowqnjJDN5LAOUs7qHNdSSNiJeRBde8xGrt/979uPu22/Htf/06dn7nu+g+MYtaL8IRzSY8LuXDQo1XkfHxbBBjq0sYYcZUbQyQzSUnL3mukcivYLbE9MsCubIsyctaDmC3kwTLr90FMG2Bxe0zt7Qli0WXVb8cN2X/zuKLBavwiVgLR6CQUK/WELMwDtllV0GjWpN92u0u9ne66NUbMJvWY/NJ27Hj7DNxyrln47gzTgOO3gLUOMksB1O5ZKCsvpMlgKKu2BTGn3M9G+vuk7i4xPMnec5Sj3iXp4uT44bOFczVBFVgrd31q2fG640x1xWVQ6EFlntpsMBioaWbEpg4gaW0hdxUhxJZSS8kVsfWP0zWe9m6boMt6nGdQ146aKybyiWy5L/HYRsVaqHi8+dcOI6AfbOYu+8B3PP1OySv1r13/DtooSUle/w4QsOvSNwXRbGUXpHUApxkgi1XzjzFoiJiSw3XVfQ8xPxvWXk4KMcjooINYbF1la3VNm2BlQgrKVPkrFf9MkWcBZ9zkvG8RDEMp7wgLgjOFsAAhvNOsRWRY6E8g/leDwthF8FMHUccfQw2HX0Unv2ii3DMySeiedopwLFHADNVDsxD1zPossiNibOioRr71v3HYktWnzri4t8dCKz0atDF4VXJAYMQLI6ukwS5azV5et6yE7jOGPP6IkMo/L1FROwiZFchuwx1UwKTJZAKbFmsM6xokk0+sKvM0mVJbAB8shLRCpZ+yZ1hkbboheqa5digbgs+16LjFAyhLcLrccwW59hqtbF/14/x4He+i2/f8jXcf+e/Y/7BR1HtRtjg11CtVtELYnTjnhxLYU+Sl0pslsdCgRc29lwmdyuw5I9nZAWixGWFxRZYEpuWir9KXIU8AzxzXSn07SHgzPs8gzEvVIjQI04ya+A1Z7CAGJ16BTPHHonjnnoqTn/WmTjlzJ/Cpu3bgEoFqNWluDI4/QZfJlweia8NiYFj+5KzMoUuQJ0vlGTVhDNy9S9qvtYSd7PbPbl0uCWxViVWMLksNVfDZB8I2toyCbBLkF2D7CIs7FZ4gSXvKSIOduegd92UwOQILOH+sykh7Vts1AIttkZxoHLaxZis4Uvcbn0Xj7OgcIyUeAidG0osT7592XOMFbE7y8k4CruyyhAS/xMBe+eABx7EfXfciW/ddgceuP8+7H5it2SI59I8XDOxYQJxKcbtLqJOG81aVWJ/uNiw3EsisjhppQ345hVpRXYRpuOukpkVC1/ErlSg0pyRfFOcqqoXhYg4jUa1hqA5A9OcwUlPOx3bnnoaTn/22Vj/lCcBG2ckq3ocBCDfRws9VGDTKMikhlzMmWU2Z0sjhGzBDHxZqOAWn9pusNjiX1RdUebkWkwLfhbdEiFmrzDJvyZuRs655oSV8zhP7qbQlpTAsgj8vDHmH5e1Z453KoXAciKL0zZw+gbdlMBkCNhsC3YTq4F1vyTB7/bXBwqtxMMj6/f6y80GS7qSnKU2nsYFu7O1SFq2xZ05gJoTRsoKPvYQOssFh/vwx2wQkZubVyEm/iQ+QMRWW6xb1FrArm/ejd0PPIB77/42dn7vPsw/9gT8ThczsQeOFmrweVlJUGSD4Z3QEuHBLjLuzRo+RabtIuy7A5kiu2Vd/FWFLU/VKh7v9mAaDdQ3bMC6LZtx1PZtOPFpp2PHM56OTSedCGzaDFTtvmBByi4+SXkWiyAL6jaVgs2PZt21glPyK7DrzwkhPoatYrJikfexqz85cW1f4B5qHkbFAk7mjtBWlMByCLzTGPNry9kx7/us4aNxddERURPAjQDOW90z69kKS2AJgZWIp3T6BrYhLHYR2oST4q7hPAfJyy8xeQ2ldrDr/qxfRwoMc+JPfvFKslCbKktyU/G7mO/oRfFfErgjLr1+4WbZhVDhNtmy1eoA8/PAvjnMPfIIdt5zH74vwutH+MlDDyPgVAQhxxiFoDjsJ9eUnFoiGlwqeMM1Fweznaw4TD9k7O/SPFae5oHbOpjAWlRwWZgM8nslnw2ShNo+D9drtGwjGHbZcS0/FjcGaDQa2LR5M+qbjsCOZ56JI7Ztx4lP2YHa9u3AxvVAjcsfBfJHXK++D89nXx5bj6xIlsWXfUE+cCeL0IrZOpjEWtl5ZzEbe7wCkK2ebMAiuX4aXAza4ZcvkqmbzZ3igF8ePE6rsHeqDiw7BG4BcKkxZj47XZpeT0ojsOThQ3SOE1mbp4dUWy4VgeE32tBLLrFiDQusZJl8/42YxM4k1rAl2kl9tAhx+tAD2Kc+TKxPSQVFm6E9KdnD5XpcyR42lYgbKUL88MN4/OFH8MPvfR8777sPjzy4C088+hjm9uxBNN9CsxeJlSsIqhJsLyklIo4H68qqxzoLDbaAxTaNppyTBSQbxVhm+tYVlmwi2NyKxlHWKbbkcQ1ASfTKsVJyqKvh5xYDcPt2ZaR1abK7TRKBulV+Nb8CjxcIcFB5HKEdh+gQocuCyjeobdyADUcfheNOOgHbnnQStp50Eo7bvg3NrccDmzdZU2E/jonFZipDOo+Y4+NkW5zANRnvQQ1LS3yQ/CoJobIWr2Vsh7hGS/UCWAYq3WWqBPY4cXX7VM+SocZLd38R0TUACrssNEPXlnYlgwTSeZyknIoTIhyqJZYQdnKyGGHxE0dSWNgVXLQ1Ezs9YN8+tJ7Yg+7eWTzynXuwb/ejePjBB/HIQw9j35696HXa7rgIUacLw1acmFNFAFU/QBB48tP3PHS7XXE7cskfwxYww/mm2BXJOaci+fdii9dgsQAn+EzScEkyUO69/GR3Guf2skk2Od1ETDYBKB/Aeb4qQU2Sr7LwqdZqmFm/Dpu2bMFRxx+HrU86GceedBLWHbUF1W3HA/UKUK9Dov5ZAEqQWyDiiZEMZ79PT7tYGnVTAkqACbzOGPO+MqEoncBy346vBfCbZZpoHasSSCxDfeuJZCZPuc7E2uXyOomJKYLHn0sMlhztotytRcrGd3FgEAdnh7a0T6uNcN8s9j7+E8zt34eHdu5Cr7WA/ftmsW/vHszt2Yf9+/ejvbCAsN1Fg+vuhSGiiLOlH/izUuFIsANdrNZSxS47jlOyaSZ4hV9QrcALqlY8eQEazRnUZxqYWbce6zasx/qNG7F582Zs2XI06pvWY/3Wo+E3Z1BpNoGZJsDB5Da1vY2X4hWZnGvKD2yaCi75Z6yI88ErB/1DBvknFjm9+pRAyQm83Rjz5rIxKKXAci+az7C5smwTruNVAmnXm0lSuLsVghLv46Ks+zFWktCUBZXUz3FuMCfMbCS9jeXin4kgIV7aKEsdnbsxtgWs+d8drrHYk8zmHFRvehHCMDzgDweU93i/g2wssOrrG+CVlYFXEXFVqdfEIsWZziUj/UYOMq8CvBpSfJOuMRZSAf87lKz2kASuvLlkoe6nXbTAB9nw82TJQeJ5Hc6SoFeXElACBxC40RhzWRm5lFlgPdXFY20v48TrmJWAXfafqoUo+sIu++eNQ/FDDmpnAZOsXuybv1yQtpRq4ZWNnB7CWb9Ykkg8F2eeZzecs4CxVSzZOMYr5MJ8LFHcirl+2xK9boUZC6FDbUmkugSPWyEkQkosULDWNW5DXI0uPsq1Tawgg4qs/IzJijyPi1t7HiquXzwu2RIoki7DSCA6uxz9iroA9U5SAocgsMvFXX2njJRKK7DkmUn0CgCFz8VRxgtbx7wMArI40SkHCc52Aeau3Ir9ZCCK2JLDu0t8lrgWDax9yUZ2cwEWyWhuDKoeSzI+glcWsuCSxE0i0yT1gZSAsakP+nUQOQg95bKUs6dF2RJDkqB6ezPbNApJgHx/X88Gv/MqQs8mUe2Ps18meaC9ErkkujNhwwH6PG7JqO8aTkxY/aV6y+CtuyiB8hF4pTHmI+Ub9uCZUtaxu+cy/T6A3ys1BB18OQn0rTKDHFwialyMEX/c7XXF1RaYgSUp0RgcSM4CJ/0tbVFKBkeVfyf5ozh4PklQ6oRR7Ipdp8vQJJOR1AE82OSwMAvjnqQwYAElqwQ58arr0aJsFalIruT3EqsuItMay1gickyaGL8OIpxk90R4sb2M47N0UwJKYCkCf2CM4fdraTd9OthvvB8F8HOlvQp04OUkMJwKQFbe2Tj2QSoA+4hIMtQnqbrSIoX1hoRmcSz4wBAmv+MtecgkxiYRca5+n5+4AJM49sQytMyf6ZxO6UlMefQSg5V8zGFh0ifuKy8IPGieBFfyz40rsbIN766J0Mt56+ioRxL4mDHm5SP3KvgOKrCswDoBwGcBnFbw+dbhKYEhAs4FyC601NPAGXYOoJUu5XMwcTN80MGilFws/XgzMuknWCoOPl2yL/33pLgRn5rtesvKRTXeKPVoJZAnAt8FcIkxZmeeOj2Nvk768TSNPq5Km0R0OYBPr8rJ9CRKIDME0lWkl9GpYbdiSpAs4+gDdpEH0LBZ6HAaOtxjhy1jw0/AJKQr1QeO7EqfJk2MC9boQ/RwJkz3LQGBK4wxN5RgnCOHqM+GFCIieguAPx1JTXdQAgUikBYPix4Iw0FMS41ZYpVsbUSbQ2uQCDQdIL/Uody8K524xHHD7Rz4b/6NRIYdjsgaFlh8fLr/yTjSQjLpvMsRNhiLK6utT9EC3Q06lDEJvNUY87Yx2yjM4fpoGJpKInongDcWZoZ1IErgEAQOGoK0lGg5qJBJpV9Y7hPF7ZcqRX3Y88Typm9BWipma1SLzkd5SIHJH/Z3cEIySXzKx/fL5Iw6mX6uBApP4F3GmDcVfpSHMcDlPg4Po8n870pEnLqBUzjopgTKSWBJMTVsoVqUxWExp+U8WRLr11iEbTkcycQw9HNxs1YEDrv6bCLRQfhZP8bM2dQkD9ZSAiuJWdM0DWPNnh5cGAIfMca8sjCjmdBAlvMYnNCp8tUMEX0FwPn56rX2VglMiMAis07KQjXcPAuNpcTYwZ4sS6qgQ7R/qOHIOazAGr3Zc6TPlATypwWWbdFuNnlq8nf3l4Oa/Eb3QPdQAgUl8C/GmOcXdGxjDUsF1kHwEdERAG4D8OSxCOvBSiDLBA6mTlLxRokQYXmyeHebwf3JXoVOAAAQ6klEQVRQ26g855N+AI0SW8NSLkk7kR7DodpIH7/UsVmeau2bEpgCge8DeLYx5okptJ37Jif9fMs9kEUPWiIup8Mia12hBqaDUQIJgRECK/k4sf+QC2KPnbAa2HiWRjrqATNKgI2aqOH2Rwksbi9xdPLfuVrOktuSqwkP3FNF1qgZ0s8LTGDOiatSlsFZzryOev4tp41C70NEFwL4fKEHqYNTAiMIWB2yRAzWmOTW4gE07BKUISz5y8WDOxxP6JhY9HAlkAcCFxljvpCHjq5VH9fi+bZWY13xeYnoPwD40Iob0AOVgBJQAkpACRSHwC8YY/62OMOZzkhUYC2TKxH9JoBrl7m77qYElIASUAJKoIgE3myMeXsRBzbpManAOgyiRMQCi4WWbkpACSgBJaAEykbg7caYN5dt0CsdrwqswyRHROwqZJehbkpACSgBJaAEykLgb40xv1CWwU5inCqwVkCRiDjonYPfdVMCSkAJKAElUHQCXzDGXFT0QU56fCqwVkiUiO4EcOYKD9fDlIASUAJKQAnkgcBdxpiz8tDRrPVRBdYYM0JEOwFsH6MJPVQJKAEloASUQFYJ7DLGnJDVzmW9XyqwxpwhIuJka80xm9HDlYASUAJKQAlkicC8MUaTbI8xIyqwxoCXHEpEy0kgPYEzaRNKQAkoASWgBKZPwBij+mBMzApwTIB8OBFtBqC1mCbAUptQAkpACSiBNSdwhDFmz5r3IucdUIE1oQkkoh0AuPClbkpACSgBJaAE8krgycaY+/Pa+Sz1WwXWBGeDiM5xxaEn2Ko2pQSUgBJQAkpgVQg82xhz+6qcqQQnUYE14UkmoksBfGbCzWpzSkAJKAEloASmSeAyY8yN0zxB2dpWgTWFGdfi0FOAqk0qASWgBJTAtAho8eYpkFWBNQWo3CQRvRHAO6fUvDarBJSAElACSmASBN5kjHnXJBrSNhYTUIE1xSuCiH4fwO9N8RTatBJQAkpACSiBlRL4A2MMv6d0mwIBFVhTgJpuUi1ZUwaszSsBJaAElMBKCKjlaiXUDuMYFViHAWulu2pM1krJ6XFKQAkoASUwBQIaczUFqMNNqsBaBch8Cl1duEqg9TRKQAkoASVwKAK6WnCVrg8VWKsE2okszZO1irz1VEpACSgBJbCIgOa5WsULQgXWKsJ2Ikszvq8ycz2dElACSkAJQDO0r/JFoAJrlYE7kaW1C9eAu55SCSgBJVBSAlpbcA0mXgXWGkBPTklEcwCaa9gFPbUSUAJKQAkUl8C8MWZdcYeX7ZGpwFrj+SGinQC2r3E39PRKQAkoASVQLAK7jDEnFGtI+RqNCqwMzBcR3QngzAx0RbugBJSAElAC+SdwlzHmrPwPI98jUIGVkfkjopsAXJSR7mg3lIASUAJKIJ8EPm+MeXE+u16sXqvAytB8EtFfAPjPGeqSdkUJKAEloATyQ+D/GmP+S366W+yeqsDK2PwS0a8D+LOMdUu7owSUgBJQAtkm8BvGmP+T7S6Wq3cqsDI430T0EgCfzGDXtEtKQAkoASWQPQIvNcZ8KnvdKnePVGBldP6J6DwA/5LR7mm3lIASUAJKIBsEzjfG3JKNrmgv0gRUYGX4eiCipwP4EoAjM9xN7ZoSUAJKQAmsPoGfAHihMeZbq39qPeNyCKjAWg6lNdyHiLYB+AiA56xhN/TUSkAJKAElkB0CXwPwCmPMg9npkvZkmIAKrBxcE0TEmXjfB+DlOeiudlEJKAEloASmR+CjAK4xxnAlEN0yTEAFVoYnZ7hrRPRuAG/IUZe1q0pACSgBJTA5Au8xxvzy5JrTlqZJQAXWNOlOoW0iehuAN0+haW1SCSgBJaAEskvgWmPMW7LbPe3ZMAEVWDm8JoiIb7I/zWHXtctKQAkoASVw+ATeaozhL9e65YiACqwcTVa6q0R0OYC3Azgtp0PQbisBJaAElMChCXwXwG8aY25QUPkjoAIrf3PW7zERcaX0/w3g53I8DO26ElACSkAJHEjgYwD+qzFmp8LJJwEVWPmct0W9JqLfB/B7BRiKDkEJKAEloASAPzDG8HNdtxwTUIGV48lLd52IXuFchtsLMiQdhhJQAkqgbAR2OZcg5z7ULecEVGDlfAKHRNZTnci6tEDD0qEoASWgBMpA4EYnrr5ThsGWYYwqsAo4y0R0Ld+oBRyaDkkJKAElUEQCbzfGaPqdgs2sCqyCTWgyHCK6xlmzNhd0iDosJaAElEDeCexxViuu1KFbwQiowCrYhA65DM9xIuu8Ag9Th6YElIASyCOBW5y4uj2Pndc+jyagAms0o1zvQURNAH8C4E25Hoh2XgkoASVQHALvBPBbxpj54gxJRzJMQAVWSa4JInolgP8B4NSSDFmHqQSUgBLIGoF7Afx3Y8w/Zq1j2p/JE1CBNXmmmW2RiI53Iut1me2kdkwJKAElUEwC1zlx9VAxh6ejUguWXgMgIhZYbM1iwTXWRkRyvDGq1ccCqQcrASVQVAIsqNhqxQJLtxIR0LdiiSY7PVQiYlchiyx2Ha54U4G1YnR6oBJQAsUnwK5AFlfsGtStZARUYJVswoeHS0Qc/M5Ca+NKUKjAWgk1PUYJKIGCE9jnhBUHs+tWUgIqsEo68UPWrGcC+EMAlx8uDhVYh0tM91cCSqDgBG4A8LvGmH8r+Dh1eCMIqMDSS6RPgIh+y1mz/OViUYG1XFK6nxJQAgUnEDmrFafF0U0JQAWWXgSLCBDR8wFwFfcXLQeNCqzlUNJ9lIASKDiBm/m5aYz5SsHHqcM7DAIqsA4DVpl2JaLfYTM3gOqhxq0Cq0xXhY5VCSiBIQJdDq8wxvyRklECwwRUYOk1cVACRPRcJ7IuO9hOKrD0AlICSqCkBD7jxNWtJR2/DnsEARVYeomMJEBEXOWdrVkbRu6sOygBJaAEik1g1gmra4s9TB3duARUYI1LsCTHE9FZHMAJ4GUlGbIOUwkoASUwTOB6XghkjLlT0SiBUQRUYI0ipJ8vIkBEv+qsWUcrGiWgBJRASQg86qxWf16S8eowJ0BABdYEIJatCSI63VmzXlW2set4lYASKB2Bf3BWq3tKN3Id8FgEVGCNha/cBxPRG5w164Ryk9DRKwElUEACO53V6j0FHJsOaRUIqMBaBchFPgURnQzgtwG8vsjj1LEpASVQKgLvBfDHxpgHSjVqHexECajAmijO8jZGRBcD+A0Al5aXgo5cCSiBnBO4EcCfGWM+l/NxaPczQEAFVgYmoUhdIKJrnNA6o0jj0rEoASVQaAJ3O2H1vkKPUge3qgRUYK0q7nKcjIjWOZHFFq3N5Ri1jlIJKIEcEtjDwsqJq7kc9l+7nGECKrAyPDl57xoRneqE1q/kfSzafyWgBApH4K+csLq3cCPTAWWCgAqsTExDsTtBRBc4ofWSYo9UR6cElEAOCHzKCasv5qCv2sUcE1CBlePJy1vXiehqJ7Q4K7xuSkAJKIHVJMDZ1zmA/YOreVI9V3kJqMAq79yvyciJqO5E1hsBHLcmndCTKgElUCYCjwB4lxNX7TINXMe6tgRUYK0t/9KenYiOBfDLADg+6/jSgtCBKwElMC0CDwHgOKt3G2N+PK2TaLtK4GAEVGDptbGmBIhoS0ponbimndGTKwElUAQCP0oJq8eLMCAdQz4JqMDK57wVrtdEtMkJrf8I4MmFG6AOSAkogWkTuD8lrPZO+2TavhIYRUAF1ihC+vmqEiCi9QC4xiELrdNW9eR6MiWgBPJIgNMssCvwPcaY/XkcgPa5mARUYBVzXnM/KiJqOKHFMVpPy/2AdABKQAlMmsC3APy1E1atSTeu7SmBcQmowBqXoB4/VQJEVElZtM6c6sm0cSWgBPJA4K6UsOrlocPax3ISUIFVznnP3aiJiK/V1wH4RQDPz90AtMNKQAmMS+ArAD4A4DpjDI3bmB6vBKZNQAXWtAlr+xMnQERXAvglAFdNvHFtUAkogawR+DiAvzHG/HPWOqb9UQKHIqACS6+P3BIgovOcReu1ANiVqJsSUALFIMCuv/ezxcoYc0sxhqSjKBsBFVhlm/ECjpeIeLUhuw7ZhXhMAYeoQ1ICZSHwKID3OmH13bIMWsdZTAIqsIo5r6UcFREdlRJaTy0lBB20Esgnge9wbJUTVo/lcwjaayWwmIAKLL0iCkfABcSzRYv/XFC4AeqAlEBxCNzM8VVOWGngenHmVUcCQAWWXgaFJkBElwP4WQCvBMBJTHVTAkpgbQnMAfgwgH8yxtywtl3RsyuB6RFQgTU9ttpyhggQEcdmsdB6laZ5yNDEaFfKRIDTLPyDE1a7yzRwHWs5CajAKue8l3rURHSOE1uvAbC91DB08EpgugR2Afg7J6pun+6ptHUlkC0CKrCyNR/am1UkQESBE1ps2fo5APxv3ZSAEhiPQMiCCsDHnLDif+umBEpHQAVW6aZcB7wUASLa4cTWqwGcpZSUgBI4bAJ3Avh7J6ruP+yj9QAlUDACKrAKNqE6nPEJEBGvPHyZs2ptHb9FbUEJFJbAw85Sdb0x5ouFHaUOTAmsgIAKrBVA00PKQYCIPAC8CvEKZ906uhwj11EqgUMS4GSg7AL8NIAbjDGx8lICSuBAAiqw9KpQAssgQERVJ7Ze4qxbRy7jMN2loASIbMomY0rzCP0JgOsBfMqJqm5Bp1aHpQQmRqA0T4eJEdOGSk+AiGac2PoZAPxnY+mhlAxASQTWXgCfAPBJJ6oWSjbNOlwlMBYBFVhj4dODy06AiDakxBZbtzSZaQkuigILrP3O9ffPTlTNlmA6dYhKYCoEVGBNBas2WkYCRHQEgBcDuAjAxQBOKCOHMoy5YAJrJ4DPAfg8gJuMMU+UYQ51jEpg2gRUYE2bsLZfWgJE9HQALwDAlq3nqiuxOJdCzgXWPgC3uniqLxtjvlWcmdGRKIHsEFCBlZ250J4UnAARsci60AXJnwnAL/iQCzu8nAmsCADnqGK33xeMMSyudFMCSmDKBFRgTRmwNq8EliJARCyuWGyxS5Fzbj1ZSeWHQA4E1n1OUN3kRBWLLN2UgBJYRQIqsFYRtp5KCRyMgAuWZwvXC138FrsXOTWEbhkkkDGBxSkT2M3HcVRfYvefMUaD0zN43WiXykVABVa55ltHmyMCRHSGi93iZKfPAXBMjrqvXZ0egd0Avsar/JyYunt6p9KWlYASWCkBFVgrJafHKYFVJkBEnNyUrVxcyofdi0/VAtWrPAmrfzoulPwddvMB4FI0bJ3ipJ+6KQElkHECKrAyPkHaPSVwKAJExIWpOWCeRRf//UQA65RaLgnMAfghgLucmLrLGMPB6bopASWQQwIqsHI4adplJTBCdHE+Lo7h+mkA57m/bwdQU3KZINABsMvFTX0VwO38d80/lYm50U4ogYkRUIE1MZTakBLINgEi2urE1vNcTNepALiAdSPbPc9t77i0zGMA7nUxUyymWEg9nNsRaceVgBJYNgEVWMtGpTsqgWISIKKKcy3ucG7G0wHw348HwHFf7HLUZ8Xi6edqz+zS43iohwD8wMVKsUvvfgA/Msb0innF6KiUgBJYDgF9aC6Hku6jBEpOgIhYbHF8F8d5sfvxJADHAWB3JNdf5ALYRUkrwWkP2PrEdfm4bMwjLjaKUyGwgGLxxKJKNyWgBJTAQQmowNKLQwkogYkRIKKjnNvxFABPcqKMxdmxzhrGxbE5FoytZp6zjA3/5OdS8of7drDnFFuReOOf6T+x+3f6J1uTOPaJ80M9DoBTHbBI+pGzOHFizkeNMezS000JKAElMDaB/w8xN47d5raQygAAAABJRU5ErkJggg==',
                  width: 100
                }, {
                  text: 'POLLOS GRIS ',
                  fontSize: 40,
                  bold: true
                }, {
                  text: 'Platino #362, Col. Salinas de Gortari.',
                  fontSize: 15,
                  bold: true
                }, {
                  text: 'Zamora, Michoacán',
                  fontSize: 15,
                  bold: true
                }, {
                  text: 'Tel: 5106023',
                  fontSize: 15,
                  bold: true
                }, // {text: 'Muchas gracias por su compra', fontSize: 15},
                {
                  text: '\n CORTE DE CAJA ',
                  fontSize: 20,
                  bold: true
                }, // {text: '\n \n  No. de venta: '+this.idventa, fontSize: 15, bold: true},
                {
                  text: '\n \n Nombre de ususario: ' + this.nombre + ' ' + this.apellidos,
                  fontSize: 15,
                  bold: true
                }, {
                  text: 'No. Usuario: ' + this.idusuario,
                  fontSize: 15,
                  bold: true
                }, {
                  text: 'Fecha: ' + (date.getDay() + 13) + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + '         Hora: ' + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds() + '\n',
                  fontSize: 15,
                  bold: true
                }, {
                  text: '\n ',
                  fontSize: 15,
                  bold: true
                }, {
                  style: 'tableExample',
                  table: {
                    widths: [500],
                    body: [[{
                      text: '\n Descripción de venta \n ',
                      fontSize: 15
                    }], [{
                      text: '\n ' + this.descripcion + '\n',
                      fontSize: 15
                    }], [{
                      text: '\n Total: $' + this.total + '\n ',
                      fontSize: 15
                    }]]
                  }
                }],
                fontzise: 40,
                margin: [0, 20, 0, 0],
                alignment: 'center'
              }],
              styles: {
                header: {
                  fontSize: 18,
                  bold: true,
                  alignment: 'center'
                }
              }
            };
            this.pdfObject = pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_4___default.a.createPdf(docDefinition);
            this.pdfObject.download();
          }
        }]);

        return MenuComponent;
      }();

      MenuComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
        }, {
          type: src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_3__["BackendService"]
        }];
      };

      MenuComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-menu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./menu.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./menu.component.scss */
        "./src/app/components/menu/menu.component.scss"))["default"]]
      })], MenuComponent);
      /***/
    },

    /***/
    "./src/app/pipes/filtro.pipe.ts":
    /*!**************************************!*\
      !*** ./src/app/pipes/filtro.pipe.ts ***!
      \**************************************/

    /*! exports provided: FiltroPipe */

    /***/
    function srcAppPipesFiltroPipeTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FiltroPipe", function () {
        return FiltroPipe;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var FiltroPipe = /*#__PURE__*/function () {
        function FiltroPipe() {
          _classCallCheck(this, FiltroPipe);
        }

        _createClass(FiltroPipe, [{
          key: "transform",
          value: function transform(arr, texto, columna) {
            if (texto === '') {
              return arr;
            }

            texto = texto.toLocaleLowerCase();
            return arr.filter(function (item) {
              return item[columna].toLocaleLowerCase().includes(texto);
            });
          }
        }]);

        return FiltroPipe;
      }();

      FiltroPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'filtro'
      })], FiltroPipe);
      /***/
    },

    /***/
    "./src/app/pipes/pipes.module.ts":
    /*!***************************************!*\
      !*** ./src/app/pipes/pipes.module.ts ***!
      \***************************************/

    /*! exports provided: PipesModule */

    /***/
    function srcAppPipesPipesModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PipesModule", function () {
        return PipesModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _filtro_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./filtro.pipe */
      "./src/app/pipes/filtro.pipe.ts");

      var PipesModule = function PipesModule() {
        _classCallCheck(this, PipesModule);
      };

      PipesModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_2__["FiltroPipe"]],
        exports: [_filtro_pipe__WEBPACK_IMPORTED_MODULE_2__["FiltroPipe"]]
      })], PipesModule);
      /***/
    },

    /***/
    "./src/app/servicios/backend.service.ts":
    /*!**********************************************!*\
      !*** ./src/app/servicios/backend.service.ts ***!
      \**********************************************/

    /*! exports provided: BackendService */

    /***/
    function srcAppServiciosBackendServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BackendService", function () {
        return BackendService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs/operators */
      "./node_modules/rxjs/_esm2015/operators/index.js");

      var BackendService = /*#__PURE__*/function () {
        function BackendService(http) {
          _classCallCheck(this, BackendService);

          this.http = http;
          this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
          console.log("Hola");
        }

        _createClass(BackendService, [{
          key: "getUsuarios",
          //USUARIOS
          value: function getUsuarios() {
            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios';
            return this.http.get(path);
          } //CREAR USUARIOS

        }, {
          key: "crearUsuario",
          value: function crearUsuario(usuario) {
            var _this6 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios';
            return this.http.post(path, usuario).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this6._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //VERIFICAR USUARIO 

        }, {
          key: "verificar",
          value: function verificar(email, contra) {
            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios/verificar/' + email;
            return this.http.put(path, contra).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          }
        }, {
          key: "verificar2",
          value: function verificar2(email, contra) {
            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios/verificar/' + email + '/' + contra;
            return this.http.get(path);
          } //ACTUALIZAR INFORMACION DE USUARIO

        }, {
          key: "updateUsuario",
          value: function updateUsuario(usuario, id) {
            var _this7 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios/' + id;
            return this.http.put(path, usuario).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this7._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //ELIMINAR USUARIO

        }, {
          key: "eliminarUsuario",
          value: function eliminarUsuario(id) {
            var _this8 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/usuarios/' + id;
            return this.http["delete"](path).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this8._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //Ventas

        }, {
          key: "getVentas",
          value: function getVentas() {
            var path = 'https://backend-pgcontrol.herokuapp.com/ventas';
            return this.http.get(path);
          } //CREAR VENTA

        }, {
          key: "crearVenta",
          value: function crearVenta(venta) {
            var _this9 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/ventas';
            return this.http.post(path, venta).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this9._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //OBTENER VENTA

        }, {
          key: "idVenta",
          value: function idVenta(id) {
            var path = 'https://backend-pgcontrol.herokuapp.com/ventas/' + id;
            return this.http.get(path);
          } //OBTENER CORTES

        }, {
          key: "getCortes",
          value: function getCortes() {
            var path = 'https://backend-pgcontrol.herokuapp.com/cortecaja';
            return this.http.get(path);
          } //CREAR CORTE

        }, {
          key: "crearCorte",
          value: function crearCorte(corte) {
            var _this10 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/cortecaja';
            return this.http.post(path, corte).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this10._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //ELIMINAR SESION

        }, {
          key: "eliminarSesion",
          value: function eliminarSesion(id) {
            var _this11 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/sesion/' + id;
            return this.http["delete"](path).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this11._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            })["catch"](function (data) {
              console.log(data);
              return data;
            });
          } //CREAR SESION

        }, {
          key: "crearSesion",
          value: function crearSesion(sesion) {
            var _this12 = this;

            var path = 'https://backend-pgcontrol.herokuapp.com/sesion';
            return this.http.post(path, sesion).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
              _this12._refresh$.next();
            })).toPromise().then(function (data) {
              console.log(data);
              return data;
            });
          } //CONSULTAR SESION

        }, {
          key: "getSesion",
          value: function getSesion() {
            var path = 'https://backend-pgcontrol.herokuapp.com/sesion';
            return this.http.get(path);
          } //PRODUCTOS
          //CONSULTAR PRODUCTOS

        }, {
          key: "getProductos",
          value: function getProductos() {
            var path = 'https://backend-pgcontrol.herokuapp.com/piezas';
            return this.http.get(path);
          }
        }, {
          key: "refresh$",
          get: function get() {
            return this._refresh$;
          }
        }]);

        return BackendService;
      }();

      BackendService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
        }];
      };

      BackendService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], BackendService);
      /***/
    },

    /***/
    "./src/environments/environment.ts":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "./src/main.ts":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function srcMainTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "./src/app/app.module.ts");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "./src/environments/environment.ts");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! C:\Users\LoziM\Desktop\UsoD\Escuela\7mo Semestre\Ing. Software\PGControl\src\main.ts */
      "./src/main.ts");
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map