(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-infoventas-infoventas-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infoventas/infoventas.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infoventas/infoventas.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Ventas realizadas\"></app-header>\n\n<ion-content>\n\n  <ion-list>\n\n\n    <ion-card *ngFor=\"let v of ventas | async\" color=\"dark\" mode=\"ios\">\n      <ion-card-header>\n        <ion-card-subtitle>ID Venta: {{v.idventa}} <p></p> ID Usuario: {{v.idusuario}} <p></p> Usuario: {{v.nombre}} {{v.apellidos}}</ion-card-subtitle>\n        <ion-card-title >Fecha: {{v.fecha}}       Hora: {{v.hora}}</ion-card-title>\n      </ion-card-header>\n\n      <ion-item class=\"back\">\n        <!-- <ion-icon name=\"call-outline\" slot=\"start\"></ion-icon> -->\n        <ion-label>{{v.descripcion}},</ion-label>\n      </ion-item>\n\n      <ion-item class=\"back\">\n        <!-- <ion-icon name=\"mail-outline\" slot=\"start\"></ion-icon> -->\n        <ion-label>Monto de venta: ${{v.montoventa}}</ion-label>\n      </ion-item>\n\n    </ion-card>\n\n    \n\n  </ion-list>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/infoventas/infoventas-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/infoventas/infoventas-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: InfoventasPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoventasPageRoutingModule", function() { return InfoventasPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _infoventas_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./infoventas.page */ "./src/app/pages/infoventas/infoventas.page.ts");




const routes = [
    {
        path: '',
        component: _infoventas_page__WEBPACK_IMPORTED_MODULE_3__["InfoventasPage"]
    }
];
let InfoventasPageRoutingModule = class InfoventasPageRoutingModule {
};
InfoventasPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InfoventasPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/infoventas/infoventas.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/infoventas/infoventas.module.ts ***!
  \*******************************************************/
/*! exports provided: InfoventasPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoventasPageModule", function() { return InfoventasPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _infoventas_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./infoventas-routing.module */ "./src/app/pages/infoventas/infoventas-routing.module.ts");
/* harmony import */ var _infoventas_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./infoventas.page */ "./src/app/pages/infoventas/infoventas.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let InfoventasPageModule = class InfoventasPageModule {
};
InfoventasPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _infoventas_routing_module__WEBPACK_IMPORTED_MODULE_5__["InfoventasPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_infoventas_page__WEBPACK_IMPORTED_MODULE_6__["InfoventasPage"]]
    })
], InfoventasPageModule);



/***/ }),

/***/ "./src/app/pages/infoventas/infoventas.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/infoventas/infoventas.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm92ZW50YXMvaW5mb3ZlbnRhcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/infoventas/infoventas.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/infoventas/infoventas.page.ts ***!
  \*****************************************************/
/*! exports provided: InfoventasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoventasPage", function() { return InfoventasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/servicios/backend.service */ "./src/app/servicios/backend.service.ts");
/* harmony import */ var pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! pdfmake/build/pdfmake */ "./node_modules/pdfmake/build/pdfmake.js");
/* harmony import */ var pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! pdfmake/build/vfs_fonts */ "./node_modules/pdfmake/build/vfs_fonts.js");
/* harmony import */ var pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_4__);





pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_3___default.a.vfs = pdfmake_build_vfs_fonts__WEBPACK_IMPORTED_MODULE_4___default.a.pdfMake.vfs;
let InfoventasPage = class InfoventasPage {
    constructor(backendService) {
        this.backendService = backendService;
    }
    ngOnInit() {
        this.ventas = this.backendService.getVentas();
    }
    pdf() {
        let docDefinition = {
            content: [
                'Hola pérros'
            ]
        };
        this.pdfObject = pdfmake_build_pdfmake__WEBPACK_IMPORTED_MODULE_3___default.a.createPdf(docDefinition);
        this.pdfObject.download();
    }
};
InfoventasPage.ctorParameters = () => [
    { type: src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__["BackendService"] }
];
InfoventasPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-infoventas',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./infoventas.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infoventas/infoventas.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./infoventas.page.scss */ "./src/app/pages/infoventas/infoventas.page.scss")).default]
    })
], InfoventasPage);



/***/ })

}]);
//# sourceMappingURL=pages-infoventas-infoventas-module-es2015.js.map