(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-infocortes-infocortes-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infocortes/infocortes.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infocortes/infocortes.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Cortes realizados\"></app-header>\n\n<ion-content>\n\n  <ion-list>\n\n    <ion-card *ngFor=\"let c of cortes | async\" color=\"dark\" mode=\"ios\">\n      <ion-card-header>\n        <ion-card-subtitle>ID Corte: {{c.idcorte}} <p></p> ID Usuario: {{c.idusuario}} <p></p> Usuario: {{c.nombre}} {{c.apellidos}}</ion-card-subtitle>\n        <ion-card-title >Fecha: {{c.fecha}}       Hora: {{c.hora}}</ion-card-title>\n      </ion-card-header>\n\n      <ion-item class=\"back\">\n        <!-- <ion-icon name=\"call-outline\" slot=\"start\"></ion-icon> -->\n        <ion-label>{{c.descripcion}},</ion-label>\n      </ion-item>\n\n      <ion-item class=\"back\">\n        <!-- <ion-icon name=\"mail-outline\" slot=\"start\"></ion-icon> -->\n        <ion-label>Monto de corte: ${{c.monto}}</ion-label>\n      </ion-item>\n\n    </ion-card>\n\n    \n\n  </ion-list>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/infocortes/infocortes-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/infocortes/infocortes-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: InfocortesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfocortesPageRoutingModule", function() { return InfocortesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _infocortes_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./infocortes.page */ "./src/app/pages/infocortes/infocortes.page.ts");




const routes = [
    {
        path: '',
        component: _infocortes_page__WEBPACK_IMPORTED_MODULE_3__["InfocortesPage"]
    }
];
let InfocortesPageRoutingModule = class InfocortesPageRoutingModule {
};
InfocortesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InfocortesPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/infocortes/infocortes.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/infocortes/infocortes.module.ts ***!
  \*******************************************************/
/*! exports provided: InfocortesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfocortesPageModule", function() { return InfocortesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _infocortes_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./infocortes-routing.module */ "./src/app/pages/infocortes/infocortes-routing.module.ts");
/* harmony import */ var _infocortes_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./infocortes.page */ "./src/app/pages/infocortes/infocortes.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let InfocortesPageModule = class InfocortesPageModule {
};
InfocortesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _infocortes_routing_module__WEBPACK_IMPORTED_MODULE_5__["InfocortesPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_infocortes_page__WEBPACK_IMPORTED_MODULE_6__["InfocortesPage"]]
    })
], InfocortesPageModule);



/***/ }),

/***/ "./src/app/pages/infocortes/infocortes.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/infocortes/infocortes.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm9jb3J0ZXMvaW5mb2NvcnRlcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/infocortes/infocortes.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/infocortes/infocortes.page.ts ***!
  \*****************************************************/
/*! exports provided: InfocortesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfocortesPage", function() { return InfocortesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/servicios/backend.service */ "./src/app/servicios/backend.service.ts");



let InfocortesPage = class InfocortesPage {
    constructor(backendService) {
        this.backendService = backendService;
    }
    ngOnInit() {
        this.cortes = this.backendService.getCortes();
    }
};
InfocortesPage.ctorParameters = () => [
    { type: src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__["BackendService"] }
];
InfocortesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-infocortes',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./infocortes.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/infocortes/infocortes.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./infocortes.page.scss */ "./src/app/pages/infocortes/infocortes.page.scss")).default]
    })
], InfocortesPage);



/***/ })

}]);
//# sourceMappingURL=pages-infocortes-infocortes-module-es2015.js.map