(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-adminusuarios-adminusuarios-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/adminusuarios/adminusuarios.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/adminusuarios/adminusuarios.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Administración de Usuarios\"></app-header>\n\n<ion-content>\n\n  <ion-list>\n\n    <ion-card *ngFor=\"let u of usuarios | async\" color=\"dark\" mode=\"ios\">\n      <ion-card-header>\n        <ion-card-subtitle>{{u.tipo}}</ion-card-subtitle>\n        <ion-card-title>{{u.nombre}} {{u.apellidos}}</ion-card-title>\n      </ion-card-header>\n\n      <ion-item class=\"back\">\n        <ion-icon name=\"call-outline\" slot=\"start\"></ion-icon>\n        <ion-label>Telefono: {{u.telefono}}</ion-label>\n      </ion-item>\n\n      <ion-item class=\"back\">\n        <ion-icon name=\"mail-outline\" slot=\"start\"></ion-icon>\n        <ion-label>Email: {{u.email}}</ion-label>\n      </ion-item>\n\n      <ion-item class=\"back\">\n        <ion-icon name=\"home-outline\" slot=\"start\"></ion-icon>\n        <ion-label>Domicilio: {{u.domicilio}}</ion-label>\n      </ion-item>\n\n      <ion-item class=\"back\">\n        <ion-button (click)=\"guardar(u)\" color=\"tertiary\" fill=\"solid\" slot=\"start\"><ion-icon name=\"create-outline\" slot=\"start\"></ion-icon>Editar</ion-button>\n        <ion-button (click)=\"eliminarAlerta(u.idusuario)\" color=\"danger\" fill=\"solid\" slot=\"end\"><ion-icon name=\"trash-outline\" slot=\"start\"></ion-icon>Eliminar</ion-button>\n      </ion-item>\n\n    </ion-card>\n\n  </ion-list>\n\n  <ion-fab  vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"success\" (click)=\"crearUsuarios()\">\n      <ion-icon name=\"person-add-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/adminusuarios/adminusuarios-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/adminusuarios/adminusuarios-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: AdminusuariosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminusuariosPageRoutingModule", function() { return AdminusuariosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _adminusuarios_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./adminusuarios.page */ "./src/app/pages/adminusuarios/adminusuarios.page.ts");




const routes = [
    {
        path: '',
        component: _adminusuarios_page__WEBPACK_IMPORTED_MODULE_3__["AdminusuariosPage"]
    }
];
let AdminusuariosPageRoutingModule = class AdminusuariosPageRoutingModule {
};
AdminusuariosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AdminusuariosPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/adminusuarios/adminusuarios.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/adminusuarios/adminusuarios.module.ts ***!
  \*************************************************************/
/*! exports provided: AdminusuariosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminusuariosPageModule", function() { return AdminusuariosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _adminusuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./adminusuarios-routing.module */ "./src/app/pages/adminusuarios/adminusuarios-routing.module.ts");
/* harmony import */ var _adminusuarios_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./adminusuarios.page */ "./src/app/pages/adminusuarios/adminusuarios.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");
/* harmony import */ var src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/pipes/pipes.module */ "./src/app/pipes/pipes.module.ts");
/* harmony import */ var _crear_usuarios_crear_usuarios_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../crear-usuarios/crear-usuarios.page */ "./src/app/pages/crear-usuarios/crear-usuarios.page.ts");
/* harmony import */ var _crear_usuarios_crear_usuarios_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../crear-usuarios/crear-usuarios.module */ "./src/app/pages/crear-usuarios/crear-usuarios.module.ts");
/* harmony import */ var _editar_usuarios_editar_usuarios_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../editar-usuarios/editar-usuarios.page */ "./src/app/pages/editar-usuarios/editar-usuarios.page.ts");
/* harmony import */ var _editar_usuarios_editar_usuarios_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../editar-usuarios/editar-usuarios.module */ "./src/app/pages/editar-usuarios/editar-usuarios.module.ts");













let AdminusuariosPageModule = class AdminusuariosPageModule {
};
AdminusuariosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        entryComponents: [_crear_usuarios_crear_usuarios_page__WEBPACK_IMPORTED_MODULE_9__["CrearUsuariosPage"], _editar_usuarios_editar_usuarios_page__WEBPACK_IMPORTED_MODULE_11__["EditarUsuariosPage"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _adminusuarios_routing_module__WEBPACK_IMPORTED_MODULE_5__["AdminusuariosPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"],
            src_app_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
            _crear_usuarios_crear_usuarios_module__WEBPACK_IMPORTED_MODULE_10__["CrearUsuariosPageModule"],
            _editar_usuarios_editar_usuarios_module__WEBPACK_IMPORTED_MODULE_12__["EditarUsuariosPageModule"]
        ],
        declarations: [_adminusuarios_page__WEBPACK_IMPORTED_MODULE_6__["AdminusuariosPage"]]
    })
], AdminusuariosPageModule);



/***/ }),

/***/ "./src/app/pages/adminusuarios/adminusuarios.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/adminusuarios/adminusuarios.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWludXN1YXJpb3MvYWRtaW51c3Vhcmlvcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/adminusuarios/adminusuarios.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/adminusuarios/adminusuarios.page.ts ***!
  \***********************************************************/
/*! exports provided: AdminusuariosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminusuariosPage", function() { return AdminusuariosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/servicios/backend.service */ "./src/app/servicios/backend.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _crear_usuarios_crear_usuarios_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../crear-usuarios/crear-usuarios.page */ "./src/app/pages/crear-usuarios/crear-usuarios.page.ts");
/* harmony import */ var _editar_usuarios_editar_usuarios_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../editar-usuarios/editar-usuarios.page */ "./src/app/pages/editar-usuarios/editar-usuarios.page.ts");







let AdminusuariosPage = class AdminusuariosPage {
    constructor(modalCtrl, backendService, alertController) {
        this.modalCtrl = modalCtrl;
        this.backendService = backendService;
        this.alertController = alertController;
    }
    ngOnInit() {
        this.usuarios = this.backendService.getUsuarios();
        this.usuarios.subscribe(usuarios => {
            this.apellidos = usuarios[0].apellidos;
        });
        this.suscription = this.backendService.refresh$.subscribe(() => {
            this.usuarios = this.backendService.getUsuarios();
        });
    }
    //GUARDAR DATOS DE USUARIOS LOCALMENTE
    guardar(u) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.id = u.idusuario;
            this.nombre = u.nombre;
            this.apellidos = u.apellidos;
            this.telefono = u.telefono;
            this.email = u.email;
            this.contrasena = u.contrasena;
            this.domicilio = u.domicilio;
            this.tipo = u.tipo;
            console.log(u);
            this.editarUsuarios();
        });
    }
    //MODAL PARA MODIFICAR USUARIOS
    editarUsuarios() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _editar_usuarios_editar_usuarios_page__WEBPACK_IMPORTED_MODULE_5__["EditarUsuariosPage"],
                cssClass: 'my-custom-class',
                componentProps: {
                    "id": this.id,
                    "nombre": this.nombre,
                    "apellidos": this.apellidos,
                    "telefono": this.telefono,
                    "email": this.email,
                    "contrasena": this.contrasena,
                    "domicilio": this.domicilio,
                    "tipo": this.tipo
                }
            });
            yield modal.present();
        });
    }
    //MODAL PARA CREAR USUSARIOS
    crearUsuarios() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _crear_usuarios_crear_usuarios_page__WEBPACK_IMPORTED_MODULE_4__["CrearUsuariosPage"],
                cssClass: 'my-custom-class',
                componentProps: {
                    'firstName': 'Douglas',
                    'lastName': 'Adams',
                    'middleInitial': 'N'
                }
            });
            yield modal.present();
        });
    }
    //ELIMINAR USUARIO
    eliminarUsuario(id) {
        this.backendService.eliminarUsuario(id);
    }
    eliminarAlerta(u) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Eliminar usuario',
                subHeader: '¿Estas seguro de eliminar este usuario?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Eliminar',
                        handler: () => {
                            console.log(u);
                            this.eliminarUsuario(u);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
AdminusuariosPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: src_app_servicios_backend_service__WEBPACK_IMPORTED_MODULE_2__["BackendService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
AdminusuariosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-adminusuarios',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./adminusuarios.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/adminusuarios/adminusuarios.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./adminusuarios.page.scss */ "./src/app/pages/adminusuarios/adminusuarios.page.scss")).default]
    })
], AdminusuariosPage);



/***/ })

}]);
//# sourceMappingURL=pages-adminusuarios-adminusuarios-module-es2015.js.map